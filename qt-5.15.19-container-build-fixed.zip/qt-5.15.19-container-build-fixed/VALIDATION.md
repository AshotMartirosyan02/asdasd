# Validation — 2026-09-11

Այս ֆայլը տարբերակում է իրականում կատարված տեղական ստուգումները և այն ստուգումները, որոնք driver-ը պետք է կատարի ընկերության host-երում։
Այս արխիվով իրական Qt compilation կամ production installation այստեղ չի կատարվել։

## Կատարված ստուգումներ

| Ստուգում | Արդյունք | Սահման |
|---|---|---|
| Shell syntax, Python syntax և Python 3.6-compatible parsing | PASS | Ամբողջ նոր code tree |
| Թիրախային regression checks | 19 PASS | Native ELF fixtures և isolated temporary files |
| Target ordering/routing | 30 PASS | Երկու host architecture, 1/2/3 target-ի բոլոր հերթականությունները, mocked Docker/SSH |
| Deduplication, local/remote failure continuation, invalid CLI modes, dry-run | PASS | Host orchestration fixtures |
| Image fingerprint reuse/invalidation, post-only rejection, image build failure | PASS | Mocked Docker metadata/build operations |
| AOK/SOA/AAW vendor configure/build/install փուլերի կանչեր | 3 target PASS | Տրամադրված vendor source-ի normalized պատճեն, configure/make fixtures |
| Native ELF ABI version-needs parsing և wrong-architecture rejection | PASS | Իրական GCC-ով ստեղծված փոքր x86_64 ELF |
| Relative .pc/Libs.private, .prl build-tree removal | PASS | Metadata fixtures; Qt consumer-ը այստեղ չի compile արվել |
| patchelf failure/fallback, original-byte preservation | PASS | Իրական ELF input, mocked rewriting tools՝ ներառյալ rc=139 |
| Source/installed hashes, runtime aliases, PostgreSQL subtree | PASS | Temporary fixtures; ընկերության export-երի ֆայլերը այստեղ չկան |
| Public module list | PASS | Համեմատված է տրամադրված makeQt5Pkg.pl-ի Qt5Libraries_to_ship ցանկի հետ |
| mgc_home public/inhouse layout, relative aliases, qmake/source preservation, overwrite rejection | PASS | Native ELF/layout fixtures, mocked RPATH rewrite |

Fixture-ները, dummy licenses-ը և raw test data-ն չեն մտնում ZIP-ի մեջ։
Արխիվը պարունակում է իրական build-ից հետո ավտոմատ աշխատող validation code-ը և C++ consumer source-ը։

## Իրական միջավայրում դեռ չկատարված

| Target | Image build | Qt compile/install | Runtime/relocation/package consumers | Reference parity |
|---|---|---|---|---|
| AOK | NOT RUN | NOT RUN | NOT RUN | NOT RUN |
| SOA | NOT RUN | NOT RUN | NOT RUN | NOT RUN |
| AAW | NOT RUN | NOT RUN | NOT RUN | NOT RUN |

Այս workspace-ում Docker daemon/CLI և ընկերության /wv mounts չկան։
eiger/cal-arm-19 host-երում հրամաններ չեն գործարկվել, գործող install-ները և container-ները չեն փոփոխվել։
Հետևաբար այս փաստաթուղթը չի հավաստում, որ իրական միջավայրի բոլոր խնդիրներն արդեն վերացած են։

Առաջին full run-ը ստուգելու է իրական RPM repositories/entitlements-ը, EL8 SDK-ը,
mounts-ը, cdtop/NFS write permissions-ը և նշված dependency export-երի լրիվությունը։
AAW-ի լրացուցիչ packaging families/subtree paths-ը հիմնված են տրամադրված audit-ի և vendor paths-ի վրա․ այստեղ դրանց բովանդակությունը հասանելի չէ։
Պակասող package/source կամ ABI/feature mismatch-ը դադարեցնում է target-ը հստակ սխալով։ Այդ gate-երը չեն շրջանցվել։

Առանց read-only reference mount-ի սահմանաչափերը վերցվում են config/policy.json-ից և report-ում նշվում որպես defaults։
Reference-ի առկայությամբ ceilings-ը չափվում են նրա ELF version needs-ից։ AOK/AAW-ի glibc 2.28 պահանջը պահպանվում է։
Symbol comparison-ը և headless consumers-ը private ABI-ի, իրական printer-ի, DB server-ի կամ GPU display-ի ամբողջական հավաստագրում չեն։

## Ուղղված audit մեկնաբանություններ

- zlib-ի տարբեր file size-ը միայնակ չի ապացուցում տարբեր upstream package․ patchelf-ը նույնպես փոխում է ELF չափը։ Նոր manifest-ը պահում է pre/post-patch hashes-ը առանձին։
- Տարբեր ldd process-ների տարբեր providers-ը նույն process-ի double-load-ի ապացույց չէ։ Նոր consumers-ը ստուգում են իրական /proc/self/maps-ը։
- Public ABI comparison-ում UND symbols չեն հաշվվում։ Private symbols/thunks-ը report-ում առանձնացված են։
- Reference-ի կոտրված symlink-երը, հին absolute prefixes-ը և անաշխատունակ qdoc-ը չեն պատճենվել որպես ցանկալի վարք։

## Input identity

| Input | SHA-256 |
|---|---|
| build_in_container.tar(1).gz | de54ed8e8703ca3ca1d9e9c1797c92073e313c37d9fb366f61e1727bd38f2a5e |
| Pasted markdown(1).md — audit | 127845c6872b9e335c6a0c57f2be2c95aab2e8a5455cb6a79333895636f9fd86 |
| Pasted markdown(2).md — implementation prompt | f9045eb199903b2352344b50178ae546e7e131f4bd5288046c95c50882ddbd2a |

ZIP-ի ֆայլերի checksum-ները ստուգելու համար բացված գլխավոր պանակում գործարկիր՝

~~~bash
sha256sum -c SHA256SUMS
~~~

Առաջին build-ի օրինակ՝

~~~bash
bash ./build-qt.sh --dry-run -aok -soa -aaw
bash ./build-qt.sh -aok -soa -aaw
~~~

Հաջող build-ի իրական ապացույցները կլինեն target-ի build.log-ում և container/logs-ի ABI, feature,
runtime, reference, consumers ու package reports-ում։ Ընդհանուր PASS-ը տրվում է միայն պարտադիր gate-երից հետո։
