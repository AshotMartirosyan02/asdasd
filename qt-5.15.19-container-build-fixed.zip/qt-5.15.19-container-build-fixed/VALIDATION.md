# Validation — v3.1 / 2026-09-11

Այս ֆայլը տարբերակում է իրականում կատարված տեղական ստուգումները և այն ստուգումները, որոնք driver-ը պետք է կատարի ընկերության host-երում։
Այս արխիվով իրական Qt compilation կամ production installation այստեղ չի կատարվել։

## Նոր log-ից հաստատված խնդիրներ

- AOK compile/install-ը և qmake-ի pristine ստուգումը հաջողվել են։ Bundled MySQL-ի ուղին
  plugins/sqldrivers/../../lib/libmysqlclient.so.21 էր՝ ճիշտ գրադարանը։ Հին lexical path check-ը
  այն սխալմամբ մերժել է։ Նոր ստուգումը համեմատում է canonical real files-ը և մերժում է արտաքին providers-ը։
- SOA-ն տեղադրել է SDK package-ները, հետո provision.sh-ն ավարտվել է rc=1-ով՝ առանց հրամանի բացատրության։
  Հին կոդում բոլոր image-ների account-ին պարտադրվել էին AAW-ի UID/GID թվերը։ Այդ սխալ ենթադրությունը հանված է,
  ավելացված են հստակ diagnostics։ Log-ը չի ապացուցում, թե հետտեղադրման որ assertion-ն է իրականում ձախողվել։
  SLE repository-ի ժամկետանց key warning-ից հետո package transaction-ը հաջողվել է․ warning-ը չի ներկայացվում որպես հաստատված պատճառ։
- AAW UBI8 DNF transaction-ը մերժել է 21 բացակայող SDK package։ Վերջին պահանջով AAW-ն վերադարձված է
  company RHEL 9 base-ին։ AOK-ը մնում է RHEL 8, SOA-ն հստակ SLE 15.4։ Այլ OS-ի RPM-եր չեն խառնվում։
- AAW-ի հին reference-ի glibc 2.28 սահմանը փոխարինված է պահանջված RHEL 9 policy-ով՝
  GLIBC 2.34 / GLIBCXX 3.4.29 / CXXABI 1.3.13։ Reference-ի տարբերությունները մնում են տեսանելի report-երում։

## Կատարված ստուգումներ

| Ստուգում | Արդյունք | Սահման |
|---|---|---|
| Shell syntax, Python syntax և Python 3.6-compatible parsing | PASS | Ամբողջ նոր code tree |
| Թիրախային regression checks | 25 PASS | Native ELF fixtures և isolated temporary files |
| Target ordering/routing | 30 PASS | Երկու host architecture, 1/2/3 target-ի բոլոր հերթականությունները, mocked Docker/SSH |
| Deduplication, local/remote failure continuation, invalid CLI modes, dry-run | PASS | Host orchestration fixtures |
| Image reuse/invalidation, post-only policy rejection, image build failure | PASS | Mocked Docker metadata/build operations, իրական state.py |
| Canonical bundled paths, ../.., symlinked Qt root, wrong/external/missing providers | PASS | Իրական filesystem paths և mocked ldd output |
| Plugin $ORIGIN/../../lib resolution | PASS | GCC-ով կառուցված ELF plugin/library և իրական ldd |
| Existing/fresh cdtop identity, explicit UID/GID mismatch | PASS | Isolated command fixtures; host accounts չեն փոփոխվել |
| RHEL8/SLE15.4/RHEL9 provisioning, wrong OS/arch rejection, CodeReady ընտրություն, compiler/DNF/ERR diagnostics | PASS | Իրական recipe՝ isolated path substitutions և mocked package/system commands |
| RHEL 9 AAW policy և reference ABI տարբերությունների report | PASS | ELF metadata fixture; ARM code չի գործարկվել |
| AOK/SOA/AAW vendor configure/build/install փուլերի կանչեր | 3 target PASS | Տրամադրված vendor source-ի normalized պատճեն, configure/make fixtures |
| Native ELF ABI version-needs parsing և wrong-architecture rejection | PASS | Իրական GCC-ով ստեղծված փոքր x86_64 ELF |
| Relative .pc/Libs.private, .prl build-tree removal | PASS | Metadata fixtures; Qt consumer-ը այստեղ չի compile արվել |
| patchelf failure/fallback, original-byte preservation | PASS | Իրական ELF input, mocked rewriting tools՝ ներառյալ rc=139 |
| Source/installed hashes, runtime aliases, PostgreSQL subtree | PASS | Temporary fixtures; ընկերության export-երի ֆայլերը այստեղ չկան |
| Public module list | PASS | Համեմատված է տրամադրված makeQt5Pkg.pl-ի Qt5Libraries_to_ship ցանկի հետ |
| mgc_home public/inhouse layout, relative aliases, qmake/source preservation, overwrite rejection | PASS | Native ELF/layout fixtures, mocked RPATH rewrite |

Fixture-ները, dummy licenses-ը և raw test data-ն չեն մտնում ZIP-ի մեջ։
Արխիվը պարունակում է իրական build-ից հետո ավտոմատ աշխատող validation code-ը և C++ consumer source-ը։

## Այս նոր revision-ի իրական միջավայրի ստուգումներ

| Target | Image build | Qt compile/install | Runtime/relocation/package consumers | Reference parity |
|---|---|---|---|---|
| AOK | NOT RUN | NOT RUN | NOT RUN | NOT RUN |
| SOA | NOT RUN | NOT RUN | NOT RUN | NOT RUN |
| AAW | NOT RUN | NOT RUN | NOT RUN | NOT RUN |

Այս workspace-ում Docker daemon/CLI և ընկերության /wv mounts չկան։
eiger/cal-arm-19 host-երում հրամաններ չեն գործարկվել, գործող install-ները և container-ները չեն փոփոխվել։
Հետևաբար այս փաստաթուղթը չի հավաստում, որ իրական միջավայրի բոլոր խնդիրներն արդեն վերացած են։

Առաջին full run-ը ստուգելու է իրական RPM repositories/entitlements-ը, յուրաքանչյուր OS-ի SDK-ը,
mounts-ը, cdtop/NFS write permissions-ը և նշված dependency export-երի լրիվությունը։
AAW-ի լրացուցիչ packaging families/subtree paths-ը հիմնված են տրամադրված audit-ի և vendor paths-ի վրա․ այստեղ դրանց բովանդակությունը հասանելի չէ։
Պակասող package/source կամ ABI/feature mismatch-ը դադարեցնում է target-ը հստակ սխալով։ Այդ gate-երը չեն շրջանցվել։

Առանց read-only reference mount-ի սահմանաչափերը վերցվում են config/policy.json-ից և report-ում նշվում որպես defaults։
Reference-ի առկայությամբ պահանջները չափվում են նրա ELF version needs-ից։ AOK-ի glibc 2.28 պահանջը պահպանվում է։
AAW-ն օգտագործում է հստակ պահանջված RHEL 9 baseline-ը․ հին RHEL 8 համակարգերում deploy անելու հավաստում չկա։
Symbol comparison-ը և headless consumers-ը private ABI-ի, իրական printer-ի, DB server-ի կամ GPU display-ի ամբողջական հավաստագրում չեն։

## Ուղղված audit մեկնաբանություններ

- zlib-ի տարբեր file size-ը միայնակ չի ապացուցում տարբեր upstream package․ patchelf-ը նույնպես փոխում է ELF չափը։ Նոր manifest-ը պահում է pre/post-patch hashes-ը առանձին։
- Տարբեր ldd process-ների տարբեր providers-ը նույն process-ի double-load-ի ապացույց չէ։ Նոր consumers-ը ստուգում են իրական /proc/self/maps-ը։
- Public ABI comparison-ում UND symbols չեն հաշվվում։ Private symbols/thunks-ը report-ում առանձնացված են։
- Reference-ի կոտրված symlink-երը, հին absolute prefixes-ը և անաշխատունակ qdoc-ը չեն պատճենվել որպես ցանկալի վարք։

## Input identity

| Input | SHA-256 |
|---|---|
| build_in_container.tar(1).gz | de54ed8e8703ca3ca1d9e9c1797c92073e313c37d9fb366f61e1727bd38f2a5e |
| Pasted text(9).txt — վերջին build log | 665eb496f821540c252d55083592c78edfd02117fac0bb68facca9a3e635cefa |
| Pasted markdown(1).md — audit | 127845c6872b9e335c6a0c57f2be2c95aab2e8a5455cb6a79333895636f9fd86 |
| Pasted markdown(2).md — implementation prompt | f9045eb199903b2352344b50178ae546e7e131f4bd5288046c95c50882ddbd2a |

ZIP-ի ֆայլերի checksum-ները ստուգելու համար բացված գլխավոր պանակում գործարկիր՝

~~~bash
sha256sum -c SHA256SUMS
~~~

Առաջին build-ի օրինակ՝

~~~bash
bash ./build-qt.sh --dry-run -aok -soa -aaw
bash ./build-qt.sh -aok -soa -aaw
~~~

Հաջող build-ի իրական ապացույցները կլինեն target-ի build.log-ում և container/logs-ի ABI, feature,
runtime, reference, consumers ու package reports-ում։ Ընդհանուր PASS-ը տրվում է միայն պարտադիր gate-երից հետո։
