# Qt 5.15.19 — container build v3

Պանակը բացելուց հետո գործարկիր՝

~~~bash
bash ./build-qt.sh --dry-run -aok -soa -aaw
bash ./build-qt.sh -aok -soa -aaw
~~~

Կարելի է նաև առանձին կամ ցանկացած հերթականությամբ՝ -aok, -soa, -aaw, -aok -aaw, -soa -aaw։
AAW-ն աշխատում է aarch64 host-ում, մյուսները՝ x86_64-ում։ Անհամապատասխան target-ը ավտոմատ փոխանցվում է համապատասխանաբար cal-arm-19 կամ eiger։

Default Qt repository՝ /wv/ashmarmo_nobackup/fix_container/final/qt։
Այլ տեղակայման դեպքում՝

~~~bash
QT_REPO_DIR=/absolute/path/to/qt bash ./build-qt.sh -aok -aaw
~~~

Առաջին գործարկումը պետք է լինի լրիվ build՝ առանց --post-only-ի։
Հին AAW/RHEL9 build-ի ABI-ն միայն post-processing-ով հնարավոր չէ ուղղել։

Արխիվը պարունակում է build automation-ը, image recipes-ը, runtime/package ստուգումները և փաստաթղթերը։
Qt source-ը, լիցենզիան և ընկերության dependency export-երը վերցվում են քո գործող միջավայրից․ դրանք արխիվում չեն կրկնօրինակված։

Մանրամասները՝ [build_in_container/README.md](build_in_container/README.md)։
Տեղական ստուգումների և դեռ չկատարված իրական build-երի սահմանները՝ [VALIDATION.md](VALIDATION.md)։
