# Qt 5.15.19 — container build v3.1

Պանակը բացելուց հետո գործարկիր՝

~~~bash
bash ./build-qt.sh --dry-run -aok -soa -aaw
bash ./build-qt.sh -aok -soa -aaw
~~~

Կարելի է նաև առանձին կամ ցանկացած հերթականությամբ՝ -aok, -soa, -aaw, -aok -aaw, -soa -aaw։
AAW-ն աշխատում է aarch64 host-ում, մյուսները՝ x86_64-ում։ Անհամապատասխան target-ը ավտոմատ փոխանցվում է համապատասխանաբար cal-arm-19 կամ eiger։

Default Qt repository՝ /wv/ashmarmo_nobackup/fix_container/final/qt։
Այլ տեղակայման դեպքում՝

~~~bash
QT_REPO_DIR=/absolute/path/to/qt bash ./build-qt.sh -aok -aaw
~~~

| Target | Container OS | Host |
|---|---|---|
| aok | Red Hat Enterprise Linux 8 | x86_64 / eiger |
| soa | SUSE Linux Enterprise 15.4 | x86_64 / eiger |
| aaw | Red Hat Enterprise Linux 9 | aarch64 / cal-arm-19 |

Քո վերջին log-ի AOK compile/install-ն ավարտվել է․ այն կանգնել է ճիշտ MySQL ուղու սխալ ստուգման վրա։
Եթե qtbuild-aok-v3 container-ը պահպանված է, նոր պանակից շարունակիր՝

~~~bash
bash ./build-qt.sh -aok --post-only
bash ./build-qt.sh -soa -aaw
~~~

Առաջին հրամանը Qt-ն նորից չի compile անում։ Երկրորդը SOA/AAW-ի լրիվ build-ն է։
--post-only-ն կիրառվում է հրամանի բոլոր target-ների նկատմամբ, դրա համար այստեղ հրամաններն առանձին են։
Եթե AOK container-ը հեռացվել է կամ install-ը չի համապատասխանում պահպանված build state-ին, օգտագործիր լրիվ build։

AAW-ի RHEL 9 պահանջը կիրառված է քո վերջին հստակեցմամբ։ Նրա ABI սահմաններն են
GLIBC 2.34, GLIBCXX 3.4.29, CXXABI 1.3.13։ Հին reference-ի glibc 2.28-ը report-ում համեմատվում է,
բայց նոր AAW build-ի պարտադիր ceiling չէ։ RHEL 8-ում այս AAW build-ի աշխատանք չի խոստացվում։

Արխիվը պարունակում է build automation-ը, image recipes-ը, runtime/package ստուգումները և փաստաթղթերը։
Qt source-ը, լիցենզիան և ընկերության dependency export-երը վերցվում են քո գործող միջավայրից․ դրանք արխիվում չեն կրկնօրինակված։

Մանրամասները՝ [build_in_container/README.md](build_in_container/README.md)։
Տեղական ստուգումների և դեռ չկատարված իրական build-երի սահմանները՝ [VALIDATION.md](VALIDATION.md)։
