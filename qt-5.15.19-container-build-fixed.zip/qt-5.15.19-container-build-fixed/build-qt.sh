#!/usr/bin/env bash
set -Eeuo pipefail
driver_root=$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd -P)
export QT_REPO_DIR="${QT_REPO_DIR:-/wv/ashmarmo_nobackup/fix_container/final/qt}"
exec bash "$driver_root/build_in_container/build-qt.sh" "$@"
