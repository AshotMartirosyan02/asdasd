#!/usr/bin/env bash
set -Eeuo pipefail
source /etc/os-release
[[ "$BUILD_UID" =~ ^[1-9][0-9]*$ && "$BUILD_GID" =~ ^[1-9][0-9]*$ ]]
case "$TARGET:${ID:-}:${VERSION_ID:-}:$(uname -m)" in
    aaw:rhel:8*:aarch64|aaw:almalinux:8*:aarch64|aaw:rocky:8*:aarch64) ;;
    aok:rhel:8*:x86_64) ;;
    soa:sles:15*:x86_64|soa:opensuse*:15*:x86_64) ;;
    *) echo "Wrong base image: $TARGET / $PRETTY_NAME / $(uname -m)" >&2; exit 1 ;;
esac
mapfile -t packages < "/opt/qt-image-build/$TARGET.packages"
if [ "$TARGET" = soa ]; then
    zypper --non-interactive install --no-recommends "${packages[@]}"
else
    repo_args=()
    if [ "$TARGET" = aaw ] && dnf -q repolist --all | awk '{print $1}' | grep -qx ubi-8-codeready-builder-rpms; then
        repo_args+=(--enablerepo=ubi-8-codeready-builder-rpms)
    fi
    dnf "${repo_args[@]}" install -y --setopt=install_weak_deps=False "${packages[@]}" || {
        echo "Required SDK packages unavailable. Supply a correctly entitled EL8 BASE_IMAGE; do not use EL9." >&2
        exit 1
    }
fi
if ! id "$BUILD_USER" >/dev/null 2>&1; then
    getent group "$BUILD_GID" >/dev/null || groupadd -g "$BUILD_GID" "$BUILD_USER"
    useradd -m -u "$BUILD_UID" -g "$BUILD_GID" -s /bin/bash "$BUILD_USER"
fi
[ "$(id -u "$BUILD_USER")" = "$BUILD_UID" ]
[ "$(id -g "$BUILD_USER")" = "$BUILD_GID" ]
IFS=, read -ra groups <<< "$BUILD_GROUPS"
for gid in "${groups[@]}"; do
    [[ "$gid" =~ ^[0-9]+$ && "$gid" != 0 ]]
    getent group "$gid" >/dev/null || groupadd -g "$gid" "qt-build-$gid"
    usermod -a -G "$gid" "$BUILD_USER"
done
mkdir -p /build
chown "$BUILD_UID:$BUILD_GID" /build
test -r /usr/include/cups/cups.h
case "$TARGET" in
    aaw) test "$(getconf GNU_LIBC_VERSION)" = 'glibc 2.28'; test -x /opt/rh/gcc-toolset-13/root/usr/bin/g++ ;;
    aok) test "$(getconf GNU_LIBC_VERSION)" = 'glibc 2.28'; test -x /opt/rh/gcc-toolset-10/root/usr/bin/g++ ;;
    soa) test -x /usr/bin/g++-10 ;;
esac
rpm -qa --qf '%{NAME}\t%{VERSION}-%{RELEASE}\t%{ARCH}\n' | sort > /opt/qt-image-build/installed-packages.tsv
