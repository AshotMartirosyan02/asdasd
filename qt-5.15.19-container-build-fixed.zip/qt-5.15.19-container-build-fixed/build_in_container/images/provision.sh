#!/usr/bin/env bash
set -Eeuo pipefail
trap 'rc=$?; echo "ERROR: image provisioning ($TARGET), line $LINENO, rc=$rc: $BASH_COMMAND" >&2; exit "$rc"' ERR
image_fail(){ echo "ERROR: $TARGET image: $*" >&2; exit 1; }
source /etc/os-release
case "$TARGET:${ID:-}:${VERSION_ID:-}:$(uname -m)" in
    aaw:rhel:9*:aarch64|aok:rhel:8*:x86_64|soa:sles:15.4:x86_64|soa:sle*:15.4:x86_64) ;;
    *) image_fail "Expected AOK=RHEL8/x86_64, SOA=SLE15.4/x86_64, AAW=RHEL9/aarch64; found ${PRETTY_NAME:-unknown}/$(uname -m)" ;;
esac
printf 'Platform: %s (%s)\n' "$PRETTY_NAME" "$(uname -m)"
for value in "${BUILD_UID:-}" "${BUILD_GID:-}"; do
    [ -z "$value" ] || [[ "$value" =~ ^[1-9][0-9]*$ ]] || image_fail "Invalid explicit UID/GID: $value"
done
if id "$BUILD_USER" >/dev/null 2>&1; then id "$BUILD_USER"; fi
mapfile -t packages < "/opt/qt-image-build/$TARGET.packages"
if [ "$TARGET" = soa ]; then
    zypper --non-interactive install --no-recommends "${packages[@]}"
else
    repo_args=()
    repositories=$(dnf -q repolist --all)
    printf '%s\n' "$repositories"
    while read -r repo _; do
        case "$repo" in
            codeready-builder-for-rhel-${VERSION_ID%%.*}-$(uname -m)-rpms)
                repo_args+=(--enablerepo="$repo") ;;
        esac
    done <<< "$repositories"
    dnf "${repo_args[@]}" install -y --setopt=install_weak_deps=False "${packages[@]}" ||
        image_fail "SDK installation failed. The company RHEL ${VERSION_ID%%.*} base must expose BaseOS, AppStream and CodeReady Builder packages; see DNF errors above."
fi
source /opt/qt-image-build/build-user.sh
prepare_build_user
[ -r /usr/include/cups/cups.h ] || image_fail "cups-devel installed no readable /usr/include/cups/cups.h"
case "$TARGET" in
    aaw) compiler=/opt/rh/gcc-toolset-13/root/usr/bin/g++; required_glibc='glibc 2.34' ;;
    aok) compiler=/opt/rh/gcc-toolset-10/root/usr/bin/g++; required_glibc='glibc 2.28' ;;
    soa) compiler=/usr/bin/g++-10; required_glibc='glibc 2.31' ;;
esac
[ "$(getconf GNU_LIBC_VERSION)" = "$required_glibc" ] || image_fail "Expected $required_glibc; got $(getconf GNU_LIBC_VERSION)"
[ -x "$compiler" ] || image_fail "Required compiler is missing: $compiler"
"$compiler" --version
rpm -qa --qf '%{NAME}\t%{VERSION}-%{RELEASE}\t%{ARCH}\n' | sort > /opt/qt-image-build/installed-packages.tsv
echo "OK: $TARGET SDK, compiler, CUPS and build identity verified"
