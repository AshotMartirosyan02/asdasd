prepare_build_user(){
    local uid gid group_name
    if id "$BUILD_USER" >/dev/null 2>&1; then
        uid=$(id -u "$BUILD_USER")
        gid=$(id -g "$BUILD_USER")
        [ -z "${BUILD_UID:-}" ] || [ "$uid" = "$BUILD_UID" ] ||
            image_fail "$BUILD_USER already has UID $uid; explicit BUILD_UID=$BUILD_UID differs"
        [ -z "${BUILD_GID:-}" ] || [ "$gid" = "$BUILD_GID" ] ||
            image_fail "$BUILD_USER already has GID $gid; explicit BUILD_GID=$BUILD_GID differs"
    else
        uid=${BUILD_UID:-108486}
        gid=${BUILD_GID:-6237}
        if getent passwd "$uid" >/dev/null; then
            image_fail "UID $uid belongs to another account; set BUILD_UID for $BUILD_USER"
        fi
        if ! getent group "$gid" >/dev/null; then
            group_name=$BUILD_USER
            getent group "$group_name" >/dev/null && group_name="qt-build-primary-$gid"
            groupadd -g "$gid" "$group_name"
        fi
        useradd -m -u "$uid" -g "$gid" -s /bin/bash "$BUILD_USER"
    fi
    [ "$uid" != 0 ] && [ "$gid" != 0 ] || image_fail "The build identity must be non-root"
    local extra_gid
    local groups=()
    IFS=, read -ra groups <<< "${BUILD_GROUPS:-6236,236}"
    for extra_gid in "${groups[@]}"; do
        [[ "$extra_gid" =~ ^[1-9][0-9]*$ ]] || image_fail "Invalid supplementary GID: $extra_gid"
        getent group "$extra_gid" >/dev/null || groupadd -g "$extra_gid" "qt-build-$extra_gid"
        usermod -a -G "$extra_gid" "$BUILD_USER"
    done
    mkdir -p /build
    chown "$uid:$gid" /build
    id "$BUILD_USER"
}
