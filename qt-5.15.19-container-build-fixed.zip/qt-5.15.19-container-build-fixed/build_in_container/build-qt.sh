#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_PATH=$(readlink -f "${BASH_SOURCE[0]}")
BIC_DIR=$(cd "$(dirname "$SCRIPT_PATH")" && pwd -P)
QT_DIR=${QT_REPO_DIR:-$(cd "$BIC_DIR/.." && pwd -P)}
[[ "$QT_DIR" = /* && -d "$QT_DIR" ]] || { echo "Set QT_REPO_DIR to your existing Qt repository" >&2; exit 2; }
QT_DIR=$(cd "$QT_DIR" && pwd -P)
export QT_REPO_DIR="$QT_DIR"
export BIC_DIR QT_DIR
source "$BIC_DIR/host/lib-log.sh"
source "$BIC_DIR/config/common.conf"
source "$BIC_DIR/host/lib-args.sh"
source "$BIC_DIR/host/lib-remote.sh"
source "$BIC_DIR/host/lib-docker.sh"
parse_args "$@"

for input in "bin/buildQt-$QT_VERSION" bin/qt-license md5sums.txt; do
    [ -r "$QT_DIR/$input" ] || fail "Missing Qt repository input: $QT_DIR/$input"
done
HOST_ARCH=$(uname -m)
case "$HOST_ARCH" in x86_64|aarch64) ;; *) fail "Unsupported host architecture: $HOST_ARCH" ;; esac
RUN_STAMP=$(date -u +%Y%m%dT%H%M%S)-$$
export RUN_STAMP

if [ "$INTERNAL_ONE" = 1 ]; then
    [ "${#TARGETS[@]}" -eq 1 ] || fail "Internal target mode requires one target"
    t=${TARGETS[0]}
    a=$(target_arch "$t")
    if [ "$a" = "$HOST_ARCH" ]; then
        build_target_local "$t"
    else
        [ "$LOCAL_ONLY" = 0 ] && [ "$ALLOW_REMOTE" = 1 ] || fail "$t requires $a; remote execution is disabled"
        dispatch_remote "$a" "$t"
    fi
    exit 0
fi

MAIN_LOG="not written (dry-run)"
if [ "$DRY_RUN" = 0 ]; then
    mkdir -p "$BIC_DIR/logs"
    MAIN_LOG="$BIC_DIR/logs/driver-$RUN_STAMP.log"
    exec > >(tee -a "$MAIN_LOG") 2>&1
fi
info "Qt $QT_VERSION | host $(hostname -s) ($HOST_ARCH) | targets: ${TARGETS[*]}"
info "Repository: $QT_DIR"
info "Mode: $([ "$POST_ONLY" = 1 ] && echo post-only || echo full-build)"
info "Logs: $BIC_DIR/logs"
declare -A RESULT
EXIT_CODE=0
for t in "${TARGETS[@]}"; do
    section "$t"
    set +e
    bash "$SCRIPT_PATH" --_run-one "$t" "${FORWARD_ARGS[@]}"
    rc=$?
    set -e
    if [ "$rc" -eq 0 ]; then
        if [ "$DRY_RUN" = 1 ]; then RESULT[$t]="PLANNED"; else RESULT[$t]="PASS"; fi
    else
        RESULT[$t]="FAIL (rc=$rc)"
        EXIT_CODE=1
    fi
done
section "Summary"
for t in "${TARGETS[@]}"; do
    printf '%-5s %-15s %s/qt-%s\n' "$t" "${RESULT[$t]}" \
        "${INSTALL_ROOT_OVERRIDE:-$IIT_QT_ROOT/$t}" "$QT_VERSION"
done
info "Driver log: $MAIN_LOG"
exit "$EXIT_CODE"
