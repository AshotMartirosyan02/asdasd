assert_build_identity(){
    section "Build identity"
    : "${BUILD_USER:=cdtop}"
    if [ -z "${HOME:-}" ] || [ ! -d "${HOME:-}" ]; then
        HOME=$(getent passwd "$(id -u)" | cut -d: -f6)
    fi
    export HOME BUILD_USER

    echo "Running as:  $(id -un) (uid=$(id -u), gid=$(id -g))"
    echo "Groups:      $(id -Gn)"
    echo "Group ids:   $(id -G)"
    echo "HOME:        $HOME"
    echo "Expected:    $BUILD_USER"

    [ "$(id -u)" != 0 ] || fail "Run the build through build-qt.sh using the ordinary $BUILD_USER account"
    [ "$(id -u)" = "$(id -u "$BUILD_USER")" ] || fail "The build is not running as $BUILD_USER"

    [ -n "$HOME" ] && [ -d "$HOME" ] && [ -w "$HOME" ] ||
        fail "HOME is not writable for $(id -un): '$HOME'"
    [ -w /build ] ||
        fail "/build is not writable by $(id -un) - run container/bootstrap-user.sh as root first"

    ok "identity verified"
}

assert_install_ownership(){
    local dir=$1 probe owner_uid owner_gid dir_uid dir_gid
    probe="$dir/.write-probe-$$"
    touch "$probe" 2>/dev/null ||
        fail "$(id -un) cannot write into $dir - check the group permissions of that directory (or root_squash)"
    owner_uid=$(stat -c '%u' "$probe")
    owner_gid=$(stat -c '%g' "$probe")
    rm -f "$probe"

    [ "$owner_uid" = "$(id -u)" ] ||
        fail "files created in $dir get uid=$owner_uid instead of $(id -u) - broken id mapping on the share"

    dir_uid=$(stat -c '%u' "$dir")
    dir_gid=$(stat -c '%g' "$dir")
    echo "Write test in $dir: OK"
    echo "  new files:  uid=$owner_uid ($(id -un)) gid=$owner_gid"
    echo "  directory:  uid=$dir_uid gid=$dir_gid mode=$(stat -c '%A' "$dir")"
    if [ "$owner_uid" != "$dir_uid" ]; then
        echo "  note: different uid than the directory owner - fine on a group-writable share"
    fi
}

verify_install_ownership(){
    local expected owner f bad=0
    expected=$(id -u)
    for f in "$QT_ROOT" "$QT_ROOT/bin/qmake" "$QT_ROOT/lib/libQt5Core.so.${QT_VERSION}"; do
        [ -e "$f" ] || continue
        owner=$(stat -c '%u' "$f")
        if [ "$owner" != "$expected" ]; then
            echo "WRONG OWNER (uid=$owner, expected $expected): $f"
            bad=1
        fi
    done
    local stray
    stray=$(find "$QT_ROOT" ! -uid "$expected" -printf '%u %p\n' -quit)
    if [ -n "$stray" ]; then
        echo "$stray"
        bad=1
    fi
    [ "$bad" = 0 ] || fail "installed tree is not fully owned by $(id -un)"
    ok "installed tree owned by $(id -un)"
}
