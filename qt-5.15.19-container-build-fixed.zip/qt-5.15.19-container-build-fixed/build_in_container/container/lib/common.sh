ALL_STAGES=(checkTarball extract patch_it configIt injectStyle buildIt buildStyle installIt installStyle fixRpath)

container_hostname(){
    hostname 2>/dev/null ||
        cat /proc/sys/kernel/hostname 2>/dev/null ||
        echo unknown
}

section(){ printf '\n== %s ==\n' "$*"; }
fail(){ echo "ERROR: $*" >&2; exit 1; }
ok(){   echo "OK: $*"; }
warn(){ echo "WARNING: $*"; }
require_cmd(){ command -v "$1" >/dev/null 2>&1 || fail "Required command is missing: $1"; }

LOG_DIR=/build/logs
TOOLS_BIN=/build/tools/bin
BACKUP_DIR=/build/backups
DISABLED_DIR=/build/disabled-artifacts

target_preflight(){ :; }
target_prepare_env(){ :; }
target_post_configure(){ :; }
target_post_install(){ :; }
target_patch_bundled(){ :; }
target_post_rpath(){ :; }
target_extra_smoke(){ :; }
target_final_validation(){ :; }

REQUIRED_COMMANDS=(awk sed grep find xargs file readelf ldd cmp sha256sum md5sum
                   xz tar patch perl sort head tail stat chmod ln mktemp unzip cp mv mkdir
                   rm readlink dirname basename tee diff env nproc bash which date touch id)

check_required_commands(){
    section "Checking the commands this build relies on"
    local c missing=()
    for c in "${REQUIRED_COMMANDS[@]}"; do
        if command -v "$c" >/dev/null 2>&1; then
            printf '  %-10s %s\n' "$c" "$(command -v "$c")"
        else
            missing+=("$c")
        fi
    done
    if command -v gmake >/dev/null 2>&1 || command -v make >/dev/null 2>&1; then
        printf '  %-10s %s\n' make "$(command -v gmake || command -v make)"
    else
        missing+=(make/gmake)
    fi
    if [ "${#missing[@]}" -ne 0 ]; then
        fail "this image is missing required commands: ${missing[*]} - add them to the Dockerfile"
    fi
    command -v hostname >/dev/null 2>&1 || warn "hostname is not installed (cosmetic only)"
    command -v patchelf >/dev/null 2>&1 || echo "INFO: no system patchelf; a toolset build will be selected later"
    ok "all required commands are available"
}

prepare_workspace(){
    section "Preparing build workspace"
    for input in "bin/buildQt-$QT_VERSION" bin/qt-license md5sums.txt "patches/$QT_VERSION-patch"; do
        [ -r "$QT_REPO_DIR/$input" ] || fail "Missing repository input: $QT_REPO_DIR/$input"
    done
    rm -rf /build/qt /build/logs /build/tools /build/backups /build/python-test \
        /build/disabled-artifacts /build/qt-smoke /build/egl-probe /build/qmake-spec-test /build/shim
    mkdir -p /build/qt "$LOG_DIR" "$TOOLS_BIN" "$BACKUP_DIR/mkspecs" \
        /build/python-test "$DISABLED_DIR" /build/egl-probe
    cp -R "$QT_REPO_DIR/bin" "$QT_REPO_DIR/patches" /build/qt/
    cp "$QT_REPO_DIR/md5sums.txt" /build/qt/
    [ ! -f "$QT_REPO_DIR/qt.conf" ] || cp "$QT_REPO_DIR/qt.conf" /build/qt/
    find /build/qt -type d -exec chmod u+rwx {} +
    find /build/qt -type f -exec chmod u+rw {} +
    cd /build/qt
    BUILD_SCRIPT="bin/buildQt-$QT_VERSION"
    cp -p "$BUILD_SCRIPT" "$BUILD_SCRIPT.orig"
    export BUILD_SCRIPT
}

prepare_workspace_light(){
    section "Post-only mode: reusing the existing /build workspace"
    mkdir -p "$LOG_DIR" "$TOOLS_BIN" "$BACKUP_DIR/mkspecs" /build/python-test \
             "$DISABLED_DIR" /build/egl-probe
    mkdir -p /build/qt/bin
    local name
    for name in "buildQt-${QT_VERSION}" qt-license; do
        [ -f "/build/qt/bin/$name" ] && continue
        [ -r "$QT_REPO_DIR/bin/$name" ] || fail "Post-only input is missing: $QT_REPO_DIR/bin/$name"
        cp -p "$QT_REPO_DIR/bin/$name" "/build/qt/bin/$name"
    done
    case "$VCO" in
        aok|soa)
            if [ ! -f /build/qt/bin/makeQt5Pkg.pl ]; then
                [ -r "$QT_REPO_DIR/bin/makeQt5Pkg.pl" ] || fail "Post-only packaging input is missing: $QT_REPO_DIR/bin/makeQt5Pkg.pl"
                cp -p "$QT_REPO_DIR/bin/makeQt5Pkg.pl" /build/qt/bin/makeQt5Pkg.pl
            fi ;;
    esac
    cd /build/qt
    BUILD_SCRIPT="bin/buildQt-${QT_VERSION}"
    export BUILD_SCRIPT
    ok "post-only workspace ready; configure/build/install remain skipped"
}

install_license(){
    section "Installing Qt license"
    export QT_LICENSE_FILE=/build/qt/bin/qt-license
    [ -r "$QT_LICENSE_FILE" ] || QT_LICENSE_FILE="$QT_REPO_DIR/bin/qt-license"
    [ -r "$QT_LICENSE_FILE" ] || fail "Qt license is not readable: $QT_LICENSE_FILE"
    cp -f "$QT_LICENSE_FILE" "$HOME/.qt-license"
    chmod 600 "$HOME/.qt-license"
    ok "license installed for $(id -un) at $HOME/.qt-license"
}

create_python_wrapper(){
    section "Creating Python wrapper"
    local interp="${1:-}"
    if [ -z "$interp" ]; then
        interp=$(command -v python3.11 2>/dev/null || command -v python3 2>/dev/null) ||
            fail "No python3 interpreter found"
    fi
    cat > "$TOOLS_BIN/python" <<PYTHON_WRAPPER
#!/bin/sh
exec $interp "\$@"
PYTHON_WRAPPER
    chmod 755 "$TOOLS_BIN/python"
    export PATH="$TOOLS_BIN:$PATH"
    hash -r
    [ "$(command -v python)" = "$TOOLS_BIN/python" ] || fail "Python wrapper was not selected"

    local missing
    missing=$(ldd "$interp" 2>/dev/null | grep 'not found' || true)
    [ -z "$missing" ] || { echo "$missing"; fail "System Python has missing dependencies"; }

    PYTHON_BIN="$interp"
    export PYTHON_BIN
    ok "python -> $interp"
}

patch_buildqt_common(){
    section "Preparing the vendor build script"
    export QT_DRIVER_TOOLS="$TOOLS_BIN"
    "$PYTHON_BIN" "$CONTAINER_DIR/patch-build.py" build "$BUILD_SCRIPT" "$VCO"
    bash -n "$BUILD_SCRIPT"
}

update_md5sums(){
    section "Preparing Qt tarball checksum"
    [ -r "$QT_TARBALL" ] || fail "Qt tarball is missing: $QT_TARBALL"
    xz -t "$QT_TARBALL" || fail "Qt tarball integrity check failed"

    local md5 checksum_tmp archive_name style_archive style_expected style_actual
    style_archive="$(dirname "$QT_TARBALL")/qtstyleplugins-master.zip"
    [ -r "$style_archive" ] || fail "Style archive is missing: $style_archive"
    style_expected=$(awk '$2=="qtstyleplugins-master.zip" {print $1}' md5sums.txt)
    style_actual=$(md5sum "$style_archive" | awk '{print $1}')
    [ "$style_expected" = "$style_actual" ] || fail "Style archive checksum does not match md5sums.txt"
    unzip -tqq "$style_archive" || fail "Style archive is corrupt: $style_archive"

    archive_name=$(basename "$QT_TARBALL")
    md5=$(md5sum "$QT_TARBALL" | awk '{print $1}')
    checksum_tmp=$(mktemp ./md5sums.txt.XXXXXX) || fail "Cannot create a checksum temporary file in $PWD"
    if ! awk -v name="$archive_name" '$2 != name' md5sums.txt > "$checksum_tmp"; then
        rm -f "$checksum_tmp"
        fail "Cannot read md5sums.txt"
    fi
    printf '%s  %s\n' "$md5" "$archive_name" >> "$checksum_tmp"
    chmod --reference=md5sums.txt "$checksum_tmp"
    mv -f "$checksum_tmp" md5sums.txt
    awk -v name="$archive_name" '$2 == name' md5sums.txt
    ok "md5sums.txt updated"
}

set_stage(){
    local name=$1 value=$2
    grep -qE "^${name}=" "$BUILD_SCRIPT" || fail "Stage variable was not found: $name"
    sed -i -E "s/^${name}=.*/${name}=${value}/" "$BUILD_SCRIPT"
}

set_stages(){
    local s
    for s in "${ALL_STAGES[@]}"; do set_stage "$s" 0; done
    for s in "$@"; do set_stage "$s" 1; done
    set_stage fixRpath 0
    grep -nE "^($(IFS='|'; echo "${ALL_STAGES[*]}"))=" "$BUILD_SCRIPT"
}

run_buildqt(){
    local label=$1 prefix=$2 rc
    LAST_LOG="$LOG_DIR/qt-${VCO}-${prefix}-$(date +%Y%m%d-%H%M%S).out"

    section "$label"
    echo "Log: $LAST_LOG"

    set +e
    bash "$BUILD_SCRIPT" "$VCO" 2>&1 | tee "$LAST_LOG"
    rc=${PIPESTATUS[0]}
    set -e

    echo "$label return code: $rc"
    if [ "$rc" -ne 0 ]; then
        tail -150 "$LAST_LOG"
        fail "$label failed with rc=$rc (log: $LAST_LOG)"
    fi
    grep -q 'INFO --- SUCCESS!' "$LAST_LOG" || fail "$label log does not contain SUCCESS"
    ok "$label completed"
}

phase_prepare(){
    set_stages checkTarball extract patch_it
    run_buildqt "Prepare phase (checkTarball, extract, patch)" prepare
    PREPARE_LOG="$LAST_LOG"
    grep -q 'Patch successful' "$PREPARE_LOG" || fail "Patch stage was not successful"
}

phase_configure(){
    set_stages configIt
    run_buildqt "Configure-only phase" configure
    CONFIG_LOG="$LAST_LOG"
    grep -q "Using install root of: $INSTALL_ROOT" "$CONFIG_LOG" ||
        fail "Configure used the wrong install root (expected $INSTALL_ROOT)"
    grep -q 'Qt is now configured for building' "$CONFIG_LOG" ||
        fail "Qt configure completion message was not found"
}

phase_build_install(){
    set_stages injectStyle
    run_buildqt "Prepare style plugins" styles
    if [ "$VCO" = aaw ]; then
        "$PYTHON_BIN" "$CONTAINER_DIR/style-policy.py" "/build/qt/$VCO/$QT_SRC_DIRNAME/qtstyleplugins"
    fi
    set_stages buildIt buildStyle
    run_buildqt "Build Qt and style plugins" build
    BUILD_LOG="$LAST_LOG"
    local cleanlooks
    cleanlooks=$(find "/build/qt/$VCO/$QT_SRC_DIRNAME" -type f -name 'libqcleanlooks*.so' -print -quit)
    [ -n "$cleanlooks" ] || fail "Cleanlooks style plugin was not built"
    file "$cleanlooks" | grep -q "$EXPECTED_ELF_ARCH" || fail "Built Cleanlooks has the wrong architecture"
    guard_install_target
    set_stages installIt installStyle
    run_buildqt "Install Qt and style plugins" install
    INSTALL_LOG="$LAST_LOG"
    grep -q 'skipping rpath fix step' "$INSTALL_LOG" || fail "Vendor RPATH processing must stay disabled"
    policy_stamp
}

detect_src_tree(){
    section "Locating the extracted Qt source tree"
    local d
    for d in "/build/qt/${VCO}/${QT_SRC_DIRNAME}" "/build/qt/${QT_SRC_DIRNAME}"; do
        if [ -f "$d/qtbase/src/gui/configure.json" ]; then
            SRC_TREE="$d"; export SRC_TREE
            ok "source tree: $SRC_TREE"; return 0
        fi
    done
    while IFS= read -r d; do
        if [ -f "$d/qtbase/src/gui/configure.json" ]; then
            SRC_TREE="$d"; export SRC_TREE
            ok "source tree: $SRC_TREE"; return 0
        fi
    done < <(find /build/qt -maxdepth 4 -type d -name "$QT_SRC_DIRNAME" 2>/dev/null | sort)

    echo "Directories named $QT_SRC_DIRNAME under /build/qt:" >&2
    find /build/qt -maxdepth 4 -type d -name "$QT_SRC_DIRNAME" 2>/dev/null >&2 || true
    fail "No extracted Qt tree containing qtbase/src/gui/configure.json was found"
}

python_generator_check(){
    section "Python reference cleanup and generator validation"
    { grep -RIlZ '/usr/mgc/peteoss/bin/python' "$SRC_TREE" 2>/dev/null || true; } |
        xargs -0 -r sed -i "s|/usr/mgc/peteoss/bin/python|$TOOLS_BIN/python|g"

    local stale
    stale=$( { grep -RIl '/usr/mgc/peteoss/bin/python' "$SRC_TREE" 2>/dev/null || true; } | head -1 )
    [ -z "$stale" ] || fail "PeteOSS Python remains referenced: $stale"

    local gen="$SRC_TREE/qtdeclarative/src/3rdparty/masm/yarr/create_regex_tables"
    [ -f "$gen" ] || fail "Qt regex table generator is missing: $gen"
    rm -f /build/python-test/RegExpJitTables.h
    "$TOOLS_BIN/python" "$gen" > /build/python-test/RegExpJitTables.h
    [ -s /build/python-test/RegExpJitTables.h ] || fail "Qt Python generator produced an empty file"
    ok "python generator validation passed"
}

guard_install_target(){
    section "Preparing install destination"
    mkdir -p "$INSTALL_ROOT"
    assert_install_ownership "$INSTALL_ROOT"
    [ ! -L "$QT_ROOT" ] || fail "The install destination must be a real directory: $QT_ROOT"
    if [ -e "$QT_ROOT" ]; then
        local backup="$QT_ROOT-prev-${RUN_STAMP:-$(date -u +%Y%m%dT%H%M%S)-$$}"
        [ ! -e "$backup" ] || fail "Backup destination already exists: $backup"
        mv -- "$QT_ROOT" "$backup"
        echo "Previous installation: $backup"
        printf '%s\n' "$backup" > "$LOG_DIR/previous-install.txt"
    fi
}

exclude_qdoc(){
    section "Excluding optional qdoc"
    [ ! -e "$QT_ROOT/bin/qdoc" ]       || mv "$QT_ROOT/bin/qdoc"       "$DISABLED_DIR/qdoc"
    [ ! -e "$QT_ROOT/bin/qdoc.debug" ] || mv "$QT_ROOT/bin/qdoc.debug" "$DISABLED_DIR/qdoc.debug"
    [ ! -e "$QT_ROOT/bin/qdoc" ]       || fail "qdoc remains in the install tree"
    [ ! -e "$QT_ROOT/bin/qdoc.debug" ] || fail "qdoc.debug remains in the install tree"
    ok "qdoc excluded"
}

fix_packaging_mysql_path(){
    local vco=$1 mysql_pkg=$2
    section "Preparing $vco MySQL packaging path"
    make_writable /build/qt/bin/makeQt5Pkg.pl
    "$PYTHON_BIN" "$CONTAINER_DIR/patch-build.py" packaging \
        /build/qt/bin/makeQt5Pkg.pl "$vco" --mysql-root "$mysql_pkg"
    perl -c /build/qt/bin/makeQt5Pkg.pl
    cp /build/qt/bin/makeQt5Pkg.pl "$LOG_DIR/makeQt5Pkg.pl"
}

bundle_library(){
    local src=$1 base=$2; shift 2
    [ -f "$src" ] || fail "Runtime library is missing: $src"
    "$PYTHON_BIN" "$CONTAINER_DIR/audit.py" record "$QT_ROOT" "$VCO" \
        --source "$src" --destination "$QT_ROOT/lib/$base"
    cp --remove-destination -- "$src" "$QT_ROOT/lib/$base"
    chmod u+rw,go+r "$QT_ROOT/lib/$base"
    local l
    for l in "$@"; do ln -sfn "$base" "$QT_ROOT/lib/$l"; done
}

copy_family(){
    local src_dir=$1 pattern=$2 description=$3
    local found=0 src real base alias
    local -A copied=()
    [ -d "$src_dir" ] || fail "$description source directory is missing: $src_dir"
    for src in "$src_dir"/$pattern; do
        if [ -e "$src" ] || [ -L "$src" ]; then
            echo "Copying $description: $src"
            real=$(readlink -f "$src") || fail "Cannot resolve $description: $src"
            [ -f "$real" ] || fail "Broken $description source: $src"
            base=${real##*/}
            alias=${src##*/}
            file "$real" | grep -q 'ELF ' || fail "Expected a shared ELF runtime, not a linker script: $real"
            if [ -z "${copied[$real]:-}" ]; then
                bundle_library "$real" "$base"
                copied[$real]=1
            fi
            if [ "$alias" != "$base" ]; then
                ln -sfn "$base" "$QT_ROOT/lib/$alias"
            fi
            found=1
        fi
    done
    [ "$found" -eq 1 ] || fail "No $description files matched $src_dir/$pattern"
}

make_writable(){
    local f=$1
    [ -e "$f" ] || fail "cannot make a missing file writable: $f"
    [ -w "$f" ] && return 0
    chmod u+w "$f" 2>/dev/null ||
        fail "cannot add write permission to $f (owner $(stat -c '%U' "$f" 2>/dev/null), mode $(stat -c '%A' "$f" 2>/dev/null))"
    [ -w "$f" ] || fail "still not writable after chmod: $f"
}

patchelf_set_rpath(){
    local f=$1 rpath=$2 actual temporary candidate
    make_writable "$f"
    if actual=$(env -u LD_LIBRARY_PATH -u LD_PRELOAD "$PATCHELF" --print-rpath "$f") &&
        [ "$actual" = "$rpath" ]; then
        return 0
    fi
    for candidate in "$PATCHELF" "${PATCHELF_CANDIDATES[@]}"; do
        [ -x "$candidate" ] || continue
        temporary=$(mktemp "${f%/*}/.qt-rpath.XXXXXX")
        cp --preserve=mode,timestamps -- "$f" "$temporary"
        if env -u LD_LIBRARY_PATH -u LD_PRELOAD "$candidate" --set-rpath "$rpath" "$temporary" &&
            actual=$(env -u LD_LIBRARY_PATH -u LD_PRELOAD "$candidate" --print-rpath "$temporary") &&
            [ "$actual" = "$rpath" ] && readelf -h -d "$temporary" >/dev/null; then
            mv -f -- "$temporary" "$f"
            PATCHELF="$candidate"
            export PATCHELF
            printf '%s\t%s\t%s\n' "$f" "$candidate" "$rpath" >> "$LOG_DIR/patchelf-applied.tsv"
            return 0
        fi
        warn "patchelf candidate failed; original preserved: $candidate / $f"
        rm -f -- "$temporary"
    done
    fail "Every usable patchelf failed on $f; original remains intact"
}

normalise_tree_permissions(){
    local root=$1
    [ -d "$root" ] || fail "cannot normalise a missing tree: $root"
    section "Normalising permissions under $root"
    find "$root" -type d -exec chmod u+rwx,go+rx {} +
    find "$root" -type f -exec chmod u+rw,go+r {} +
    find "$root" -type f \( -name '*.so' -o -name '*.so.*' \) -exec chmod a+x {} +
    local not_writable
    not_writable=$(find "$root" -type f ! -writable -print -quit)
    [ -z "$not_writable" ] || fail "still not writable after normalisation: $not_writable"
    echo "OK: every file under $root is writable by $(id -un)"
}

create_compiler_wrappers(){
    local real_cc=$1 real_cxx=$2 include_dir=${3:-} compiler real
    local extra_args=()
    [ -z "$include_dir" ] || extra_args=(-isystem "$include_dir")
    for compiler in gcc g++; do
        if [ "$compiler" = gcc ]; then real=$real_cc; else real=$real_cxx; fi
        [ -x "$real" ] || fail "Compiler is missing: $real"
        {
            printf '#!/usr/bin/bash\nexec '
            printf '%q ' "$real" "${extra_args[@]}"
            printf '"$@"\n'
        } > "$TOOLS_BIN/$compiler"
        chmod 755 "$TOOLS_BIN/$compiler"
    done
    export CC="$TOOLS_BIN/gcc" CXX="$TOOLS_BIN/g++"
    export PATH="$TOOLS_BIN:$PATH" QT_DRIVER_TOOLS="$TOOLS_BIN"
    if ! command -v gmake >/dev/null; then
        ln -sfn "$(command -v make)" "$TOOLS_BIN/gmake"
    fi
    hash -r
}
