policy_preflight(){
    section "Checking mandatory build policy"
    require_cmd python3
    require_cmd cmake
    require_cmd pkg-config
    [ -r /usr/include/cups/cups.h ] || fail "cups-devel is required; rebuild the policy image"
    case "$VCO" in
        aaw|aok) [ "$(getconf GNU_LIBC_VERSION)" = 'glibc 2.28' ] ||
            fail "$VCO requires glibc 2.28 in the build image" ;;
    esac
    export EFFECTIVE_POLICY_FILE=/build/effective-policy-v3.json
    python3 "$CONTAINER_DIR/derive-policy.py" "$VCO" "$EFFECTIVE_POLICY_FILE"
    if [ "$POST_ONLY" = 1 ]; then
        python3 "$CONTAINER_DIR/state.py" check "$QT_ROOT" "$VCO"
        python3 "$CONTAINER_DIR/audit.py" abi "$QT_ROOT" "$VCO"
        python3 "$CONTAINER_DIR/audit.py" features "$QT_ROOT" "$VCO"
    fi
}
policy_stamp(){
    cp "$EFFECTIVE_POLICY_FILE" "$QT_ROOT/build-policy.json"
    "$PYTHON_BIN" "$CONTAINER_DIR/state.py" write "$QT_ROOT" "$VCO"
}
policy_audit(){
    cp "$EFFECTIVE_POLICY_FILE" "$LOG_DIR/effective-policy.json"
    "$PYTHON_BIN" "$CONTAINER_DIR/audit.py" "$1" "$QT_ROOT" "$VCO" \
        --report "$LOG_DIR/$1.json"
}
policy_post_configure(){
    section "Checking configure feature policy"
    cp "$EFFECTIVE_POLICY_FILE" "$LOG_DIR/effective-policy.json"
    grep -Eq 'CUPS[ .]+yes' "$CONFIG_LOG" || fail "CUPS was not enabled by configure"
    if [ "$VCO" = aaw ]; then
        grep -Eq 'Vulkan[ .]+no' "$CONFIG_LOG" || fail "AAW Vulkan must be disabled"
    fi
    [ ! -f /opt/qt-image-build/installed-packages.tsv ] ||
        cp /opt/qt-image-build/installed-packages.tsv "$LOG_DIR/image-packages.tsv"
}
policy_patch_runtimes(){
    local f
    while IFS= read -r -d '' f; do
        file "$f" | grep -q 'ELF ' || continue
        readelf -d "$f" | grep -Eq '\((SONAME|NEEDED)\)' || continue
        local runtime_relative
        runtime_relative=$(realpath --relative-to="${f%/*}" "$QT_ROOT/lib")
        if [ "$runtime_relative" = . ]; then
            patchelf_set_rpath "$f" '$ORIGIN'
        else
            patchelf_set_rpath "$f" "\$ORIGIN:\$ORIGIN/$runtime_relative"
        fi
    done < <(find "$QT_ROOT/lib" -type f -name '*.so*' ! -name 'libQt5*' ! -name '*.debug' -print0)
    if [ -d "$QT_ROOT/libexec" ]; then
        while IFS= read -r -d '' f; do
            file "$f" | grep -q 'ELF ' || continue
            readelf -d "$f" | grep -q '(NEEDED)' || continue
            local relative
            relative=$(realpath --relative-to="${f%/*}" "$QT_ROOT/lib")
            patchelf_set_rpath "$f" "\$ORIGIN:\$ORIGIN/$relative"
        done < <(find "$QT_ROOT/libexec" -type f ! -name '*.debug' -print0)
    fi
}
policy_reference(){
    if [ -n "${REFERENCE_ROOT:-}" ]; then
        "$PYTHON_BIN" "$CONTAINER_DIR/audit.py" reference "$QT_ROOT" "$VCO" \
            --reference "$REFERENCE_ROOT" --report "$LOG_DIR/reference-symbols.json"
    else
        echo "NOT RUN: no read-only reference tree mounted" > "$LOG_DIR/reference-status.txt"
    fi
}
policy_consumers(){
    section "Testing qmake, CMake, pkg-config and a relocated copy"
    "$PYTHON_BIN" "$CONTAINER_DIR/consumers.py" "$QT_ROOT" "$VCO" \
        --work "$LOG_DIR/consumers" --compiler "$CXX"
}
policy_package(){
    section "Creating and verifying an isolated mgc_home package preview"
    local work
    work=$(mktemp -d /build/package-check.XXXXXX)
    "$PYTHON_BIN" "$BIC_DIR/package-qt.py" --source "$QT_ROOT" --target "$VCO" \
        --output "$work/mgc_home" --patchelf "$PATCHELF"
    "$PYTHON_BIN" "$CONTAINER_DIR/consumers.py" \
        "$work/mgc_home/shared/pkgs/icv_qt5_comp_inhouse.$VCO" "$VCO" \
        --work "$LOG_DIR/package-consumers" --compiler "$CXX" --no-copy
    printf '%s\n' "$work/mgc_home" > "$LOG_DIR/package-preview.txt"
}
