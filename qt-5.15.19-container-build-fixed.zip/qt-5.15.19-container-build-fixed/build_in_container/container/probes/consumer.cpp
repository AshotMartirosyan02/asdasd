#include <QApplication>
#include <QDir>
#include <QFile>
#include <QPluginLoader>
#include <QPrinterInfo>
#include <QQmlComponent>
#include <QQmlEngine>
#include <QSet>
#include <QSqlDatabase>
#include <QStyle>
#include <QStyleFactory>
#include <QTextStream>

int main(int argc, char **argv)
{
    const QString root = qEnvironmentVariable("TEST_QT_ROOT");
    QCoreApplication::setLibraryPaths(QStringList() << root + "/plugins");
    QApplication app(argc, argv);
    QTextStream out(stdout);
    if (QString::fromLatin1(qVersion()) != "5.15.19")
        return 10;
    QStyle *style = QStyleFactory::create("cleanlooks");
    if (!style)
        return 16;
    app.setStyle(style);
    QQmlEngine engine;
    engine.setImportPathList(QStringList() << root + "/qml");
    QQmlComponent component(&engine);
    component.setData("import QtQuick 2.15\nRectangle { width: 10; height: 10 }", QUrl());
    QObject *object = component.create();
    if (!object) {
        out << component.errorString() << "\n";
        return 11;
    }
    delete object;
    QPluginLoader cups(root + "/plugins/printsupport/libcupsprintersupport.so");
    if (!cups.load()) {
        out << cups.errorString() << "\n";
        return 12;
    }
    const auto printers = QPrinterInfo::availablePrinters();
    out << "PRINTERS " << printers.size() << "\n";
    QStringList sqlDrivers = {"QSQLITE", "QPSQL"};
    if (qEnvironmentVariable("QT_DRIVER_EXPECT_MYSQL") == "1")
        sqlDrivers << "QMYSQL";
    for (const auto &driver : sqlDrivers) {
        QSqlDatabase db = QSqlDatabase::addDatabase(driver, "probe-" + driver);
        if (!db.isValid()) {
            out << "INVALID SQL DRIVER " << driver << "\n";
            return 13;
        }
        if (driver == "QSQLITE") {
            db.setDatabaseName(":memory:");
            if (!db.open())
                return 14;
            db.close();
        }
    }
    QFile maps("/proc/self/maps");
    if (!maps.open(QIODevice::ReadOnly))
        return 15;
    QSet<QString> seen;
    for (const auto &line : maps.readAll().split('\n')) {
        int start = line.indexOf('/');
        if (start < 0)
            continue;
        const QString path = QString::fromUtf8(line.mid(start));
        if (!path.contains(".so") || seen.contains(path))
            continue;
        seen.insert(path);
        out << "MAP " << path << "\n";
    }
    return 0;
}
