#!/usr/bin/bash
set -Eeuo pipefail
export USER="${USER:-root}"
trap 'rc=$?; echo "ERROR: aborted (rc=$rc) at line $LINENO: $BASH_COMMAND" >&2' ERR

VCO="${1:-${VCO:-}}"
[ -n "$VCO" ] || { echo "usage: run-build.sh <aok|soa|aaw>" >&2; exit 2; }

CONTAINER_DIR=$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd -P)
BIC_DIR=$(cd "$CONTAINER_DIR/.." && pwd -P)

QT_VERSION="${QT_VERSION:-5.15.19}"
QT_SRC_DIRNAME="qt-everywhere-src-${QT_VERSION}"
QT_TARBALL="${QT_TARBALL:-/wv/calibre_3rdparty/tarballs/Qt/${QT_SRC_DIRNAME}.tar.xz}"
QT_REPO_DIR="${QT_REPO_DIR:-$(cd "$BIC_DIR/.." && pwd -P)}"
IIT_QT_ROOT="${IIT_QT_ROOT:-/wv/iit/qt}"
INSTALL_ROOT="${INSTALL_ROOT:-$IIT_QT_ROOT/$VCO}"
QT_ROOT="$INSTALL_ROOT/qt-$QT_VERSION"
JOBS="${JOBS:-$(nproc)}"
[[ "$JOBS" =~ ^[1-9][0-9]*$ ]] || { echo "Invalid JOBS: $JOBS" >&2; exit 2; }
POST_ONLY="${POST_ONLY:-0}"
export VCO QT_VERSION QT_SRC_DIRNAME QT_TARBALL QT_REPO_DIR IIT_QT_ROOT INSTALL_ROOT QT_ROOT JOBS POST_ONLY

case "$(uname -m)" in
    x86_64)  EXPECTED_ELF_ARCH='x86-64' ;;
    aarch64) EXPECTED_ELF_ARCH='ARM aarch64' ;;
    *) echo "ERROR: unsupported architecture $(uname -m)" >&2; exit 1 ;;
esac
export EXPECTED_ELF_ARCH

. "$CONTAINER_DIR/lib/common.sh"
. "$CONTAINER_DIR/lib/egl-x11.sh"
. "$CONTAINER_DIR/lib/rpath.sh"
. "$CONTAINER_DIR/lib/privileges.sh"
. "$CONTAINER_DIR/lib/verify.sh"
. "$CONTAINER_DIR/lib/policy.sh"

[ -f "$CONTAINER_DIR/targets/$VCO.sh" ] || fail "Unknown target: $VCO"
. "$CONTAINER_DIR/targets/$VCO.sh"

section "Qt $QT_VERSION - $VCO container build"
echo "Host inside container: $(container_hostname)"
echo "Architecture:          $(uname -m)"
echo "Qt repository:         $QT_REPO_DIR"
echo "Install root:          $INSTALL_ROOT"
echo "Final tree:            $QT_ROOT"
echo "Parallel jobs:         $JOBS"
echo "Mode:                  $([ "$POST_ONLY" = 1 ] && echo post-only || echo full)"

assert_build_identity
check_required_commands
target_preflight
policy_preflight

if [ "$POST_ONLY" = 1 ]; then
    section "POST-ONLY: reusing the installed tree in $QT_ROOT"
    [ -d "$QT_ROOT" ] || fail "Missing installed tree: $QT_ROOT"
    [ -x "$QT_ROOT/bin/qmake" ] || fail "POST_ONLY=1 but $QT_ROOT/bin/qmake is missing - the tree is incomplete"
    PREPARE_LOG="n/a (post-only)"
    CONFIG_LOG="n/a (post-only)"
    BUILD_LOG="n/a (post-only)"
    prepare_workspace_light
    install_license
    target_prepare_env
else
    prepare_workspace
    install_license
    target_prepare_env
    select_patchelf
    patch_buildqt_common
    update_md5sums

    phase_prepare
    detect_src_tree

    egl_probe
    egl_patch_configure_json
    python_generator_check

    phase_configure
    egl_verify_summary
    target_post_configure
    policy_post_configure

    phase_build_install
fi

validate_install_basics
verify_install_prefix

normalise_tree_permissions "$QT_ROOT"

target_post_install
policy_audit collect
exclude_qdoc

normalise_tree_permissions "$QT_ROOT"
select_patchelf
qmake_backup
patch_qt_libraries
target_patch_bundled
policy_patch_runtimes
patch_plugins "\$ORIGIN:\$ORIGIN/../../lib:\$ORIGIN/../../../icv_lib/lib64:\$ORIGIN/../../../icv_lib.${VCO}/lib64"
patch_qml_plugins
patch_bootstrap_tools
patch_qt_executables
qmake_regression
target_post_rpath
policy_audit pc
policy_audit tools-view
policy_audit manifest
policy_audit abi
policy_audit features
policy_audit runtime
policy_reference

assert_tree_writable "$QT_ROOT"
audit_unsafe_rpaths
audit_missing_deps

build_smoke_test
target_extra_smoke
policy_consumers
policy_package
qtdiag_optional

final_validation
final_summary
