#!/usr/bin/env python3
"""Disable only GTK2 subprojects in the staged qtstyleplugins source."""
from pathlib import Path
import re
import sys


def disable_gtk2(root):
    changes = []
    for path in sorted(root.rglob('*.pro')):
        text = path.read_text()
        logical = re.sub(r'\\\r?\n', ' ', text)
        lines = []
        changed = False
        for line in logical.splitlines():
            match = re.search(r'\bSUBDIRS\s*[+*~-]?=', line)
            if match:
                first, rhs = line[:match.end()], line[match.end():]
                rhs, count = re.subn(r'(?<![\w/.-])(?:[\w.-]+/)*gtk2(?=\s|$)', '', rhs)
                changed = changed or bool(count)
                line = first + rhs
            lines.append(line)
        if changed:
            path.write_text('\n'.join(lines) + '\n')
            changes.append(str(path.relative_to(root)))
    for path in root.rglob('*.pro'):
        logical = re.sub(r'\\\r?\n', ' ', path.read_text())
        for line in logical.splitlines():
            if re.search(r'\bSUBDIRS\s*[+*~-]?=', line) and 'gtk2' in line.split('=', 1)[1].split('#', 1)[0]:
                raise ValueError('Unsupported GTK2 subproject expression: ' + str(path))
    return changes


if __name__ == '__main__':
    root = Path(sys.argv[1])
    if not (root / 'qtstyleplugins.pro').is_file():
        raise SystemExit('Missing staged qtstyleplugins.pro')
    for change in disable_gtk2(root):
        print('GTK2 disabled in ' + change)
