#!/usr/bin/env python3
import json
import hashlib
import os
from pathlib import Path
import sys

mode, root, target = sys.argv[1:]
path = Path(root) / 'build-state.json'
expected = {'schema': 3, 'target': target, 'qt': '5.15.19',
            'image_fingerprint': os.environ.get('IMAGE_FINGERPRINT', '')}
policy_file = os.environ.get('EFFECTIVE_POLICY_FILE', '')
expected['policy_sha256'] = hashlib.sha256(Path(policy_file).read_bytes()).hexdigest() if policy_file else ''
if not expected['image_fingerprint']:
    raise SystemExit('Image fingerprint is required')
if mode == 'write':
    path.write_text(json.dumps(expected, indent=2) + '\n')
elif mode == 'check':
    if not path.is_file() or json.loads(path.read_text()) != expected:
        raise SystemExit('Incompatible or untracked installation: full rebuild required; tree not changed')
else:
    raise SystemExit('Unknown state operation')
