#!/usr/bin/env python3
"""Run real consumers with a clean loader environment, including relocation."""
import argparse
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tempfile
from audit import ENV, inside, object_info, write_json

MODULES = ['Core', 'Gui', 'Widgets', 'Qml', 'Quick', 'Sql', 'PrintSupport']


def command(args, cwd, env, log):
    with log.open('a') as stream:
        stream.write('$ ' + ' '.join(shlex.quote(str(x)) for x in args) + '\n')
        stream.flush()
        subprocess.check_call([str(x) for x in args], cwd=str(cwd), env=env,
                              stdout=stream, stderr=subprocess.STDOUT, timeout=600)


def validate_maps(text, root):
    selected = {}
    qt_seen = False
    for line in text.splitlines():
        if not line.startswith('MAP '):
            continue
        path = Path(line[4:])
        if not path.is_file():
            continue
        info = object_info(path)
        soname = info['soname']
        if not soname:
            continue
        selected.setdefault(soname, set()).add(str(path.resolve()))
        if soname.startswith('libQt5'):
            qt_seen = True
            if not inside(path, root) and not inside(path, root / 'lib'):
                raise ValueError('Consumer loaded Qt from another tree: ' + str(path))
    if not qt_seen:
        raise ValueError('Consumer produced no actual Qt loader mappings')
    duplicates = {name: sorted(paths) for name, paths in selected.items() if len(paths) > 1}
    if duplicates:
        raise ValueError('One process loaded multiple providers: ' + repr(duplicates))
    return {name: sorted(paths)[0] for name, paths in selected.items()}


def test_tree(root, work, compiler, target):
    work.mkdir(parents=True, exist_ok=False)
    probes = Path(__file__).resolve().parent / 'probes'
    shutil.copy2(str(probes / 'consumer.cpp'), str(work / 'consumer.cpp'))
    env = dict(ENV, PKG_CONFIG_LIBDIR=str(root / 'lib/pkgconfig'),
               PKG_CONFIG_PATH='', PKG_CONFIG_SYSROOT_DIR='',
               CMAKE_PREFIX_PATH=str(root), QTDIR=str(root), QT_SELECT='',
               QT_QPA_PLATFORM='offscreen', QT_QUICK_BACKEND='software',
               QML_DISABLE_DISK_CACHE='1', QT_DRIVER_EXPECT_MYSQL='0' if target == 'aaw' else '1',
               TEST_QT_ROOT=str(root))
    env['QT_QPA_PLATFORM_PLUGIN_PATH'] = str(root / 'plugins/platforms')
    env.pop('QMAKEPATH', None)
    env.pop('QMAKEFEATURES', None)
    env.pop('QMAKESPEC', None)
    for key in ('CMAKE_TOOLCHAIN_FILE', 'QT_CONF_PATH'):
        env.pop(key, None)
    log = work / 'commands.log'
    prefix = subprocess.check_output([str(root / 'bin/qmake'), '-query', 'QT_INSTALL_PREFIX'],
                                     env=env, universal_newlines=True).strip()
    if Path(prefix).resolve() != root.resolve():
        raise ValueError('qmake relocation failed: ' + prefix)
    results = {}
    for method in ('qmake', 'cmake', 'pkg-config'):
        directory = work / method
        directory.mkdir()
        if method == 'qmake':
            (directory / 'consumer.pro').write_text(
                'QT += core gui widgets qml quick sql printsupport\nCONFIG += console c++17\n'
                'CONFIG -= app_bundle\nSOURCES += ../consumer.cpp\nTARGET = consumer\n')
            command([root / 'bin/qmake', 'consumer.pro'], directory, env, log)
            command(['make', '-j2'], directory, env, log)
            exe = directory / 'consumer'
        elif method == 'cmake':
            (directory / 'CMakeLists.txt').write_text(
                'cmake_minimum_required(VERSION 3.10)\nproject(consumer LANGUAGES CXX)\n'
                'set(CMAKE_CXX_STANDARD 17)\n'
                'find_package(Qt5 5.15.19 EXACT REQUIRED COMPONENTS ' + ' '.join(MODULES) + ')\n'
                'add_executable(consumer ../consumer.cpp)\n'
                'target_link_libraries(consumer PRIVATE ' + ' '.join('Qt5::' + m for m in MODULES) + ')\n')
            command(['cmake', '-S', '.', '-B', 'build', '-DCMAKE_CXX_COMPILER=' + compiler,
                     '-DCMAKE_PREFIX_PATH=' + str(root), '-DCMAKE_FIND_USE_PACKAGE_REGISTRY=OFF',
                     '-DCMAKE_FIND_PACKAGE_NO_PACKAGE_REGISTRY=ON'], directory, env, log)
            command(['cmake', '--build', 'build', '--', '-j2'], directory, env, log)
            exe = directory / 'build/consumer'
        else:
            flags = subprocess.check_output(
                ['pkg-config', '--cflags', '--libs'] + ['Qt5' + m for m in MODULES],
                env=env, universal_newlines=True)
            if str(root) not in flags or '/build/qt/' in flags:
                raise ValueError('pkg-config selects a wrong prefix: ' + flags)
            # Static flags are metadata-checked too, without imposing a static-Qt build.
            static_flags = subprocess.check_output(
                ['pkg-config', '--static', '--libs', 'Qt5Core'], env=env, universal_newlines=True)
            for token in shlex.split(static_flags):
                if token.startswith('/') and ('qt-5.15' in token) and not inside(Path(token), root):
                    raise ValueError('Stale Libs.private path: ' + token)
            exe = directory / 'consumer'
            command([compiler, '-std=c++17', '-fPIC', '../consumer.cpp', '-o', exe,
                     '-Wl,-rpath,' + str(root / 'lib')] + shlex.split(flags), directory, env, log)
        output = subprocess.check_output([str(exe)], cwd=str(directory), env=env,
                                         stderr=subprocess.STDOUT, universal_newlines=True, timeout=120)
        (directory / 'runtime.log').write_text(output)
        results[method] = validate_maps(output, root)
    write_json(work / 'loaded-providers.json', results)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path)
    parser.add_argument('target', choices=('aaw', 'aok', 'soa'))
    parser.add_argument('--work', type=Path, required=True)
    parser.add_argument('--compiler', required=True)
    parser.add_argument('--no-copy', action='store_true')
    args = parser.parse_args()
    root = args.root.resolve()
    args.work.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix='run-', dir=str(args.work)))
    test_tree(root, work / 'original', args.compiler, args.target)
    if not args.no_copy:
        relocated = Path(tempfile.mkdtemp(prefix='qt-relocation-', dir='/build')) / 'qt'
        command(['cp', '-a', '--reflink=auto', str(root), str(relocated)], work, ENV, work / 'copy.log')
        test_tree(relocated, work / 'relocated', args.compiler, args.target)
        (work / 'relocated-tree.txt').write_text(str(relocated) + '\n')
    print('OK: real consumers and loader mappings: ' + str(work))


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        print('ERROR: consumer validation: ' + str(error), file=sys.stderr)
        sys.exit(1)
