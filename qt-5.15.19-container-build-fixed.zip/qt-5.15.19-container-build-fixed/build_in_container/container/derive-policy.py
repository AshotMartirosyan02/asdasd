#!/usr/bin/env python3
import json
import os
from pathlib import Path
import sys
from audit import elfs, object_info, version_tuple, write_json

target, destination = sys.argv[1:]
policy = json.loads((Path(__file__).resolve().parents[1] / 'config/policy.json').read_text())[target]
reference = os.environ.get('REFERENCE_ROOT', '')
maxima = {}
if reference:
    count = 0
    for path in elfs(Path(reference)):
        info = object_info(path)
        if info['machine'] != policy['arch']:
            raise SystemExit('Wrong-architecture object in reference: ' + str(path))
        count += 1
        for name, version in info['versions'].items():
            if version_tuple(version) > version_tuple(maxima.get(name, '0')):
                maxima[name] = version
    if not count or 'GLIBC' not in maxima:
        raise SystemExit('Reference does not contain usable dynamic ELF version needs')
    if target != 'aaw':
        for family, key in (('GLIBC', 'glibc'), ('GLIBCXX', 'glibcxx'), ('CXXABI', 'cxxabi')):
            if family in maxima:
                policy[key] = maxima[family]
    if target == 'aok' and version_tuple(policy['glibc']) > (2, 28):
        raise SystemExit('Reference violates the required EL8/glibc 2.28 baseline')
result = {'target': target, 'policy': policy, 'reference': reference,
          'reference_maxima': maxima, 'limits_source': 'reference version needs' if reference else 'config/policy.json defaults'}
if target == 'aaw':
    result['limits_source'] = 'requested RHEL 9 platform: config/policy.json'
    result['reference_abi_differences'] = {
        name: {'reference': maxima[name], 'platform_limit': policy[key]}
        for name, key in (('GLIBC', 'glibc'), ('GLIBCXX', 'glibcxx'), ('CXXABI', 'cxxabi'))
        if name in maxima and maxima[name] != policy[key]}
write_json(destination, result)
print(json.dumps(result, sort_keys=True))
