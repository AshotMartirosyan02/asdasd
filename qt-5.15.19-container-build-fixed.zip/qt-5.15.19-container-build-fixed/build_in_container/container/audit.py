#!/usr/bin/env python3
"""ELF, metadata and runtime provenance checks; Python 3.6+."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

AREAS = ('bin', 'lib', 'libexec', 'plugins', 'qml', 'tools_lib')
ENV = dict(os.environ, LC_ALL='C')
for _key in ('LD_LIBRARY_PATH', 'LD_PRELOAD', 'LD_AUDIT', 'QT_PLUGIN_PATH',
             'QT_QPA_PLATFORM_PLUGIN_PATH', 'QML2_IMPORT_PATH', 'QML_IMPORT_PATH'):
    ENV.pop(_key, None)


def run(*args, **kwargs):
    return subprocess.check_output(args, stderr=subprocess.STDOUT, env=kwargs.get('env', ENV),
                                   universal_newlines=True, timeout=kwargs.get('timeout', 60))


def sha(path):
    h = hashlib.sha256()
    with open(str(path), 'rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def inside(path, root):
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except (ValueError, RuntimeError):
        return False


def elfs(root):
    areas = AREAS if any((root / p).is_dir() for p in AREAS) else ('.',)
    for area in areas:
        for path in sorted((root / area).rglob('*')):
            if path.is_symlink() or not path.is_file() or path.name.endswith('.debug'):
                continue
            with path.open('rb') as stream:
                if stream.read(4) == b'\x7fELF':
                    yield path


def version_tuple(value):
    return tuple(int(n) for n in value.split('.'))


def version_needs(output):
    result = {}
    in_needs = False
    for line in output.splitlines():
        if line.startswith('Version ') and 'section' in line:
            in_needs = line.startswith('Version needs section')
        if not in_needs:
            continue
        match = re.search(r'\bName: (GLIBC|GLIBCXX|CXXABI)_([0-9.]+)\b', line)
        if match:
            name, version = match.groups()
            if version_tuple(version) > version_tuple(result.get(name, '0')):
                result[name] = version
    return result


def object_info(path):
    header = run('readelf', '-hW', str(path))
    dynamic = run('readelf', '-dW', str(path))
    machine = re.search(r'^\s*Machine:\s*(.+)$', header, re.M)
    soname = re.search(r'\(SONAME\).*\[(.*?)\]', dynamic)
    return {
        'machine': machine.group(1) if machine else '',
        'soname': soname.group(1) if soname else '',
        'needed': re.findall(r'\(NEEDED\).*\[(.*?)\]', dynamic),
        'runpath': re.findall(r'\((?:RPATH|RUNPATH)\).*\[(.*?)\]', dynamic),
        'versions': version_needs(run('readelf', '-VW', str(path)))
    }


def check_abi(root, policy):
    rows, errors = [], []
    caps = {'GLIBC': policy['glibc'], 'GLIBCXX': policy['glibcxx'], 'CXXABI': policy['cxxabi']}
    for path in elfs(root):
        info = object_info(path)
        rel = str(path.relative_to(root))
        rows.append(dict(path=rel, **info))
        if info['machine'] != policy['arch']:
            errors.append('{}: wrong machine {}'.format(rel, info['machine']))
        for name, version in info['versions'].items():
            if version_tuple(version) > version_tuple(caps[name]):
                errors.append('{}: {}_{} exceeds {}'.format(rel, name, version, caps[name]))
    if not rows:
        errors.append('No ELF objects found')
    return {'objects': rows, 'errors': errors, 'limits': caps}


def check_links(root):
    errors = []
    for path in sorted(root.rglob('*')):
        if not path.is_symlink():
            continue
        if os.path.isabs(os.readlink(str(path))) or not path.exists() or not inside(path, root):
            errors.append('Unsafe/broken symlink: {} -> {}'.format(path, os.readlink(str(path))))
    return errors


def fix_pc(root):
    changes = []
    for path in sorted((root / 'lib' / 'pkgconfig').glob('*.pc')):
        before = path.read_text()
        match = re.search(r'^prefix=(.+)$', before, re.M)
        if not match:
            raise ValueError('Missing prefix in ' + str(path))
        old = match.group(1).rstrip('/')
        text = before
        for prefix in sorted({str(root), old}, key=len, reverse=True):
            if not prefix.startswith('/'):
                continue
            text = re.sub(re.escape(prefix) + r'(?=/|(?=\s|$))', lambda _: '${prefix}', text)
        text = re.sub(r'^prefix=.*$', 'prefix=${pcfiledir}/../..', text, flags=re.M)
        if '/build/' in text or '/qt-5.15/' in text:
            raise ValueError('Unresolved build/legacy path in ' + str(path))
        if text != before:
            path.write_text(text)
            changes.append(str(path.relative_to(root)))
    if not list((root / 'lib' / 'pkgconfig').glob('Qt5Core.pc')):
        raise ValueError('Qt5Core.pc missing')
    for path in sorted(root.rglob('*.prl')):
        before = path.read_text()
        text = re.sub(r'^QMAKE_PRL_BUILD_DIR\s*=.*\n?', '', before, flags=re.M)
        text = re.sub(re.escape(str(root / 'lib')) + r'(?=/|(?=\s|$))',
                      lambda _: '$$[QT_INSTALL_LIBS]', text)
        if text != before:
            path.write_text(text)
            changes.append(str(path.relative_to(root)))
    return changes


def record(root, source, destination):
    source, destination = source.resolve(), Path(destination)
    if not source.is_file() or not inside(destination, root):
        raise ValueError('Invalid runtime source/destination')
    info = object_info(source)
    if not info['soname']:
        raise ValueError('Runtime source has no SONAME: ' + str(source))
    record_path = root / 'runtime-sources.json'
    records = json.loads(record_path.read_text()) if record_path.exists() else {}
    relative = str(destination.relative_to(root))
    old = records.get(relative)
    source_hash = sha(source)
    if old and (old['source'] != str(source) or old['source_sha256'] != source_hash):
        raise ValueError('Runtime source changed; full rebuild required: ' + relative)
    records[relative] = dict(source=str(source), source_sha256=source_hash, **info)
    write_json(record_path, records)


def collect_exports(root, target):
    """Bundle only already-resolved private export dependencies, never glibc."""
    initial = list(elfs(root))
    chosen = {}
    for path in initial:
        info = object_info(path)
        if not info['needed']:
            continue
        output = run('ldd', str(path), env=dict(ENV, LD_LIBRARY_PATH=str(root / 'lib')))
        for name, resolved in re.findall(r'^\s*(\S+) => (/\S+) ', output, re.M):
            if inside(Path(resolved), root) or not resolved.startswith(('/wv/', '/user/')):
                continue
            if re.match(r'lib(?:c|m|pthread|dl|rt|stdc\+\+|gcc_s)\.so', name):
                raise ValueError('Do not bundle the toolchain/libc: ' + resolved)
            for other in {'aaw', 'aok', 'soa'} - {target}:
                if re.search(r'(?:engr-|[./])' + other + r'(?:[./_-]|$)', resolved):
                    raise ValueError('Cross-target dependency: ' + resolved)
            real = Path(resolved).resolve()
            if name in chosen and chosen[name] != real:
                raise ValueError('Multiple export providers for ' + name)
            chosen[name] = real
    for name, source in sorted(chosen.items()):
        destination = root / 'lib' / source.name
        if destination.exists() and sha(destination) != sha(source):
            records = root / 'runtime-sources.json'
            known = json.loads(records.read_text()) if records.exists() else {}
            if str(destination.relative_to(root)) not in known:
                raise ValueError('Conflicting runtime destination: ' + str(destination))
        else:
            if destination.is_symlink():
                raise ValueError('Refusing to overwrite runtime symlink ' + str(destination))
            shutil.copy2(str(source), str(destination))
        record(root, source, destination)
        for alias in {name, object_info(source)['soname']}:
            link = root / 'lib' / alias
            if link == destination:
                continue
            if link.exists() or link.is_symlink():
                if link.resolve() != destination.resolve():
                    raise ValueError('Runtime alias collision: ' + str(link))
            else:
                link.symlink_to(destination.name)
    return {k: str(v) for k, v in chosen.items()}


def finalize_manifest(root, target):
    path = root / 'runtime-sources.json'
    records = json.loads(path.read_text()) if path.exists() else {}
    for rel, entry in records.items():
        destination = root / rel
        entry['installed_sha256'] = sha(destination)
        entry['installed_runpath'] = object_info(destination)['runpath']
        entry['target'] = target
        entry['aliases'] = [str(p.relative_to(root)) for p in root.rglob('*')
                            if p.is_symlink() and p.resolve() == destination.resolve()]
    result = {
        'target': target, 'image_id': os.environ.get('IMAGE_ID', ''),
        'image_fingerprint': os.environ.get('IMAGE_FINGERPRINT', ''),
        'provider_policy': 'in-tree runtime first via RUNPATH; system ABI libraries remain system',
        'libraries': records
    }
    write_json(root / 'runtime-manifest.json', result)
    return result


def tools_view(root):
    records = json.loads((root / 'runtime-sources.json').read_text())
    view = root / 'tools_lib'
    view.mkdir(exist_ok=True)
    if (root / 'lib/postgresql').is_dir():
        alias = view / 'postgresql'
        if not alias.is_symlink() and alias.exists():
            raise ValueError('tools_lib/postgresql collision')
        if not alias.is_symlink():
            alias.symlink_to('../lib/postgresql')
    for path in sorted((root / 'lib').iterdir()):
        real_rel = str(path.resolve().relative_to(root)) if inside(path, root) else ''
        if real_rel not in records:
            continue
        alias = view / path.name
        if alias.is_symlink() and alias.resolve() == path.resolve():
            continue
        if alias.exists() or alias.is_symlink():
            raise ValueError('tools_lib collision: ' + str(alias))
        alias.symlink_to('../lib/' + path.name)


def copy_subtree(root, source):
    if not source.is_dir():
        raise ValueError('PostgreSQL packaging subtree missing: ' + str(source))
    destination = root / 'lib/postgresql'
    plan = []
    for path in sorted(source.rglob('*')):
        if path.is_symlink() and not inside(path, source):
            raise ValueError('External PostgreSQL subtree symlink: ' + str(path))
        if path.is_symlink() and not path.exists():
            raise ValueError('Broken PostgreSQL subtree symlink: ' + str(path))
        plan.append((path, destination / path.relative_to(source)))
    destination.mkdir(exist_ok=True)
    resources = {}
    for path, dest in plan:
        if path.is_symlink():
            target = destination / path.resolve().relative_to(source.resolve())
            value = os.path.relpath(str(target), str(dest.parent))
            if dest.is_symlink():
                if os.readlink(str(dest)) != value:
                    raise ValueError('PostgreSQL alias changed: ' + str(dest))
            elif dest.exists():
                raise ValueError('PostgreSQL destination collision: ' + str(dest))
            else:
                dest.symlink_to(value)
        elif path.is_dir():
            dest.mkdir(exist_ok=True)
        elif path.is_file():
            shutil.copy2(str(path), str(dest))
            dest.chmod(dest.stat().st_mode | 0o200)
            resources[str(dest.relative_to(root))] = {'source': str(path), 'source_sha256': sha(path)}
            with path.open('rb') as stream:
                if stream.read(4) == b'\x7fELF' and object_info(path)['soname']:
                    record(root, path, dest)
    write_json(root / 'postgresql-resources.json', resources)
    return resources


def check_runtime(root):
    rows, errors = [], []
    for path in elfs(root):
        info = object_info(path)
        for value in info['runpath']:
            for part in value.split(':'):
                if part != '$ORIGIN' and not part.startswith('$ORIGIN/'):
                    errors.append('Unsafe RUNPATH: {}: {}'.format(path, part))
        if not info['needed']:
            continue
        try:
            output = run('ldd', str(path))
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
            errors.append('ldd failed: {}: {}'.format(path, str(exc)))
            continue
        if 'not found' in output:
            errors.append('Unresolved dependency: {}\n{}'.format(path, output))
        for name, resolved in re.findall(r'^\s*(\S+) => (/\S+) ', output, re.M):
            provider = 'tree' if inside(Path(resolved), root) else 'system'
            if name in info['needed'] and (root / 'lib' / name).exists() and provider != 'tree':
                errors.append('Direct dependency bypasses its bundled provider: {} -> {} -> {}'.format(path, name, resolved))
            if provider != 'tree' and not resolved.startswith(('/lib/', '/lib64/', '/usr/lib/', '/usr/lib64/')):
                errors.append('Unexpected external provider: {} -> {}'.format(path, resolved))
            rows.append({'object': str(path.relative_to(root)), 'soname': name,
                         'provider': provider, 'resolved': resolved})
    errors.extend(check_links(root))
    return {'edges': rows, 'errors': errors}


def check_features(root, policy):
    required = ['plugins/styles/libqcleanlooksstyle.so', 'plugins/platforms/libqxcb.so',
                'plugins/platforms/libqoffscreen.so', 'plugins/sqldrivers/libqsqlpsql.so']
    if policy['cups']:
        required += ['plugins/printsupport/libcupsprintersupport.so',
                     'lib/cmake/Qt5PrintSupport/Qt5PrintSupport_QCupsPrinterSupportPlugin.cmake']
    if policy['mysql']:
        required += ['plugins/sqldrivers/libqsqlmysql.so']
    if policy['egl_x11']:
        required += ['plugins/egldeviceintegrations/libqeglfs-x11-integration.so',
                     'plugins/xcbglintegrations/libqxcb-egl-integration.so']
    errors = ['Missing required artifact: ' + p for p in required if not (root / p).is_file()]
    if not policy['mysql'] and (root / 'plugins/sqldrivers/libqsqlmysql.so').exists():
        errors.append('MySQL must be disabled')
    if policy['gtk2'] is False:
        for path in (root / 'plugins').rglob('*gtk2*'):
            errors.append('Unexpected GTK2 plugin: ' + str(path))
    if policy['vulkan'] is False:
        for name in ('include/QtVulkanSupport', 'lib/libQt5VulkanSupport.a',
                     'mkspecs/modules/qt_lib_vulkan_support_private.pri'):
            if (root / name).exists():
                errors.append('Vulkan must be disabled: ' + name)
        header = root / 'include/QtGui/qtgui-config.h'
        if not header.is_file() or not re.search(r'^#define QT_FEATURE_vulkan -1$', header.read_text(), re.M):
            errors.append('QT_FEATURE_vulkan is not explicitly disabled')
    return {'required': required, 'errors': errors}


def defined_symbols(path):
    result = set()
    for line in run('readelf', '--dyn-syms', '--wide', str(path)).splitlines():
        fields = line.split()
        if len(fields) >= 8 and fields[4] in ('GLOBAL', 'WEAK') and fields[6] != 'UND':
            if fields[5] in ('DEFAULT', 'PROTECTED'):
                result.add(fields[7])
    return result


def compare_reference(root, reference):
    if not reference.is_dir() or reference.resolve() == root.resolve():
        raise ValueError('Reference must be a different, existing read-only tree')
    rows = []
    for ref in sorted((reference / 'lib').glob('libQt5*.so.5.15.19')):
        new = root / 'lib' / ref.name
        if not new.is_file():
            rows.append({'library': ref.name, 'missing_library': True})
            continue
        before, after = defined_symbols(ref), defined_symbols(new)
        removed, added = sorted(before - after), sorted(after - before)
        public_removed = [s for s in removed if '@Qt_5' in s and 'PRIVATE' not in s.upper()
                          and 'Private' not in s and not s.startswith('_ZTh')]
        rows.append({'library': ref.name, 'removed_defined': removed, 'added_defined': added,
                     'public_removed': public_removed,
                     'reference_version_needs': object_info(ref)['versions'],
                     'built_version_needs': object_info(new)['versions']})
    errors = ['Reference comparison found missing public definitions/libraries: ' + r['library']
              for r in rows if r.get('missing_library') or r.get('public_removed')]
    if not rows:
        errors.append('No Qt libraries in reference')
    return {'libraries': rows, 'errors': errors,
            'note': 'No UND symbols counted. Private ABI still requires matching headers and consumer tests.'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('abi', 'runtime', 'features', 'pc', 'record',
                                        'collect', 'manifest', 'tools-view', 'reference', 'subtree'))
    parser.add_argument('root', type=Path)
    parser.add_argument('target', choices=('aaw', 'aok', 'soa'))
    parser.add_argument('--report', type=Path)
    parser.add_argument('--source', type=Path)
    parser.add_argument('--destination', type=Path)
    parser.add_argument('--reference', type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    policy = json.loads((Path(__file__).resolve().parents[1] / 'config/policy.json').read_text())[args.target]
    effective = os.environ.get('EFFECTIVE_POLICY_FILE', '')
    if effective:
        document = json.loads(Path(effective).read_text())
        if document['target'] != args.target:
            raise ValueError('Effective policy belongs to another target')
        policy = document['policy']
    if args.mode == 'abi':
        result = check_abi(root, policy)
    elif args.mode == 'features':
        result = check_features(root, policy)
    elif args.mode == 'runtime':
        result = check_runtime(root)
    elif args.mode == 'pc':
        result = {'changed': fix_pc(root)}
    elif args.mode == 'record':
        if args.source is None or args.destination is None:
            parser.error('record requires --source and --destination')
        record(root, args.source, args.destination)
        result = {}
    elif args.mode == 'collect':
        result = collect_exports(root, args.target)
    elif args.mode == 'manifest':
        result = finalize_manifest(root, args.target)
    elif args.mode == 'tools-view':
        tools_view(root)
        result = {}
    elif args.mode == 'subtree':
        if args.source is None:
            parser.error('--source required')
        result = copy_subtree(root, args.source)
    else:
        if args.reference is None:
            parser.error('--reference required')
        result = compare_reference(root, args.reference)
    if args.report:
        write_json(args.report, result)
    for error in result.get('errors', []):
        print('ERROR: ' + error, file=sys.stderr)
    if result.get('errors'):
        return 1
    print('OK: {} {}'.format(args.mode, root))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, OSError, subprocess.SubprocessError) as error:
        print('ERROR: ' + str(error), file=sys.stderr)
        sys.exit(1)
