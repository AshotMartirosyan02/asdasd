#!/usr/bin/env python3
"""Prepare a staged vendor script; the repository source is never edited."""
import argparse
from pathlib import Path
import re

STAGES = ("checkTarball", "extract", "patch_it", "configIt", "injectStyle",
          "buildIt", "buildStyle", "installIt", "installStyle", "fixRpath")


def sub_once(text, pattern, replacement, label):
    count = len(re.findall(pattern, text, flags=re.M))
    if count != 1:
        raise ValueError("Expected exactly one " + label + "; found " + str(count))
    return re.sub(pattern, lambda _: replacement, text, flags=re.M)


def dependency_block(text, target):
    start = text.index("qtLicenseType='-commercial'")
    header = re.compile(r'^(?:if|elif)\s+\[\s+"?\$[{\(]?VCO[}\)]?"?\s*=\s*"' + target + r'"\s*\]', re.M)
    match = header.search(text, start)
    if not match:
        raise ValueError("Missing dependency block for " + target)
    end = re.search(r'^(?:elif\s|else\s*$)', text[match.end():], re.M)
    if not end:
        raise ValueError("Missing end of dependency block for " + target)
    return match.start(), match.end() + end.start()


def prepare(text, target):
    marker = '# qt-container-driver-v3 target=' + target
    if '# qt-container-driver-v3 target=' in text:
        if marker not in text or '-feature-cups' not in text:
            raise ValueError("Staged script belongs to another target/policy")
        return text
    for name in STAGES:
        text = sub_once(text, r"^" + name + r"=.*$", name + "=0", name)
    text = text.replace("/usr/mgc/peteoss/bin/python", "/build/tools/bin/python")
    text = sub_once(text, r"^tarBallPath=.*$", 'tarBallPath=$(dirname "$QT_TARBALL")', "tarball directory")
    text = sub_once(text, r"^tarBall=.*$", 'tarBall=$(basename "$QT_TARBALL")', "tarball filename")
    text = sub_once(text, r"^myGCC=.*$", 'myGCC=$(command -v gcc)', "compiler lookup")
    for compiler in ("/opt/rh/gcc-toolset-10/root/usr/bin/gcc",
                     "/opt/rh/gcc-toolset-13/root/usr/bin/gcc"):
        text = text.replace('"${myGCC}" != "' + compiler + '"', '"${myGCC}" != "${CC}"')
    text = text.replace("mkSpec='linux-aarch64-gnu-g++'", "mkSpec=linux-g++")
    text = text.replace("TargetSpec=linux-g++-64", "TargetSpec=${mkSpec}")
    text = text.replace("HostSpec=linux-g++-64", "HostSpec=${mkSpec}")
    text = text.replace('echo "Prefix=${INSTALL_ROOT}${installDir}"', 'echo "Prefix=.."')
    text = text.replace('echo "HostPrefix=${INSTALL_ROOT}${installDir}"', 'echo "HostPrefix=.."')

    def path_assignment(match):
        rhs = match[2]
        if rhs.startswith('"'):
            rhs = '"${QT_DRIVER_TOOLS}:' + rhs[1:]
        else:
            rhs = '${QT_DRIVER_TOOLS}:' + rhs
        return match[1] + rhs
    text = re.sub(r"^([ \t]*export PATH=)(.+)$", path_assignment, text, flags=re.M)
    text = sub_once(text, r"^[ \t]*-prefix\s+\$\{installDir\}\s*\\$",
                    '        -prefix "${INSTALL_ROOT%/}${installDir}" \\\n        -platform "${mkSpec}" \\',
                    "configure prefix")
    flags = '        -feature-cups \\\n'
    if target == 'aaw':
        flags += '        -no-feature-vulkan \\\n'
    text = sub_once(text, r'^[ \t]*-fontconfig\s*\\$', flags + '        -fontconfig \\',
                    'explicit feature policy')
    text = text.replace("gmake install", 'env -u INSTALL_ROOT gmake install')
    text = text.replace(chr(96) + "/home/icdet/bin/count_processors" + chr(96), '"${JOBS}"')
    text = text.replace("${QtDeclarativeTarBall}", "${QtStylePluginsTarBall}")

    start, end = dependency_block(text, target)
    block = text[start:end]
    block = re.sub(r'(^[ \t]*\w*(?:LibPath|IncludePath)="[^"\n]*?)[ \t]+"[ \t]*$',
                   r'\1"', block, flags=re.M)
    if target == "aok":
        for name, value in (("zlibIncludePath", "/build/shim/zlib/include"),
                            ("zlibLibPath", "/build/shim/zlib/lib64")):
            block = sub_once(block, r"^[ \t]*" + name + r"=.*$",
                             '    ' + name + '="' + value + '"', name)
        block = sub_once(block, r"^[ \t]*freetypeConfigs=.*$",
                         '    freetypeConfigs="FREETYPE_INCDIR=${freetypeIncludePath} FREETYPE_LIBDIR=${freetypeLibPath} FREETYPE_LIBS=-lfreetype"\n    freetypeLibs="-lfreetype"',
                         "AOK freetype flags")
        block = sub_once(block, r'^[ \t]*export LDFLAGS="-L\$\{sqliteLibPath\}.*$',
                         '    export LDFLAGS="-L${sqliteLibPath} -Wl,-rpath,${sqliteLibPath} ${LDFLAGS} -lrt -ldl"',
                         "AOK SQLite flags")
    elif target == "aaw":
        block = sub_once(block, r"^[ \t]*zlibIncludePath=.*$",
                         '    zlibIncludePath="${AAW_ZLIB_ROOT}/shared/pkgs/icv_zlib_inhouse.aaw/include"',
                         "AAW selected zlib headers")
        block = sub_once(block, r"^[ \t]*zlibLibPath=.*$",
                         '    zlibLibPath="${AAW_ZLIB_LIB}"', "AAW selected zlib library")
        block = sub_once(block, r"^[ \t]*mySql=.*$", '    mySql="-no-sql-mysql"', "AAW MySQL mode")
        block = sub_once(block, r"^[ \t]*freetypeLibs=.*$",
                         '    freetypeLibs="-lfreetype -lpng16"\n    export LDFLAGS="-L${AAW_PNG_LIB} -Wl,-rpath,${AAW_PNG_LIB} ${LDFLAGS}"',
                         "AAW PNG link path")
    text = text[:start] + block + text[end:]
    # Explicit failures are needed because the vendor script otherwise ignores
    # several tar/make/install/cd statuses and still prints SUCCESS.
    lines = []
    style_stage = False
    for line in text.splitlines():
        stage = re.match(r"^if \[ \$(\w+) -ne 0 \]", line)
        if stage and stage[1] in STAGES:
            style_stage = stage[1] in ("buildStyle", "installStyle")
        if style_stage and "env -u INSTALL_ROOT gmake install" in line:
            line = line.replace("gmake install", "gmake -k install")
        if re.match(r"^[ \t]*\$\{ECHO\}\s+(?:gmake\b|env -u INSTALL_ROOT gmake\b|tar\b|unzip\b|mkdir\b|mv\b|cd\b|\.\./qtbase/bin/qmake\b)", line):
            optional_style_make = style_stage and re.search(r"\bgmake\b", line)
            if not optional_style_make and not line.rstrip().endswith("\\") and "||" not in line:
                line = line.rstrip() + " || exit $?"
        lines.append(line)
    lines.insert(1, marker)
    text = "\n".join(lines) + "\n"
    return text


def patch_packaging(text, target, mysql_root):
    match = re.search(r"^(?:[ \t]*)(?:if|elsif)\s*\(\s*\$VCO\s+eq\s+'" + target + r"'\s*\)\s*\{", text, re.M)
    if not match:
        raise ValueError("Cannot find active packaging branch for " + target)
    end = text.find("\n", match.end())
    next_branch = re.search(r"^[ \t]*(?:elsif|else)\b", text[end:], re.M)
    stop = end + next_branch.start() if next_branch else len(text)
    block = text[match.start():stop]
    block = sub_once(block, r"^[ \t]*\$mySqlRoot\s*=.*?;[ \t]*$",
                     "        $mySqlRoot = '" + mysql_root + "';", "active MySQL assignment")
    return text[:match.start()] + block + text[stop:]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("build", "packaging"))
    parser.add_argument("path", type=Path)
    parser.add_argument("target", choices=("aok", "soa", "aaw"))
    parser.add_argument("--mysql-root")
    args = parser.parse_args()
    before = args.path.read_text()
    if args.mode == "build":
        after = prepare(before, args.target)
    else:
        if not args.mysql_root:
            parser.error("--mysql-root is required for packaging")
        after = patch_packaging(before, args.target, args.mysql_root)
    args.path.write_text(after)


if __name__ == "__main__":
    main()
