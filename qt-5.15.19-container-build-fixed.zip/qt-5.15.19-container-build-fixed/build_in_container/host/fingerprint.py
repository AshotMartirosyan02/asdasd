#!/usr/bin/env python3
import hashlib
import sys
from pathlib import Path


def fingerprint(root, identities):
    digest = hashlib.sha256()
    for value in identities:
        digest.update(value.encode() + b'\0')
    for directory in ('images', 'config', 'container'):
        for path in sorted((root / directory).rglob('*')):
            if not path.is_file() or '__pycache__' in path.parts:
                continue
            digest.update(str(path.relative_to(root)).encode() + b'\0')
            digest.update(path.read_bytes() + b'\0')
    return digest.hexdigest()


if __name__ == '__main__':
    print(fingerprint(Path(sys.argv[1]), sys.argv[2:]))
