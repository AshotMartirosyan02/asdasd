_ts(){ date -u '+%Y-%m-%dT%H:%M:%SZ'; }

section(){ printf '\n== %s ==\n' "$*"; }

info(){ printf '%s INFO  %s\n' "$(_ts)" "$*"; }
warn(){ printf '%s WARN  %s\n' "$(_ts)" "$*"; }
err(){  printf '%s ERROR %s\n' "$(_ts)" "$*" >&2; }
ok(){   printf '%s OK    %s\n' "$(_ts)" "$*"; }

fail(){ err "$*"; exit 1; }
