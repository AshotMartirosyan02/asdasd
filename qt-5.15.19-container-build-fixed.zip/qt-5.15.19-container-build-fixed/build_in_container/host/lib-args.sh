usage(){
    cat <<'HELP'
Usage: ./build-qt.sh [options] -aok|-soa|-aaw|-all
Targets can be combined in any order.

  --post-only        Finish an existing Qt install without recompiling it
  --rebuild-image    Rebuild the Docker image
  --cache            Allow Docker build cache when rebuilding an image
  --jobs N           Build parallelism (default: container CPU count)
  --build-user NAME  Container build account (default: cdtop)
  --install-root DIR  Override the install root for one target
  --no-remote        Require all targets to match the local architecture
  --no-sync          Use the existing remote source files
  --stop-after       Remove the container after success
  --dry-run          Print the plan without changing containers or files
  -h, --help         Show this help

A full build renames an existing installation just before installing the new
tree. Previous trees are retained as qt-5.15.19-prev-<timestamp>.
HELP
}
parse_args(){
    TARGETS=()
    FORWARD_ARGS=()
    INTERNAL_ONE=0
    DRY_RUN=0
    LOCAL_ONLY=0
    ALLOW_REMOTE=1
    SYNC_REMOTE=1
    REBUILD_IMAGE=0
    DOCKER_NO_CACHE=1
    STOP_AFTER=0
    POST_ONLY=0
    JOBS=""
    INSTALL_ROOT_OVERRIDE=""
    while [ $# -gt 0 ]; do
        case "$1" in
            -aok|--aok|aok) TARGETS+=(aok) ;;
            -soa|--soa|soa) TARGETS+=(soa) ;;
            -aaw|--aaw|aaw) TARGETS+=(aaw) ;;
            -all|--all|all) TARGETS+=(aok soa aaw) ;;
            --_run-one) INTERNAL_ONE=1 ;;
            --post-only) POST_ONLY=1; FORWARD_ARGS+=("$1") ;;
            --rebuild-image) REBUILD_IMAGE=1; FORWARD_ARGS+=("$1") ;;
            --cache) DOCKER_NO_CACHE=0; FORWARD_ARGS+=("$1") ;;
            --no-cache) DOCKER_NO_CACHE=1; FORWARD_ARGS+=("$1") ;;
            --stop-after) STOP_AFTER=1; FORWARD_ARGS+=("$1") ;;
            --dry-run) DRY_RUN=1; FORWARD_ARGS+=("$1") ;;
            --no-sync) SYNC_REMOTE=0; FORWARD_ARGS+=("$1") ;;
            --no-remote) ALLOW_REMOTE=0; FORWARD_ARGS+=("$1") ;;
            --local-only) LOCAL_ONLY=1; ALLOW_REMOTE=0; FORWARD_ARGS+=("$1") ;;
            --force) : ;;  # Compatibility: full builds already retain/replace the old tree.
            --jobs|--build-user|--install-root)
                [ $# -ge 2 ] && [ -n "$2" ] || fail "$1 requires a value"
                FORWARD_ARGS+=("$1" "$2")
                case "$1" in
                    --jobs) JOBS=$2 ;;
                    --build-user) BUILD_USER=$2 ;;
                    --install-root) INSTALL_ROOT_OVERRIDE=$2 ;;
                esac
                shift ;;
            -h|--help) usage; exit 0 ;;
            *) usage; fail "Unknown argument: $1" ;;
        esac
        shift
    done
    [ "${#TARGETS[@]}" -gt 0 ] || { usage; fail "No target selected"; }
    local t seen=" " unique=()
    for t in "${TARGETS[@]}"; do
        case "$seen" in *" $t "*) continue ;; esac
        seen+="$t "
        unique+=("$t")
    done
    TARGETS=("${unique[@]}")
    [ -z "$JOBS" ] || [[ "$JOBS" =~ ^[1-9][0-9]*$ ]] || fail "--jobs must be a positive integer"
    [[ "$BUILD_USER" =~ ^[a-zA-Z_][a-zA-Z0-9_.-]*$ ]] || fail "Invalid build user"
    [ "$BUILD_USER" != root ] || fail "Use an ordinary build account; the bootstrap handles root setup"
    [ "$POST_ONLY" = 0 ] || [ "$REBUILD_IMAGE" = 0 ] || fail "--post-only cannot be combined with --rebuild-image"
    if [ -n "$INSTALL_ROOT_OVERRIDE" ]; then
        [ "${#TARGETS[@]}" -eq 1 ] || fail "--install-root is for one target; use IIT_QT_ROOT for a multi-target base"
        case "$INSTALL_ROOT_OVERRIDE" in /*) ;; *) fail "--install-root must be absolute" ;; esac
        INSTALL_ROOT_OVERRIDE=${INSTALL_ROOT_OVERRIDE%/}
        [ -n "$INSTALL_ROOT_OVERRIDE" ] || fail "--install-root cannot be /"
    fi
    local p
    for p in "$QT_DIR" "$IIT_QT_ROOT" "$INSTALL_ROOT_OVERRIDE" "$QT_TARBALL"; do
        [[ "$p" != *[[:space:],\'\"]* ]] || fail "The vendor build script requires paths without whitespace, commas or quotes: $p"
    done
    case "$IIT_QT_ROOT" in /*) ;; *) fail "IIT_QT_ROOT must be absolute" ;; esac
    case "$QT_TARBALL" in /*) ;; *) fail "QT_TARBALL must be absolute" ;; esac
}
