#!/usr/bin/env python3
"""Produce an isolated mgc_home layout, without invoking mgc_server."""
import argparse
import json
import os
import re
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parent / 'container'))
from audit import (ENV, check_abi, check_features, check_links, check_runtime, elfs,
                   inside, object_info, sha, write_json)


def relative_link(link, target):
    link.symlink_to(os.path.relpath(str(target), str(link.parent)))


def patch(path, rpath, patchelf):
    fd, name = tempfile.mkstemp(prefix='.qt-package-', dir=str(path.parent))
    os.close(fd)
    temp = Path(name)
    try:
        shutil.copy2(str(path), str(temp))
        subprocess.check_call([patchelf, '--set-rpath', rpath, str(temp)], env=ENV)
        actual = subprocess.check_output([patchelf, '--print-rpath', str(temp)],
                                         env=ENV, universal_newlines=True).strip()
        if actual != rpath:
            raise ValueError('Package RPATH verification failed: ' + str(path))
        object_info(temp)
        os.replace(str(temp), str(path))
    finally:
        if temp.exists():
            temp.unlink()


def package(source, target, output, patchelf):
    if output.exists() or output.is_symlink():
        raise ValueError('Output must not exist; nothing overwritten: ' + str(output))
    if inside(output, source) or len(output.parts) < 3:
        raise ValueError('Unsafe output path')
    if not (source / 'runtime-manifest.json').is_file():
        raise ValueError('Source has no validated runtime manifest; run the full v3 driver first')
    policy = json.loads((Path(__file__).resolve().parent / 'config/policy.json').read_text())[target]
    if (source / 'build-policy.json').is_file():
        effective = json.loads((source / 'build-policy.json').read_text())
        if effective['target'] != target:
            raise ValueError('Source policy belongs to a different target')
        policy = effective['policy']
    for result in (check_abi(source, policy), check_features(source, policy), check_runtime(source)):
        if result['errors']:
            raise ValueError('\n'.join(result['errors']))
    output.mkdir(parents=True, exist_ok=False)
    sdk = output / 'shared/pkgs' / ('icv_qt5_comp_inhouse.' + target)
    runtime = output / 'pkgs' / ('icv_lib.' + target) / 'lib64'
    component = output / 'pkgs' / ('icv_qt5_comp.' + target)
    sdk.parent.mkdir(parents=True)
    subprocess.check_call(['cp', '-a', '--reflink=auto', str(source), str(sdk)])
    runtime.mkdir(parents=True)
    component.mkdir(parents=True)
    qmake_before = sha(sdk / 'bin/qmake')
    shipping = json.loads((Path(__file__).resolve().parent / 'config/packaging.json').read_text())
    for path in sorted((sdk / 'lib').iterdir()):
        if '.so' not in path.name or path.is_dir():
            continue
        module = re.match(r'libQt5(.+?)\.so(?:\.|$)', path.name)
        if module and module.group(1) not in shipping['public_qt_modules']:
            continue
        destination = runtime / path.name
        path.rename(destination)
        relative_link(path, destination)
    for name in ('plugins', 'qml'):
        path = sdk / name
        if path.is_dir():
            path.rename(component / name)
            relative_link(path, component / name)
    relative_link(component / 'lib', runtime)
    # qmake and all inhouse tools retain their normal SDK-relative paths.
    for path in elfs(output):
        if path == sdk / 'bin/qmake':
            continue
        info = object_info(path)
        if not info['needed'] and not info['soname']:
            continue
        entries = ['$ORIGIN']
        for directory in (runtime, sdk / 'lib'):
            relative = os.path.relpath(str(directory), str(path.parent))
            if relative != '.':
                entry = '$ORIGIN/' + relative
                if entry not in entries:
                    entries.append(entry)
        rpath = ':'.join(entries)
        patch(path, rpath, patchelf)
    if sha(sdk / 'bin/qmake') != qmake_before:
        raise ValueError('Packaging modified qmake')
    errors = check_links(output)
    results = {'abi': check_abi(output, policy), 'runtime': check_runtime(output)}
    for result in results.values():
        errors.extend(result['errors'])
    manifest = []
    for path in elfs(output):
        manifest.append(dict(path=str(path.relative_to(output)), sha256=sha(path), **object_info(path)))
    write_json(output / 'package-manifest.json', {'target': target, 'elfs': manifest, 'checks': results})
    if errors:
        raise ValueError('\n'.join(errors))
    print('OK: isolated package: ' + str(output))
    print('SDK: ' + str(sdk))
    return sdk


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--target', choices=('aok', 'soa', 'aaw'), required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--patchelf', default=shutil.which('patchelf'))
    args = parser.parse_args()
    if not args.patchelf:
        parser.error('Specify --patchelf /path/to/a/native/working/patchelf')
    package(args.source.resolve(), args.target, args.output.absolute(), args.patchelf)


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        print('ERROR: packaging: ' + str(error), file=sys.stderr)
        sys.exit(1)
