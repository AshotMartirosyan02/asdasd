# Qt 5.15.19 build driver v3.1

## Գործարկում

Ամբողջ արխիվի գլխավոր մուտքը վերևի build-qt.sh-ն է։
Այս build_in_container/ պանակը կարելի է նաև առանձին տեղադրել գործող Qt repository-ի մեջ ու այնտեղից գործարկել նույն հրամանը։

~~~bash
bash ./build-qt.sh -aok
bash ./build-qt.sh -soa
bash ./build-qt.sh -aaw
bash ./build-qt.sh -aok -aaw
bash ./build-qt.sh -soa -aaw
bash ./build-qt.sh -all
~~~

Target-ները կատարվում են տրված հերթականությամբ, կրկնությունները հանվում են։
Մեկի սխալը չի կասեցնում հաջորդը։ Ընդհանուր exit code-ը 0 է միայն բոլոր ընտրված target-ների հաջողության դեպքում։

| Target | Build baseline | Native architecture | SSH fallback | Նոր container |
|---|---|---|---|---|
| aok | RHEL 8 / GCC Toolset 10 | x86_64 | eiger | qtbuild-aok-v3 |
| soa | SLE 15.4 / GCC 10 | x86_64 | eiger | qtbuild-soa-v3 |
| aaw | RHEL 9 / glibc 2.34 / GCC Toolset 13 | aarch64 | cal-arm-19 | qtbuild-aaw-v3 |

Հին qtbuild-aok, qtbuild-soa, qtbuild-aaw container-ները default անուններով չեն փոխվում։
Լրիվ build-ի ժամանակ միայն նույն v3 container-ն է փոխարինվում՝ նախ պահպանելով դրա log/backups-ը։

## Մուտքեր և image-ներ

Գործող Qt repository-ում անհրաժեշտ են՝

- bin/buildQt-5.15.19, bin/qt-license, bin/makeQt5Pkg.pl։
- patches/5.15.19-patch և առկա vendor patch-երը։
- md5sums.txt՝ style archive-ի ճիշտ checksum-ով։

Default tarball-ները /wv/calibre_3rdparty/tarballs/Qt/ պանակում են՝
qt-everywhere-src-5.15.19.tar.xz և qtstyleplugins-master.zip։
Vendor source-ը փոփոխվում է միայն container-ի /build/qt պատճենում։

Host-ում պետք են Bash, Python 3, Docker, flock և sha256sum։
Remote build-ի համար՝ SSH և rsync երկու host-ում։
Ընկերության /wv, /user, /home/cqi export-երը պետք է հասանելի լինեն target host-ում։
Root bootstrap-ից հետո build-ը կատարվում է cdtop-ով։
Առկա cdtop-ի UID/GID-ը պահպանվում է՝ առանց մյուս target-ի թվային identity-ն պարտադրելու։
Միայն բացակայող account-ի ստեղծման default-ն է UID 108486, GID 6237։
Supplementary GIDs 6236 և 236-ը ավելացվում են՝ պահպանելով առկա խմբերը։
BUILD_USER, BUILD_UID, BUILD_GID, BUILD_GROUPS-ով կարելի է տալ այլ identity։
Հստակ BUILD_UID/BUILD_GID override-ը առկա account-ին չհամապատասխանելու դեպքում տալիս է բացատրությամբ սխալ։
NFS գրելու իրական իրավունքը ստուգվում է cdtop-ով write probe-ի միջոցով։

| Target | Default base | Նոր image |
|---|---|---|
| aok | aok:qt51519-ready | aok:qt51519-fixed-v3 |
| soa | soa:qt51519-ready | soa:qt51519-fixed-v3 |
| aaw | aaw:qt51519-ready | aaw:qt51519-rhel9-v3 |

Ներառված են images/Dockerfile, images/provision.sh և images/*.packages։
AOK/SOA/AAW-ն օգտագործում են գործող company base/toolchain-ը և ավելացնում պարտադիր SDK package-ները։
Բացակայող default ready base-ի համար օգտագործվում է նախկին oss-containers workflow-ը։
AAW-ի UBI8 տարբերակը հանված է․ վերջին log-ում դրա repository-ները չէին տրամադրում անհրաժեշտ 21 SDK package-ը։
Company base-ում արդեն կարգավորված, համապատասխան OS/architecture-ի CodeReady Builder repo-ն
միացվում է install հրամանի համար, եթե հայտնաբերվում է։ GPG/package ստուգումները չեն անջատվում։
Այլ, արդեն կարգավորված RHEL 9 company image կարելի է ընտրել այսպես՝

~~~bash
AAW_BASE_IMAGE=company/entitled-rhel9-aarch64:tag bash ./build-qt.sh -aaw
~~~

OS release-ը և architecture-ը ստուգվում են մինչև package installation-ը։
Provisioning-ը ցույց է տալիս ձախողված հրամանը և տողը, իսկ CUPS/compiler/identity-ի պակասը՝ առանձին սխալով։
Base image ID-ն, recipes/package lists-ը, target config-ը, policy/container code-ը և build identity-ն ընդգրկվում են fingerprint-ում։
Հին fingerprint-ով output tag-ը լրիվ build-ի ժամանակ վերակառուցվում է։
Տեղադրված RPM-երի փաստացի version/release/arch ցանկը գրանցվում է log-ում։
Սա image identity-ի վերահսկում է, ոչ տարբեր օրերի RPM mirror-ների byte-identical վերարտադրության խոստում։

## Հիմնական ուղղումները

- AOK՝ RHEL 8, SOA՝ SLE 15.4, AAW՝ RHEL 9։ CUPS-ը պարտադիր է երեք target-ի համար։
- Bundled dependency ստուգումը canonical ուղիներով է․ ../..-ը և in-tree symlink-ը ընդունվում են,
  բայց արտաքին կամ նույն անունով սխալ provider-ը մերժվում է։ Սա ընդհանուր ուղղում է երեք target-ի համար։
- AAW-ում Vulkan-ը configure-ով անջատված է, GTK2 subproject-ները հեռացվում են staged style build-ից։ GTK3-ը կուրորեն չի անջատվում։
- AAW-ն օգտագործում է native linux-g++ spec և եզակի compiler probe directory՝ առանց հին /tmp ֆայլերի բախման։
- patchelf-ը աշխատում է ժամանակավոր պատճենի վրա, ստուգում արդյունքը և միայն հետո փոխարինում ֆայլը։
  Ձախողման դեպքում փորձվում են մյուս native candidate-ները։ Հաջողը դառնում է ընթացիկը։
  PATCHELF_OVERRIDE-ը սահմանելու դեպքում օգտագործվում է միայն այդ գործիքը։
- qmake executable-ը պահվում է byte-for-byte pristine, առանց RPATH ավելացնելու։
- qt.conf prefix-ները relative են։ .pc-ի սեփական prefix/path դաշտերը relative են՝ ներառյալ Libs.private, եթե կա։
  Installed .prl-երից հանվում է QMAKE_PRL_BUILD_DIR-ը, որպեսզի կենդանի /build-ը չընտրվի consumer build-ի ժամանակ։
- AOK MySQL-ը մնում է el8, SOA MySQL-ը՝ sl15։ AAW MySQL-ը անջատված է։
- ABI scanner-ը կարդում է ELF version needs, ոչ version definitions։ Reference comparison-ը չի հաշվում UND symbols-ը։

## Runtime աղբյուրներ և priority

Runtime-ները canonical պատճենով պահվում են lib/ պանակում։
tools_lib/ պանակը դրանց relative compatibility aliases-ն է, ոչ երկրորդ անկախ binary family։
Այն առանձին մի պատճենիր՝ առանց ../lib-ի․ օգտագործիր ստորև նշված packager-ը։

AAW-ում վերականգնված են ICU-ի 6 families-ը, Freetype/PNG/zlib/libpq/SQLite,
double-conversion/gfortran, ECPG/pgtypes, SQLite compatibility entry-ն ու PostgreSQL subtree-ն։
Դրանք վերցվում են target-ի export-երից, ոչ moved reference tree-ից։
AOK-ում ավելացված է ընտրված zlib runtime-ը։
Երեք target-ում հավաքվում են նաև արդեն լուծված private-export dependencies-ը՝ առանց glibc/libstdc++ տեղափոխելու։
Architecture, SONAME, aliases և version requirements-ը ստուգվում են։

Default AAW zlib export-ը՝
/wv/cal_wg_server/ic/icv_zlib/exports.v1.2.13_2.28_20250605_engr-aaw/mgc_home։
AAW_ZLIB_ROOT կամ AOK_ZLIB_ROOT override-ը միաժամանակ կիրառվում է compile headers/libs-ի և bundling-ի վրա։

runtime-sources.json և runtime-manifest.json ֆայլերը գրանցում են source path/hash-ը,
target/architecture/SONAME/version needs-ը, installed hash/RUNPATH-ը և aliases-ը։
Source hash-ը պարտադիր չէ հավասար լինի patched file-ի hash-ին։
Միայն zlib-ի ֆայլի չափից տարբեր package-ի provenance չի եզրակացվում։

RUNPATH-ը $ORIGIN-relative է․ նախ սեփական/runtime directory-ն, հետո նախատեսված relative layout-ը։
System ABI/graphics/CUPS գրադարանները մնում են համակարգային։
Ստուգումները կատարվում են առանց inherited LD_LIBRARY_PATH, LD_PRELOAD, LD_AUDIT։
Արտաքին application launcher-ի LD_LIBRARY_PATH-ը կարող է գերակշռել RUNPATH-ին․ driver-ը չի կարող չեղարկել այդ launcher-ի որոշումը։
Պատահական absolute export priority-ն, հին broken Multimedia symlink-երը և չաշխատող qdoc-ը չեն կրկնօրինակվում։

## Reference և ABI

Driver-ը read-only reference է ընտրում ../<target>/qt-5.15.19-ից՝ Qt repository-ի նկատմամբ։
Քո AAW-ի դեպքում դա /wv/ashmarmo_nobackup/fix_container/final/aaw/qt-5.15.19-ն է։
Այլ path՝ AAW_REFERENCE_ROOT, AOK_REFERENCE_ROOT, SOA_REFERENCE_ROOT։
Reference-ը mount է արվում /opt/qt-reference՝ read-only։
Այն չի գործարկվում և չի օգտագործվում որպես runtime provider։

Reference-ի առկայության դեպքում GLIBC/GLIBCXX/CXXABI պահանջները չափվում են ամբողջ reference ELF tree-ից։
AOK/SOA-ի համար դրանք կիրառվում են որպես ceilings։ AOK-ի glibc-ը չի կարող գերազանցել 2.28-ը։
AAW-ի համար վերջին պահանջով ընտրված է RHEL 9՝ GLIBC 2.34 / GLIBCXX 3.4.29 / CXXABI 1.3.13 ceilings-ով։
Հին AAW reference-ի ցածր պահանջները պահպանվում են report-ում որպես համեմատություն՝ առանց դրանք
RHEL 9 build-ի վրա պարտադրելու։ Reference/build գրադարանների փաստացի version needs-ը report-ում առանձին են։
Reference-ի բացակայության fallback limits-ը բացահայտ գրված է config/policy.json-ում։
Դրանք compatibility policy են, ոչ չտրամադրված AOK/SOA reference-ի չափված տվյալներ։
Effective policy-ն պահպանվում է install-ում և log-երում։
Public defined-symbol կորուստը դադարեցնում է build-ը։
Private ABI-ի լիարժեք համարժեքություն միայն symbol list-ով չի հաստատվում։

## Պարտադիր վերջնական gates

Ստուգվում են architecture/ABI, prefix, Cleanlooks, CUPS, SQL, AOK/AAW EGL/X11 plugins,
bundled families, symlinks, unsafe RUNPATH-ները և clean-environment dependency resolution-ը։

Driver-ը compile/run է անում qmake, CMake և pkg-config consumer-ներ՝
QtCore/Widgets/Quick/QML/Sql/PrintSupport-ով։ Ստուգվում են Cleanlooks-ը,
CUPS plugin load-ը, SQLite in-memory operation-ը և PostgreSQL/MySQL driver load-ը՝ առանց DB connection-ի։
Նույն consumer-ները կրկնվում են relocated copy-ի և package preview-ի վրա։
/proc/self/maps-ով ստուգվում են նույն process-ի փաստացի providers-ը և duplicate SONAME mappings-ը։
Առանձին ldd կանչերի տարբերությունները ինքնին double-load չեն համարվում։

Սա headless smoke validation է, ոչ իրական printer/database server/hardware display-ի end-to-end թեստ։
qtdiag-ը մնում է optional։

## Փաթեթավորում

Build-ը ստեղծում և ստուգում է մեկուսացված package preview՝ container-ի /build/package-check.*/mgc_home-ում։
Հին makeQt5Pkg.pl-ը չի գործարկվում․ այն կարող է փոխել production staging-ը,
ստեղծել broken aliases և բաց թողնել նոր runtimes/EGL plugins-ը։
Դրա staged MySQL branch fix-ը պահպանվում է log-ում։

Նոր package-qt.py-ն ստեղծում է ամբողջական mgc_home layout՝

| Տվյալներ | Package path |
|---|---|
| Vendor-ի public Qt modules և bundled runtimes | pkgs/icv_lib.<target>/lib64 |
| Plugins և QML | pkgs/icv_qt5_comp.<target>/plugins, qml |
| bin/include/mkspecs/CMake/pkg-config, inhouse/static libraries | shared/pkgs/icv_qt5_comp_inhouse.<target> |

SDK-ից runtime/plugin պանակները հասանելի են relative aliases-ով։
Public module list-ը վերցված է տրամադրված vendor packager-ից՝ config/packaging.json։ Չթվարկված Qt modules-ը մնում են inhouse։
Debug companions-ը տեղափոխվում են իրենց libraries-ի հետ։
Packager-ը պատճենի RPATH-ները համապատասխանեցնում է layout-ին, ստուգում ABI/dependencies/symlinks-ը և գրում package-manifest.json։
Destination-ը պարտադիր նոր պանակ է․ առկան չի ջնջվում կամ վերագրվում։ mgc_server publication չի կատարվում։

Manual օրինակ՝ համապատասխան architecture-ի build container-ում՝

~~~bash
python3 /opt/qt-build-driver/package-qt.py \
  --source /wv/iit/qt/aaw/qt-5.15.19 --target aaw \
  --output /build/my-new-package/mgc_home \
  --patchelf /home/cqi/toolsets/rh8-arm/patchelf-0.18/bin/patchelf
~~~

## Ընտրանքներ և վերագործարկում

| Ընտրանք / env | Նշանակություն |
|---|---|
| --dry-run | Ոչ մի Docker/SSH գործողություն |
| --jobs N | Qt/style parallelism |
| --post-only | Պահպանված build-ի image/effective policy-ով tracked install-ի post-processing |
| --rebuild-image | Rebuild policy image, ոչ հին ready base-ի overwrite |
| --cache | Թույլատրել Docker cache, default՝ no-cache |
| --install-root DIR | Մեկ target-ի այլ writable install parent |
| IIT_QT_ROOT | Բոլոր target-ների այլ ընդհանուր install base |
| --no-remote | Միայն host architecture-ի target-ներ |
| --no-sync | Remote-ի արդեն առկա driver/repository ֆայլեր |
| REMOTE_QT_DIR | Remote repository-ի այլ absolute path |
| HOST_X86_64 / HOST_AARCH64 | Default eiger / cal-arm-19 |
| --stop-after | Հաջող ավարտից հետո հեռացնել v3 container-ը |

Full build-ը պահպանում է գործող install-ը compile-ի ընթացքում։
Միայն Qt/styles compile-ից հետո այն rename է անում qt-5.15.19-prev-<timestamp> անունով և կատարում install։
Install/post-validation failure-ի դեպքում backup-ը մնում է, container-ը՝ inspection-ի համար։
Ավտոմատ rollback կամ backup ջնջում չի կատարվում։
Նույն container/destination-ը միաժամանակ օգտագործող նույն operator-ի build-երը lock-ով արգելափակվում են։

Վերջին log-ի AOK build-ը շարունակելու համար՝

~~~bash
bash ./build-qt.sh -aok --post-only
~~~

Պահպանված qtbuild-aok-v3-ից վերցվում է իրական image ID-ն և դրա fingerprint-ը։
Նոր driver-ը պատճենվում է container-ի առանձին /build/qt-driver-<timestamp> պանակում,
ուստի ZIP-ը կարելի է բացել նաև այլ պանակում՝ հին driver mount-ը չփոխարինելով։
Qt compile/configure/install փուլերը բաց են թողնվում։ qmake-ի pristine backup-ը պահպանվում է։
Նախքան Qt tree-ի փոփոխությունը պարտադիր ստուգվում են OS-ը, image/installed-state համապատասխանությունը,
effective policy-ն, ABI-ն և features-ը։ Պարզ post-processing code fix-ը image rebuild չի պահանջում։
Փոխված effective policy-ն կամ հին untracked v2 tree-ը պահանջում է լրիվ build։
Նոր RHEL 9 AAW policy-ին անցնելու և SOA-ի image provisioning-ը վերագործարկելու համար՝

~~~bash
bash ./build-qt.sh -soa -aaw
~~~

Log-երը՝ build_in_container/logs/driver-*.log և logs/<target>-<stamp>/։
Remote մանրամասն log-երը մնում են remote repository-ի build_in_container/logs/ պանակում։
Consumer/provider/package/effective-policy reports-ը հավաքվում են container/logs/ տակ։
Relocation/package պատճենները մնում են container-ում inspection-ի համար։
Դրանց համար պետք է առնվազն ևս երկու install tree-ի չափ ազատ տարածք։

~~~bash
docker exec -it qtbuild-aok-v3 bash
ssh -t cal-arm-19 'docker exec -it qtbuild-aaw-v3 bash'
~~~

Տեղական թեստերը և չստուգված արտաքին միջավայրի սահմանները գրված են վերևի VALIDATION.md-ում։
