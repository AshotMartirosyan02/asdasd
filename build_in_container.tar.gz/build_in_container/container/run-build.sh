#!/usr/bin/bash
# =============================================================================
# In-container Qt 5.15.19 build orchestrator.
#   run-build.sh <aok|soa|aaw>
# Environment provided by the host driver:
#   QT_VERSION QT_TARBALL QT_REPO_DIR INSTALL_ROOT IIT_QT_ROOT FORCE_REPLACE
#   JOBS INSTALL_OWNER EGL_MODE (+ target specific)
# =============================================================================
set -Eeuo pipefail
export USER="${USER:-root}"
trap 'rc=$?; echo "ERROR: aborted (rc=$rc) at line $LINENO: $BASH_COMMAND" >&2' ERR

VCO="${1:-${VCO:-}}"
[ -n "$VCO" ] || { echo "usage: run-build.sh <aok|soa|aaw>" >&2; exit 2; }

CONTAINER_DIR=$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd -P)
BIC_DIR=$(cd "$CONTAINER_DIR/.." && pwd -P)

QT_VERSION="${QT_VERSION:-5.15.19}"
QT_SRC_DIRNAME="qt-everywhere-src-${QT_VERSION}"
QT_TARBALL="${QT_TARBALL:-/wv/calibre_3rdparty/tarballs/Qt/${QT_SRC_DIRNAME}.tar.xz}"
QT_REPO_DIR="${QT_REPO_DIR:-$(cd "$BIC_DIR/.." && pwd -P)}"
IIT_QT_ROOT="${IIT_QT_ROOT:-/wv/iit/qt}"
INSTALL_ROOT="${INSTALL_ROOT:-$IIT_QT_ROOT/$VCO}"
QT_ROOT="$INSTALL_ROOT/qt-$QT_VERSION"
JOBS="${JOBS:-$(nproc)}"
FORCE_REPLACE="${FORCE_REPLACE:-0}"
export VCO QT_VERSION QT_SRC_DIRNAME QT_TARBALL QT_REPO_DIR IIT_QT_ROOT INSTALL_ROOT QT_ROOT JOBS FORCE_REPLACE

case "$(uname -m)" in
    x86_64)  EXPECTED_ELF_ARCH='x86-64' ;;
    aarch64) EXPECTED_ELF_ARCH='ARM aarch64' ;;
    *) echo "ERROR: unsupported architecture $(uname -m)" >&2; exit 1 ;;
esac
export EXPECTED_ELF_ARCH

# shellcheck disable=SC1091
. "$CONTAINER_DIR/lib/common.sh"
# shellcheck disable=SC1091
. "$CONTAINER_DIR/lib/egl-x11.sh"
# shellcheck disable=SC1091
. "$CONTAINER_DIR/lib/rpath.sh"
# shellcheck disable=SC1091
. "$CONTAINER_DIR/lib/verify.sh"

[ -f "$CONTAINER_DIR/targets/$VCO.sh" ] || fail "Unknown target: $VCO"
# shellcheck disable=SC1090
. "$CONTAINER_DIR/targets/$VCO.sh"

section "Qt $QT_VERSION - $VCO container build"
echo "Host inside container: $(hostname)"
echo "Architecture:          $(uname -m)"
echo "Qt repository:         $QT_REPO_DIR"
echo "Install root:          $INSTALL_ROOT"
echo "Final tree:            $QT_ROOT"
echo "Parallel jobs:         $JOBS"

# ---- 1. preflight and workspace ---------------------------------------------
target_preflight
prepare_workspace
install_license
target_prepare_env

# ---- 2. buildQt preparation --------------------------------------------------
patch_buildqt_common
target_patch_buildqt
update_md5sums
guard_install_target

# ---- 3. unpack + vendor patches ---------------------------------------------
phase_prepare
detect_src_tree

# ---- 4. source level fixes ---------------------------------------------------
egl_probe
egl_patch_configure_json
python_generator_check

# ---- 5. configure ------------------------------------------------------------
phase_configure
egl_verify_summary
target_post_configure

# ---- 6. build / style / install ---------------------------------------------
phase_build_install
validate_install_basics
verify_install_prefix

# ---- 7. runtime bundling and packaging fixes --------------------------------
target_post_install
exclude_qdoc

# ---- 8. selective RPATH ------------------------------------------------------
select_patchelf
qmake_backup
patch_qt_libraries
target_patch_bundled
patch_plugins "\$ORIGIN:\$ORIGIN/../../lib:\$ORIGIN/../../../icv_lib/lib64:\$ORIGIN/../../../icv_lib.${VCO}/lib64"
patch_qml_plugins
patch_bootstrap_tools
patch_qt_executables
qmake_regression
target_post_rpath

# ---- 9. audits ---------------------------------------------------------------
audit_unsafe_rpaths
audit_missing_deps

# ---- 10. smoke tests ---------------------------------------------------------
build_smoke_test
target_extra_smoke
qtdiag_optional

# ---- 11. final gates ---------------------------------------------------------
final_validation
parity_report
apply_owner
final_summary
