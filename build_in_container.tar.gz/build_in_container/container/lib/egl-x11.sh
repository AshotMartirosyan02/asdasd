# shellcheck shell=bash
# GLVND-safe EGL/X11 configure test handling.
# EGL_MODE: require | auto | off

EGL_X11_ENABLED=0
EGL_PROBE_STATUS=disabled

egl_probe(){
    section "EGL/X11 toolchain preflight (mode: ${EGL_MODE:-off})"

    if [ "${EGL_MODE:-off}" = off ]; then
        echo "INFO: EGL/X11 disabled for this target"
        return 0
    fi

    local h headers_ok=1
    for h in /usr/include/EGL/egl.h /usr/include/X11/Xlib.h /usr/include/xcb/xcb.h; do
        if [ ! -f "$h" ]; then echo "MISSING header: $h"; headers_ok=0; fi
    done

    if [ "$headers_ok" = 1 ]; then
        mkdir -p /build/egl-probe
        cat > /build/egl-probe/probe.cpp <<'CPP'
#include <X11/Xlib.h>
#include <EGL/egl.h>
int main()
{
    Display *dpy = XOpenDisplay(0);
    EGLNativeDisplayType egl_dpy = (EGLNativeDisplayType)(unsigned long)dpy;
    Window w = dpy ? DefaultRootWindow(dpy) : (Window)0;
    EGLNativeWindowType egl_win = (EGLNativeWindowType)(unsigned long)w;
    EGLDisplay d = eglGetDisplay(egl_dpy);
    (void)egl_win; (void)d;
    return 0;
}
CPP
        if "$CXX" -o /build/egl-probe/probe /build/egl-probe/probe.cpp -lEGL -lX11 \
             > "$LOG_DIR/qt-${VCO}-egl-probe.log" 2>&1; then
            EGL_X11_ENABLED=1
            cat > /build/egl-probe/native.cpp <<'CPP'
#include <X11/Xlib.h>
#include <EGL/egl.h>
int main() { Display *dpy = EGL_DEFAULT_DISPLAY; (void)dpy; return 0; }
CPP
            if "$CXX" -fsyntax-only /build/egl-probe/native.cpp > /dev/null 2>&1; then
                EGL_PROBE_STATUS="native-x11-typedefs"
            else
                EGL_PROBE_STATUS="glvnd-opaque-typedefs (upstream egl-x11 test cannot pass unpatched)"
            fi
            ok "EGL/X11 probe: $EGL_PROBE_STATUS"
        else
            EGL_PROBE_STATUS="probe-failed"
            cat "$LOG_DIR/qt-${VCO}-egl-probe.log" || true
        fi
    else
        EGL_PROBE_STATUS="headers-missing"
    fi

    if [ "$EGL_X11_ENABLED" != 1 ]; then
        if [ "${EGL_MODE}" = require ]; then
            fail "EGL/X11 is mandatory for $VCO but unavailable ($EGL_PROBE_STATUS). Install libglvnd-devel/mesa-libEGL-devel, libX11-devel and libxcb-devel in the image, or set EGL_MODE=off."
        fi
        warn "continuing without EGL/X11 ($EGL_PROBE_STATUS)"
    fi
}

egl_patch_configure_json(){
    [ "$EGL_X11_ENABLED" = 1 ] || { section "Skipping EGL/X11 patch ($EGL_PROBE_STATUS)"; return 0; }

    section "Applying Qt $QT_VERSION EGL/X11 GLVND compatibility patch"
    "$PYTHON_BIN" - "$SRC_TREE" <<'PY_EGL'
from pathlib import Path
import sys

root = Path(sys.argv[1])
cfg = root / "qtbase/src/gui/configure.json"
if not cfg.is_file():
    raise SystemExit("ERROR: %s not found" % cfg)

text = cfg.read_text()
marker = '"egl-x11"'
i = text.find(marker)
if i < 0:
    raise SystemExit("ERROR: egl-x11 test not found in %s" % cfg)

def block(s, start):
    # returns (begin, end) of the balanced { } block starting at/after start
    b = s.index("{", start)
    depth = 0
    for k in range(b, len(s)):
        if s[k] == "{":
            depth += 1
        elif s[k] == "}":
            depth -= 1
            if depth == 0:
                return b, k + 1
    raise SystemExit("ERROR: unbalanced JSON block")

eb, ee = block(text, i)
entry = text[eb:ee]

NEW_TEST = """"test": {
                "include": [ "X11/Xlib.h", "EGL/egl.h" ],
                "main": [
                    "// GLVND safe: EGLNativeDisplayType/EGLNativeWindowType may be opaque",
                    "Display *dpy = XOpenDisplay(0);",
                    "EGLNativeDisplayType egl_dpy = (EGLNativeDisplayType)(unsigned long)dpy;",
                    "Window w = dpy ? DefaultRootWindow(dpy) : (Window)0;",
                    "EGLNativeWindowType egl_win = (EGLNativeWindowType)(unsigned long)w;",
                    "EGLDisplay disp = eglGetDisplay(egl_dpy);",
                    "(void)egl_win;",
                    "(void)disp;"
                ]
            }"""

if "GLVND safe" in entry:
    print("EGL/X11 patch already present; nothing to do")
else:
    ti = entry.find('"test"')
    if ti < 0:
        raise SystemExit('ERROR: "test" object not found inside egl-x11 entry')
    tb, te = block(entry, ti)
    entry = entry[:ti] + NEW_TEST + entry[te:]
    cfg.write_text(text[:eb] + entry + text[ee:])
    print("Patched %s" % cfg)

check = cfg.read_text()
ci = check.find(marker)
cb, ce = block(check, ci)
body = check[cb:ce]
for needle in ("GLVND safe", "X11/Xlib.h", "EGLNativeWindowType"):
    if needle not in body:
        raise SystemExit("ERROR: verification failed, %r missing from patched egl-x11 test" % needle)
print("EGL/X11 configure test verified")
PY_EGL

    sed -n '/GLVND safe/,+8p' "$SRC_TREE/qtbase/src/gui/configure.json"
}

egl_verify_summary(){
    [ "$EGL_X11_ENABLED" = 1 ] || return 0

    section "Verifying EGL/X11 configure results"
    local summary_ok=1
    _egl_check(){
        if grep -Eq "$1" "$CONFIG_LOG"; then echo "OK: $2"; else echo "MISSING: $2"; summary_ok=0; fi
    }
    _egl_check '^[[:space:]]*EGL[[:space:].]+yes'  'EGL .............. yes'
    _egl_check 'EGL on X11[[:space:].]+yes'        'EGL on X11 ........ yes'
    _egl_check 'EGLFS X11[[:space:].]+yes'         'EGLFS X11 ......... yes'
    _egl_check 'EGL-X11 Plugin[[:space:].]+yes'    'EGL-X11 Plugin .... yes'

    if [ "$summary_ok" -ne 1 ]; then
        grep -nE 'EGL|XCB|xcb' "$CONFIG_LOG" | tail -60 || true
        if [ "${EGL_MODE}" = require ]; then
            fail "EGL/X11 features are not enabled (probe: $EGL_PROBE_STATUS). Inspect $CONFIG_LOG."
        fi
        warn "EGL/X11 features not fully enabled; continuing because EGL_MODE=$EGL_MODE"
        EGL_X11_ENABLED=0
    fi
}

egl_reference_plugins_check(){
    local required=$1
    local rel missing=0
    local plugins=(
        plugins/egldeviceintegrations/libqeglfs-x11-integration.so
        plugins/xcbglintegrations/libqxcb-egl-integration.so
    )
    section "Checking EGL/X11 reference plugin parity"
    for rel in "${plugins[@]}"; do
        if [ -f "$QT_ROOT/$rel" ]; then
            ok "reference plugin present: $rel"
        else
            echo "MISSING: $rel"
            missing=$((missing + 1))
        fi
    done
    if [ "$missing" -ne 0 ]; then
        if [ "$required" = 1 ]; then
            fail "$missing EGL/X11 reference plugins are missing. Check the EGL/X11 configure summary in $CONFIG_LOG. Never copy plugins from another Qt tree."
        fi
        warn "missing EGL/X11 plugins accepted (not mandatory for this run)"
    fi
}
