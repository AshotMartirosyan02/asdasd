# shellcheck shell=bash
# Shared in-container helpers: workspace, buildQt staging, build phases.

ALL_STAGES=(checkTarball extract patch_it configIt injectStyle buildIt buildStyle installIt installStyle fixRpath)

section(){
    echo
    echo "============================================================"
    echo "$*"
    echo "============================================================"
}
fail(){ echo "ERROR: $*" >&2; exit 1; }
ok(){   echo "OK: $*"; }
warn(){ echo "WARNING: $*"; }
require_cmd(){ command -v "$1" >/dev/null 2>&1 || fail "Required command is missing: $1"; }

LOG_DIR=/build/logs
TOOLS_BIN=/build/tools/bin
BACKUP_DIR=/build/backups
DISABLED_DIR=/build/disabled-artifacts

# ---- default target hooks (targets override what they need) -----------------
target_preflight(){ :; }
target_prepare_env(){ :; }
target_patch_buildqt(){ :; }
target_post_configure(){ :; }
target_post_install(){ :; }
target_patch_bundled(){ :; }
target_post_rpath(){ :; }
target_extra_smoke(){ :; }
target_final_validation(){ :; }

# ---- workspace ---------------------------------------------------------------
prepare_workspace(){
    section "Preparing /build workspace"
    rm -rf /build/qt /build/logs /build/tools /build/backups /build/python-test \
           /build/disabled-artifacts /build/qt-smoke /build/egl-probe \
           /build/qmake-spec-test /build/shim /build/install
    mkdir -p /build/qt "$LOG_DIR" "$TOOLS_BIN" "$BACKUP_DIR/mkspecs" \
             /build/python-test "$DISABLED_DIR" /build/egl-probe

    [ -f "$QT_REPO_DIR/bin/buildQt-${QT_VERSION}" ] ||
        fail "buildQt-${QT_VERSION} not found in $QT_REPO_DIR"
    [ -f "$QT_REPO_DIR/bin/qt-license" ] || fail "qt-license not found in $QT_REPO_DIR"
    [ -f "$QT_REPO_DIR/md5sums.txt" ]    || fail "md5sums.txt not found in $QT_REPO_DIR"

    cp -a "$QT_REPO_DIR"/. /build/qt/
    rm -rf /build/qt/build_in_container/logs
    cd /build/qt

    BUILD_SCRIPT="bin/buildQt-${QT_VERSION}"
    cp -a "$BUILD_SCRIPT" "${BUILD_SCRIPT}.orig"
    export BUILD_SCRIPT
    ok "workspace prepared from $QT_REPO_DIR"
}

# Post-only runs reuse whatever is already in /build instead of wiping it.
prepare_workspace_light(){
    section "Post-only mode: reusing the existing /build workspace"
    mkdir -p "$LOG_DIR" "$TOOLS_BIN" "$BACKUP_DIR/mkspecs" /build/python-test \
             "$DISABLED_DIR" /build/egl-probe
    if [ -d /build/qt ]; then
        cd /build/qt
        BUILD_SCRIPT="bin/buildQt-${QT_VERSION}"
        export BUILD_SCRIPT
        ok "reusing the staged repository in /build/qt"
    else
        cd /build
        warn "/build/qt is gone (fresh container) - only the installed tree is reused"
    fi
}

install_license(){
    section "Installing Qt license"
    export QT_LICENSE_FILE=/build/qt/bin/qt-license
    # a post-only run in a fresh container has no staged copy yet
    [ -r "$QT_LICENSE_FILE" ] || QT_LICENSE_FILE="$QT_REPO_DIR/bin/qt-license"
    [ -r "$QT_LICENSE_FILE" ] || fail "Qt license is not readable: $QT_LICENSE_FILE"
    cp -f "$QT_LICENSE_FILE" "$HOME/.qt-license"
    chmod 600 "$HOME/.qt-license"
    ok "license installed for $(id -un) at $HOME/.qt-license"
}

create_python_wrapper(){
    section "Creating Python wrapper"
    local interp="${1:-}"
    if [ -z "$interp" ]; then
        interp=$(command -v python3.11 2>/dev/null || command -v python3 2>/dev/null) ||
            fail "No python3 interpreter found"
    fi
    cat > "$TOOLS_BIN/python" <<PYTHON_WRAPPER
#!/bin/sh
exec $interp "\$@"
PYTHON_WRAPPER
    chmod 755 "$TOOLS_BIN/python"
    export PATH="$TOOLS_BIN:$PATH"
    hash -r
    [ "$(command -v python)" = "$TOOLS_BIN/python" ] || fail "Python wrapper was not selected"

    local missing
    missing=$(ldd "$interp" 2>/dev/null | grep 'not found' || true)
    [ -z "$missing" ] || { echo "$missing"; fail "System Python has missing dependencies"; }

    PYTHON_BIN="$interp"
    export PYTHON_BIN
    ok "python -> $interp"
}

# ---- buildQt patching --------------------------------------------------------
patch_buildqt_common(){
    section "Patching $BUILD_SCRIPT (common rules)"

    sed -i "s|:/usr/mgc/peteoss/bin|:$TOOLS_BIN:/usr/mgc/peteoss/bin|g" "$BUILD_SCRIPT"
    sed -i "s|/usr/mgc/peteoss/bin/python|$TOOLS_BIN/python|g" "$BUILD_SCRIPT"

    # The generic RPATH loop destroys qmake - never let it run.
    sed -i -E 's/^fixRpath=.*/fixRpath=0/' "$BUILD_SCRIPT"
    grep -q '^fixRpath=0$' "$BUILD_SCRIPT" || fail "fixRpath was not disabled"

    # Only when the caller stages the build somewhere else than the real
    # deployment path do we rewrite hardcoded /wv/iit/qt/<vco>/ references.
    local default_root="$IIT_QT_ROOT/$VCO"
    if [ "$INSTALL_ROOT" != "$default_root" ]; then
        warn "Retargeting hardcoded $default_root/ -> $INSTALL_ROOT/"
        sed -i "s|$default_root/|$INSTALL_ROOT/|g" "$BUILD_SCRIPT"
    else
        ok "install root is the real deployment path: $INSTALL_ROOT"
    fi
}

update_md5sums(){
    section "Preparing Qt tarball checksum"
    [ -r "$QT_TARBALL" ] || fail "Qt tarball is missing: $QT_TARBALL"
    xz -t "$QT_TARBALL" || fail "Qt tarball integrity check failed"

    local md5
    md5=$(md5sum "$QT_TARBALL" | awk '{print $1}')
    grep -v "qt-everywhere-src-${QT_VERSION//./\\.}\.tar\.xz" md5sums.txt > /tmp/qt-md5sums.txt || true
    printf '%s  qt-everywhere-src-%s.tar.xz\n' "$md5" "$QT_VERSION" >> /tmp/qt-md5sums.txt
    mv -f /tmp/qt-md5sums.txt md5sums.txt
    grep "qt-everywhere-src-${QT_VERSION//./\\.}\.tar\.xz" md5sums.txt
    ok "md5sums.txt updated"
}

set_stage(){
    local name=$1 value=$2
    grep -qE "^${name}=" "$BUILD_SCRIPT" || fail "Stage variable was not found: $name"
    sed -i -E "s/^${name}=.*/${name}=${value}/" "$BUILD_SCRIPT"
}

# set_stages <enabled stages...>  - everything else is disabled, fixRpath forced 0
set_stages(){
    local s
    for s in "${ALL_STAGES[@]}"; do set_stage "$s" 0; done
    for s in "$@"; do set_stage "$s" 1; done
    set_stage fixRpath 0
    grep -nE "^($(IFS='|'; echo "${ALL_STAGES[*]}"))=" "$BUILD_SCRIPT"
}

# run_buildqt <label> <logfile-prefix>; sets LAST_LOG
run_buildqt(){
    local label=$1 prefix=$2 rc
    LAST_LOG="$LOG_DIR/qt-${VCO}-${prefix}-$(date +%Y%m%d-%H%M%S).out"

    section "$label"
    echo "Log: $LAST_LOG"

    set +e
    "$BUILD_SCRIPT" "$VCO" 2>&1 | tee "$LAST_LOG"
    rc=${PIPESTATUS[0]}
    set -e

    echo "$label return code: $rc"
    if [ "$rc" -ne 0 ]; then
        tail -150 "$LAST_LOG"
        fail "$label failed with rc=$rc (log: $LAST_LOG)"
    fi
    grep -q 'INFO --- SUCCESS!' "$LAST_LOG" || fail "$label log does not contain SUCCESS"
    ok "$label completed"
}

# ---- phases ------------------------------------------------------------------
phase_prepare(){
    set_stages checkTarball extract patch_it
    run_buildqt "Prepare phase (checkTarball, extract, patch)" prepare
    PREPARE_LOG="$LAST_LOG"
    grep -q 'Patch successful' "$PREPARE_LOG" || fail "Patch stage was not successful"
}

phase_configure(){
    set_stages configIt
    run_buildqt "Configure-only phase" configure
    CONFIG_LOG="$LAST_LOG"
    grep -q "Using install root of: $INSTALL_ROOT" "$CONFIG_LOG" ||
        fail "Configure used the wrong install root (expected $INSTALL_ROOT)"
    grep -q 'Qt is now configured for building' "$CONFIG_LOG" ||
        fail "Qt configure completion message was not found"
}

phase_build_install(){
    set_stages injectStyle buildIt buildStyle installIt installStyle
    grep -q '^fixRpath=0$' "$BUILD_SCRIPT" || fail "fixRpath must stay disabled"
    run_buildqt "Build, style and install phase" build
    BUILD_LOG="$LAST_LOG"
    grep -q 'skipping rpath fix step' "$BUILD_LOG" ||
        fail "Generic RPATH processing was not skipped"
}

# ---- source tree -------------------------------------------------------------
detect_src_tree(){
    section "Locating the extracted Qt source tree"
    local d
    for d in "/build/qt/${VCO}/${QT_SRC_DIRNAME}" "/build/qt/${QT_SRC_DIRNAME}"; do
        if [ -f "$d/qtbase/src/gui/configure.json" ]; then
            SRC_TREE="$d"; export SRC_TREE
            ok "source tree: $SRC_TREE"; return 0
        fi
    done
    while IFS= read -r d; do
        if [ -f "$d/qtbase/src/gui/configure.json" ]; then
            SRC_TREE="$d"; export SRC_TREE
            ok "source tree: $SRC_TREE"; return 0
        fi
    done < <(find /build/qt -maxdepth 4 -type d -name "$QT_SRC_DIRNAME" 2>/dev/null | sort)

    echo "Directories named $QT_SRC_DIRNAME under /build/qt:" >&2
    find /build/qt -maxdepth 4 -type d -name "$QT_SRC_DIRNAME" 2>/dev/null >&2 || true
    fail "No extracted Qt tree containing qtbase/src/gui/configure.json was found"
}

python_generator_check(){
    section "Python reference cleanup and generator validation"
    { grep -RIlZ '/usr/mgc/peteoss/bin/python' "$SRC_TREE" 2>/dev/null || true; } |
        xargs -0 -r sed -i "s|/usr/mgc/peteoss/bin/python|$TOOLS_BIN/python|g"

    local stale
    stale=$( { grep -RIl '/usr/mgc/peteoss/bin/python' "$SRC_TREE" 2>/dev/null || true; } | head -1 )
    [ -z "$stale" ] || fail "PeteOSS Python remains referenced: $stale"

    local gen="$SRC_TREE/qtdeclarative/src/3rdparty/masm/yarr/create_regex_tables"
    [ -f "$gen" ] || fail "Qt regex table generator is missing: $gen"
    rm -f /build/python-test/RegExpJitTables.h
    "$TOOLS_BIN/python" "$gen" > /build/python-test/RegExpJitTables.h
    [ -s /build/python-test/RegExpJitTables.h ] || fail "Qt Python generator produced an empty file"
    ok "python generator validation passed"
}

# ---- install destination -----------------------------------------------------
guard_install_target(){
    section "Preparing install destination"
    echo "Install root: $INSTALL_ROOT"
    echo "Qt root:      $QT_ROOT"

    mkdir -p "$INSTALL_ROOT" || fail "$(id -un) cannot create install root: $INSTALL_ROOT"
    assert_install_ownership "$INSTALL_ROOT"

    if [ -e "$QT_ROOT" ]; then
        if [ "${FORCE_REPLACE:-0}" = 1 ]; then
            local backup="$QT_ROOT-prev-$(date +%Y%m%d-%H%M%S)"
            warn "Existing installation renamed to $backup"
            mv "$QT_ROOT" "$backup"
        else
            fail "$QT_ROOT already exists. Re-run the driver with --force (the old tree is renamed, never deleted)."
        fi
    fi

    export INSTALL_ROOT
    ok "destination ready"
}

exclude_qdoc(){
    section "Excluding optional qdoc"
    [ ! -e "$QT_ROOT/bin/qdoc" ]       || mv "$QT_ROOT/bin/qdoc"       "$DISABLED_DIR/qdoc"
    [ ! -e "$QT_ROOT/bin/qdoc.debug" ] || mv "$QT_ROOT/bin/qdoc.debug" "$DISABLED_DIR/qdoc.debug"
    [ ! -e "$QT_ROOT/bin/qdoc" ]       || fail "qdoc remains in the install tree"
    [ ! -e "$QT_ROOT/bin/qdoc.debug" ] || fail "qdoc.debug remains in the install tree"
    ok "qdoc excluded"
}

# fix_packaging_mysql_path <perl-block-marker> <expected assignment>
fix_packaging_mysql_path(){
    local vco=$1 mysql_pkg=$2
    section "Correcting $vco packaging MySQL path"
    "$PYTHON_BIN" - "$vco" "$mysql_pkg" <<'PY_FIX_PACKAGING'
from pathlib import Path
import re, sys

vco, pkg = sys.argv[1], sys.argv[2]
path = Path("/build/qt/bin/makeQt5Pkg.pl")
text = path.read_text()

start = text.find("if ( $VCO eq '%s' )" % vco)
if start < 0:
    start = text.find("elsif ( $VCO eq '%s' )" % vco)
if start < 0:
    raise SystemExit("ERROR: packaging block for %s was not found" % vco)

candidates = [x for x in (text.find("elsif ( $VCO eq '", start + 1),
                          text.find("\nelse", start + 1)) if x >= 0]
end = min(candidates) if candidates else len(text)
block = text[start:end]

expected = "$mySqlRoot = '%s';" % pkg
block, count = re.subn(
    r"\$mySqlRoot\s*=\s*'\s*[^']*mysql-commercial-[^']*';",
    expected.replace("\\", "\\\\"),
    block,
    count=1,
)
if count != 1 and expected not in block:
    raise SystemExit("ERROR: MySQL packaging assignment for %s was not found" % vco)

path.write_text(text[:start] + block + text[end:])
print("Updated %s MySQL packaging path -> %s" % (vco, pkg))
PY_FIX_PACKAGING

    grep -A4 -B1 "VCO eq '$vco'" /build/qt/bin/makeQt5Pkg.pl | grep -q "$mysql_pkg" ||
        fail "$vco packaging script does not use $mysql_pkg"
    ok "packaging MySQL path verified"
}

# bundle_library <source-file> <destination-basename> [extra symlink...]
bundle_library(){
    local src=$1 base=$2; shift 2
    [ -f "$src" ] || fail "Runtime library is missing: $src"
    cp -f "$src" "$QT_ROOT/lib/$base"
    chmod u+rw,go+r "$QT_ROOT/lib/$base"
    local l
    for l in "$@"; do ln -sfn "$base" "$QT_ROOT/lib/$l"; done
}

# copy_family <dir> <glob> <description> - copies real files and their symlinks
copy_family(){
    local src_dir=$1 pattern=$2 description=$3
    local found=0 src
    [ -d "$src_dir" ] || fail "$description source directory is missing: $src_dir"
    for src in "$src_dir"/$pattern; do
        if [ -e "$src" ] || [ -L "$src" ]; then
            echo "Copying $description: $src"
            cp -f "$src" "$QT_ROOT/lib/" 
            chmod u+rw,go+r "$QT_ROOT/lib/"
            found=1
        fi
    done
    [ "$found" -eq 1 ] || fail "No $description files matched $src_dir/$pattern"
}

# =============================================================================
# Permission helpers
#
# Libraries copied out of the read-only /wv and /user export areas arrive with
# mode 0555. As root that was invisible; as the unprivileged build user
# patchelf fails with "open: Permission denied". Everything that rewrites a
# file in the install tree goes through these helpers.
# =============================================================================

# make_writable <file> - add the owner write bit when it is missing
make_writable(){
    local f=$1
    [ -e "$f" ] || fail "cannot make a missing file writable: $f"
    [ -w "$f" ] && return 0
    chmod u+w "$f" 2>/dev/null ||
        fail "cannot add write permission to $f (owner $(stat -c '%U' "$f" 2>/dev/null), mode $(stat -c '%A' "$f" 2>/dev/null))"
    [ -w "$f" ] || fail "still not writable after chmod: $f"
}

# patchelf_set_rpath <file> <rpath> - the only sanctioned way to set an RPATH
patchelf_set_rpath(){
    local f=$1 rpath=$2
    make_writable "$f"
    patchelf_set_rpath "$f" "$rpath"
}

# normalise_tree_permissions <root>
# Run once after install + bundling, before any RPATH work: make every regular
# file writable by its owner (so patchelf can rewrite it) while keeping the
# tree readable and executable for everybody who consumes /wv/iit/qt.
normalise_tree_permissions(){
    local root=$1
    [ -d "$root" ] || fail "cannot normalise a missing tree: $root"
    section "Normalising permissions under $root"
    find "$root" -type d -exec chmod u+rwx,go+rx {} + 2>/dev/null || true
    find "$root" -type f -exec chmod u+rw,go+r {} + 2>/dev/null || true
    find "$root" -type f \( -name '*.so' -o -name '*.so.*' \) -exec chmod a+x {} + 2>/dev/null || true
    local not_writable
    not_writable=$(find "$root" -type f ! -writable -print -quit 2>/dev/null || true)
    [ -z "$not_writable" ] || fail "still not writable after normalisation: $not_writable"
    echo "OK: every file under $root is writable by $(id -un)"
}
