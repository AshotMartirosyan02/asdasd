# shellcheck shell=bash
# Post-install validation: bundled runtimes, dependencies, smoke tests, parity.

validate_install_basics(){
    section "Validating installed Qt tree"
    [ -d "$QT_ROOT" ] || fail "Qt install tree was not created: $QT_ROOT"
    [ -x "$QT_ROOT/bin/qmake" ] || fail "Installed qmake is missing"
    [ -f "$QT_ROOT/lib/libQt5Core.so.${QT_VERSION}" ] || fail "Installed Qt5Core is missing"

    file "$QT_ROOT/bin/qmake"
    file "$QT_ROOT/lib/libQt5Core.so.${QT_VERSION}"
    file "$QT_ROOT/bin/qmake" | grep -q "$EXPECTED_ELF_ARCH" ||
        fail "Installed qmake is not $EXPECTED_ELF_ARCH"
    file "$QT_ROOT/lib/libQt5Core.so.${QT_VERSION}" | grep -q "$EXPECTED_ELF_ARCH" ||
        fail "Installed Qt5Core is not $EXPECTED_ELF_ARCH"
    ok "install tree looks sane"
}

verify_install_prefix(){
    section "Verifying baked-in installation prefix"
    local prefix bins libs
    prefix=$("$QT_ROOT/bin/qmake" -query QT_INSTALL_PREFIX)
    bins=$("$QT_ROOT/bin/qmake" -query QT_INSTALL_BINS)
    libs=$("$QT_ROOT/bin/qmake" -query QT_INSTALL_LIBS)
    echo "QT_INSTALL_PREFIX = $prefix"
    echo "QT_INSTALL_BINS   = $bins"
    echo "QT_INSTALL_LIBS   = $libs"
    [ "$prefix" = "$QT_ROOT" ] ||
        fail "qmake prefix ($prefix) does not match the deployment path ($QT_ROOT)"
    case "$bins" in "$QT_ROOT"/*) ;; *) fail "QT_INSTALL_BINS points outside $QT_ROOT" ;; esac
    case "$libs" in "$QT_ROOT"/*) ;; *) fail "QT_INSTALL_LIBS points outside $QT_ROOT" ;; esac
    ok "prefix matches the real deployment path"
}

# validate_bundled_families <glob...>
validate_bundled_families(){
    [ "$#" -gt 0 ] || return 0
    section "Validating bundled runtime families"

    local pat link target dangling=0
    for pat in "$@"; do
        while IFS= read -r -d '' link; do
            target=$(readlink -f "$link" || true)
            if [ -z "$target" ] || [ ! -f "$target" ]; then
                echo "DANGLING: $link"; dangling=$((dangling + 1)); continue
            fi
            case "$target" in
                "$QT_ROOT"/lib/*) ;;
                *) echo "OUTSIDE-TREE: $link -> $target"; dangling=$((dangling + 1)) ;;
            esac
        done < <(find "$QT_ROOT/lib" -maxdepth 1 -type l -name "$pat" -print0)
    done
    [ "$dangling" -eq 0 ] || fail "$dangling bundled symlinks are dangling or point outside the Qt tree"
    ok "all bundled symlinks resolve inside $QT_ROOT/lib"

    local f desc soname find_args=()
    for pat in "$@"; do find_args+=(-o -name "$pat"); done
    while IFS= read -r -d '' f; do
        desc=$(file "$f")
        echo "$desc"
        echo "$desc" | grep -q "$EXPECTED_ELF_ARCH" || fail "Bundled library is not $EXPECTED_ELF_ARCH: $f"
        soname=$(readelf -d "$f" | awk -F'[][]' '/SONAME/{print $2;exit}')
        [ -n "$soname" ] || fail "Bundled library has no SONAME: $f"
        [ -e "$QT_ROOT/lib/$soname" ] || fail "SONAME link is missing for $f: $soname"
    done < <(find "$QT_ROOT/lib" -maxdepth 1 -type f \( -false "${find_args[@]}" \) ! -name '*.debug' -print0)
    ok "bundled architectures and SONAMEs verified"
}

audit_missing_deps(){
    section "Recursive dependency audit"
    audit_dirs
    MISSING_LOG="$LOG_DIR/qt-${VCO}-missing-dependencies.log"
    : > "$MISSING_LOG"

    local f missing
    while IFS= read -r -d '' f; do
        file "$f" | grep -Eq 'ELF .* (shared object|dynamically linked)' || continue
        missing=$(LD_LIBRARY_PATH="$QT_ROOT/lib" ldd "$f" 2>/dev/null | grep 'not found' || true)
        if [ -n "$missing" ]; then
            { echo "===== $f"; echo "$missing"; echo; } >> "$MISSING_LOG"
        fi
    done < <(find "${AUDIT_DIRS[@]}" -type f ! -name '*.debug' -print0)

    if [ -s "$MISSING_LOG" ]; then
        cat "$MISSING_LOG"
        fail "Runtime dependency audit failed (see $MISSING_LOG)"
    fi
    ok "no missing runtime dependencies"
    export MISSING_LOG
}

# expect_bundled <file> <soname>
expect_bundled(){
    local f=$1 soname=$2 path
    path=$(LD_LIBRARY_PATH="$QT_ROOT/lib" ldd "$f" | awk -v n="$soname" '$1==n{print $3;exit}')
    case "$path" in
        "$QT_ROOT"/lib/*) echo "bundled: $soname -> $path" ;;
        "") echo "INFO: $(basename "$f") does not link $soname" ;;
        *) fail "$(basename "$f") does not resolve bundled $soname: $path" ;;
    esac
}

build_smoke_test(){
    section "Building mandatory QtCore smoke test"
    MAKE_TOOL=$(command -v gmake || command -v make) || fail "Neither gmake nor make is available"

    rm -rf /build/qt-smoke
    mkdir -p /build/qt-smoke
    cd /build/qt-smoke

    cat > main.cpp <<'CPP_SMOKE'
#include <QCoreApplication>
#include <QDebug>
#include <QtGlobal>

int main(int argc, char **argv)
{
    QCoreApplication app(argc, argv);
    qInfo() << "Qt runtime version:" << qVersion();
    qInfo() << "Application directory:" << app.applicationDirPath();
    return 0;
}
CPP_SMOKE

    cat > smoke.pro <<'QMAKE_SMOKE'
QT += core
QT -= gui
CONFIG += console
CONFIG -= app_bundle
SOURCES += main.cpp
QMAKE_SMOKE

    "$QT_ROOT/bin/qmake" smoke.pro
    "$MAKE_TOOL" -j"$JOBS"

    file ./smoke | tee "$LOG_DIR/qt-${VCO}-smoke-file.log"
    file ./smoke | grep -q "$EXPECTED_ELF_ARCH" || fail "Smoke executable is not $EXPECTED_ELF_ARCH"
    LD_LIBRARY_PATH="$QT_ROOT/lib" ./smoke
    ok "QtCore smoke test passed"
}

qtdiag_optional(){
    section "Optional offscreen qtdiag test"
    QTDIAG_RC=not-run
    if [ -x "$QT_ROOT/bin/qtdiag" ]; then
        set +e
        env -u QT_PLUGIN_PATH LD_LIBRARY_PATH="$QT_ROOT/lib" QT_QPA_PLATFORM=offscreen \
            QT_OPENGL=software LIBGL_ALWAYS_SOFTWARE=1 QT_DEBUG_PLUGINS=1 \
            "$QT_ROOT/bin/qtdiag" > "$LOG_DIR/qt-${VCO}-qtdiag-offscreen.log" 2>&1
        QTDIAG_RC=$?
        set -e
        if [ "$QTDIAG_RC" -eq 0 ]; then
            ok "qtdiag offscreen passed"
            head -60 "$LOG_DIR/qt-${VCO}-qtdiag-offscreen.log"
        else
            warn "optional qtdiag offscreen failed with rc=$QTDIAG_RC (non-blocking)"
            tail -40 "$LOG_DIR/qt-${VCO}-qtdiag-offscreen.log" || true
        fi
    else
        echo "INFO: qtdiag is not installed; optional test skipped"
    fi
    export QTDIAG_RC
}

# Compare the new tree with the most recent previous install of the same VCO.
parity_report(){
    section "Parity check against previous installations"
    REFERENCE_INSTALL=""
    local d
    for d in $(ls -1d "$INSTALL_ROOT"/qt-5.* 2>/dev/null | sort -V); do
        [ "$d" = "$QT_ROOT" ] && continue
        case "$d" in *-orig|*-DEL|*-prev-*|*-v1) continue ;; esac
        [ -x "$d/bin/qmake" ] || continue
        REFERENCE_INSTALL="$d"
    done

    if [ -z "$REFERENCE_INSTALL" ]; then
        warn "no previous installation found under $INSTALL_ROOT - skipping parity report"
        return 0
    fi
    echo "Reference installation: $REFERENCE_INSTALL"

    local entry
    for entry in $(ls -1 "$REFERENCE_INSTALL"); do
        if [ ! -e "$QT_ROOT/$entry" ]; then
            warn "top-level entry present in reference but missing here: $entry"
        fi
    done

    local report="$LOG_DIR/qt-${VCO}-parity.log"
    {
        echo "# reference: $REFERENCE_INSTALL"
        echo "# new:       $QT_ROOT"
        echo
        echo "## qmake -query (paths normalised to <PREFIX>)"
        diff -u \
            <("$REFERENCE_INSTALL/bin/qmake" -query 2>/dev/null | sed "s|$REFERENCE_INSTALL|<PREFIX>|g") \
            <("$QT_ROOT/bin/qmake" -query 2>/dev/null | sed "s|$QT_ROOT|<PREFIX>|g") || true
        echo
        echo "## top level entries"
        diff -u <(ls -1 "$REFERENCE_INSTALL") <(ls -1 "$QT_ROOT") || true
    } > "$report"

    echo "Parity report: $report"
    sed -n '1,60p' "$report"
    ok "parity report written (differences above are informational)"
}

apply_owner(){
    [ -n "${INSTALL_OWNER:-}" ] || return 0
    if [ "$(id -u)" != 0 ]; then
        warn "--owner ignored: the build runs as $(id -un), the tree is already owned correctly"
        return 0
    fi
    section "Applying ownership $INSTALL_OWNER"
    chown -R "$INSTALL_OWNER" "$QT_ROOT" || fail "chown failed"
    ok "ownership applied"
}

final_validation(){
    section "Final mandatory validation"
    local rpath sha
    rpath=$("$PATCHELF" --print-rpath "$QT_ROOT/bin/qmake")
    [ -z "$rpath" ] || fail "qmake has unexpected RPATH"
    cmp -s "$QT_ROOT/bin/qmake" "$BACKUP_DIR/qmake.pristine" || fail "qmake differs from pristine backup"
    sha=$(sha256sum "$QT_ROOT/bin/qmake" | awk '{print $1}')
    [ "$sha" = "$QMAKE_SHA256_BEFORE" ] || fail "qmake SHA-256 changed"
    [ ! -s "$MISSING_LOG" ]      || fail "Missing runtime dependencies remain"
    [ ! -s "$UNSAFE_RPATH_LOG" ] || fail "Unsafe RPATHs remain"
    LD_LIBRARY_PATH="$QT_ROOT/lib" /build/qt-smoke/smoke || fail "Mandatory QtCore smoke test failed"
    verify_install_ownership
    target_final_validation
    ok "all mandatory checks passed"
}

final_summary(){
    section "Final result"
    echo "Target:                 $VCO"
    echo "Build user:             $(id -un) (uid=$(id -u))"
    echo "Architecture:           $(uname -m)"
    echo "Prepare log:            ${PREPARE_LOG:-n/a}"
    echo "Configure log:          ${CONFIG_LOG:-n/a}"
    echo "Build log:              ${BUILD_LOG:-n/a}"
    echo "Extracted source tree:  ${SRC_TREE:-n/a}"
    echo "Install root:           $INSTALL_ROOT"
    echo "Qt root:                $QT_ROOT"
    echo "EGL/X11:                mode=${EGL_MODE:-off} enabled=${EGL_X11_ENABLED:-0} probe=${EGL_PROBE_STATUS:-n/a}"
    echo "patchelf:               ${PATCHELF:-n/a}"
    echo "qmake SHA-256:          ${QMAKE_SHA256_BEFORE:-n/a}"
    echo "Dependency log:         ${MISSING_LOG:-n/a}"
    echo "Unsafe RPATH log:       ${UNSAFE_RPATH_LOG:-n/a}"
    echo "Reference install:      ${REFERENCE_INSTALL:-none}"
    echo "Optional qtdiag rc:     ${QTDIAG_RC:-not-run}"
    echo
    echo "SUCCESS: $VCO Qt $QT_VERSION build installed in $QT_ROOT"
    echo "NOTE: qtdiag offscreen is optional; rc=${QTDIAG_RC:-not-run}"
}

# assert_tree_writable <root> - guards against a half-normalised tree
assert_tree_writable(){
    local root=$1 offender
    offender=$(find "$root" -type f ! -writable -print -quit 2>/dev/null || true)
    [ -z "$offender" ] || fail "file is not writable by $(id -un): $offender"
    echo "OK: install tree is fully owner-writable"
}
