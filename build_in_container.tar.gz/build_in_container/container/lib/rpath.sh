# shellcheck shell=bash
# Selective RPATH processing. qmake and *.debug are never touched.

QT_LIBRARY_RPATH='$ORIGIN:$ORIGIN/../lib'
QT_BIN_RPATH='$ORIGIN:$ORIGIN/../lib'
BOOTSTRAP_TOOLS=(moc rcc tracegen qcollectiongenerator)

select_patchelf(){
    section "Selecting patchelf"
    local candidate
    local candidates=()
    case "$(uname -m)" in
        x86_64)
            candidates=(
                /home/cqi/toolsets/rh8-x86_64/patchelf-0.17.2/bin/patchelf
                /home/cqi/toolsets/sles15-x86_64/patchelf-0.17.0/bin/patchelf
                /usr/bin/patchelf
            ) ;;
        aarch64)
            candidates=(
                /home/cqi/toolsets/rh9-aarch64/patchelf-0.18/bin/patchelf
                /home/cqi/toolsets/rh9-aarch64/patchelf-0.17.2/bin/patchelf
                /home/cqi/toolsets/rh8-arm/patchelf-0.18/bin/patchelf
                /usr/bin/patchelf
            ) ;;
    esac
    [ -n "${PATCHELF_OVERRIDE:-}" ] && candidates=("$PATCHELF_OVERRIDE" "${candidates[@]}")

    PATCHELF=""
    for candidate in "${candidates[@]}"; do
        [ -x "$candidate" ] || continue
        "$candidate" --version >/dev/null 2>&1 || continue
        if file "$candidate" | grep -q "$EXPECTED_ELF_ARCH"; then
            PATCHELF="$candidate"
            break
        fi
    done
    [ -n "$PATCHELF" ] || fail "No working patchelf for $(uname -m) was found"
    export PATCHELF
    echo "PATCHELF=$PATCHELF"
    "$PATCHELF" --version
}

qmake_backup(){
    section "Validating and backing up pristine qmake"
    "$QT_ROOT/bin/qmake" -v
    "$QT_ROOT/bin/qmake" -query

    QMAKE_RPATH=$("$PATCHELF" --print-rpath "$QT_ROOT/bin/qmake")
    printf 'Pristine qmake RPATH: <%s>\n' "$QMAKE_RPATH"
    [ -z "$QMAKE_RPATH" ] || fail "Pristine qmake unexpectedly has RPATH"

    cp -a "$QT_ROOT/bin/qmake" "$BACKUP_DIR/qmake.pristine"
    QMAKE_SHA256_BEFORE=$(sha256sum "$QT_ROOT/bin/qmake" | awk '{print $1}')
    export QMAKE_SHA256_BEFORE
    echo "Pristine qmake SHA-256: $QMAKE_SHA256_BEFORE"
}

patch_qt_libraries(){
    section "RPATH: Qt shared libraries"
    local f
    while IFS= read -r -d '' f; do
        file "$f" | grep -q 'ELF .*shared object' || continue
        echo "Patching Qt library: $f"
        patchelf_set_rpath "$f" "$QT_LIBRARY_RPATH"
    done < <(find "$QT_ROOT/lib" -type f -name "libQt5*.so.${QT_VERSION}" ! -name '*.debug' -print0)
}

# patch_plugins <rpath>
patch_plugins(){
    section "RPATH: Qt plugins"
    local rp=$1 f
    while IFS= read -r -d '' f; do
        file "$f" | grep -q 'ELF .*shared object' || continue
        echo "Patching plugin: $f"
        patchelf_set_rpath "$f" "$rp"
    done < <(find "$QT_ROOT/plugins" -type f -name '*.so' ! -name '*.debug' -print0)
}

patch_qml_plugins(){
    [ -d "$QT_ROOT/qml" ] || return 0
    section "RPATH: QML plugins"
    local f dir rel depth up i qml_rpath
    while IFS= read -r -d '' f; do
        file "$f" | grep -q 'ELF .*shared object' || continue
        dir=${f%/*}
        rel=${dir#"$QT_ROOT"/}
        depth=$(awk -F/ '{print NF}' <<< "$rel")
        up=""
        i=0
        while [ "$i" -lt "$depth" ]; do up="${up}../"; i=$((i + 1)); done
        qml_rpath="\$ORIGIN:\$ORIGIN/${up}lib:\$ORIGIN/${up}../icv_lib/lib64:\$ORIGIN/${up}../icv_lib.${VCO}/lib64"
        echo "Patching QML plugin: $f -> $qml_rpath"
        patchelf_set_rpath "$f" "$qml_rpath"
    done < <(find "$QT_ROOT/qml" -type f -name '*.so' ! -name '*.debug' -print0)
}

patch_bootstrap_tools(){
    section "RPATH: bootstrap tools"
    local name f
    for name in "${BOOTSTRAP_TOOLS[@]}"; do
        f="$QT_ROOT/bin/$name"
        [ -x "$f" ] || fail "Required bootstrap tool is missing: $f"
        file "$f" | grep -q 'ELF .*dynamically linked' || fail "Bootstrap tool is not a dynamic ELF: $f"
        echo "Patching bootstrap tool: $f"
        patchelf_set_rpath "$f" "$QT_BIN_RPATH"
    done
}

patch_qt_executables(){
    section "RPATH: Qt executables (qmake excluded)"
    local f
    while IFS= read -r -d '' f; do
        file "$f" | grep -q 'ELF .*dynamically linked' || continue
        readelf -d "$f" 2>/dev/null | grep -q 'Shared library: \[libQt5' || continue
        echo "Patching Qt executable: $f"
        patchelf_set_rpath "$f" "$QT_BIN_RPATH"
    done < <(find "$QT_ROOT/bin" -type f ! -name qmake ! -name 'qmake.*' ! -name '*.debug' -print0)
}

qmake_regression(){
    section "qmake regression validation"
    QMAKE_RPATH=$("$PATCHELF" --print-rpath "$QT_ROOT/bin/qmake")
    printf 'qmake RPATH after processing: <%s>\n' "$QMAKE_RPATH"
    [ -z "$QMAKE_RPATH" ] || fail "qmake was unexpectedly assigned an RPATH"
    cmp -s "$QT_ROOT/bin/qmake" "$BACKUP_DIR/qmake.pristine" ||
        fail "qmake changed during selective RPATH processing"
    "$QT_ROOT/bin/qmake" -v
    ok "qmake remained byte-for-byte pristine"
}

audit_dirs(){
    AUDIT_DIRS=()
    local d
    for d in "$QT_ROOT/bin" "$QT_ROOT/lib" "$QT_ROOT/plugins" "$QT_ROOT/qml"; do
        [ -d "$d" ] && AUDIT_DIRS+=("$d")
    done
    [ "${#AUDIT_DIRS[@]}" -gt 0 ] || fail "No Qt directories to audit"
}

audit_unsafe_rpaths(){
    section "RPATH post-condition audit"
    audit_dirs
    UNSAFE_RPATH_LOG="$LOG_DIR/qt-${VCO}-unsafe-rpaths.log"
    : > "$UNSAFE_RPATH_LOG"

    local f rp
    while IFS= read -r -d '' f; do
        file "$f" | grep -Eq 'ELF .* (shared object|dynamically linked)' || continue
        rp=$("$PATCHELF" --print-rpath "$f" 2>/dev/null || true)
        case "$rp" in
            *'/user/'*|*'/wv/'*|*'/build/'*|*'/home/'*|*'/tmp/'*)
                printf '%s|%s\n' "$f" "$rp" >> "$UNSAFE_RPATH_LOG" ;;
        esac
    done < <(find "${AUDIT_DIRS[@]}" -type f ! -name '*.debug' -print0)

    if [ -s "$UNSAFE_RPATH_LOG" ]; then
        cat "$UNSAFE_RPATH_LOG"
        fail "Unsafe host/build RPATHs remain (see $UNSAFE_RPATH_LOG)"
    fi
    ok "no host/build absolute paths remain in RPATH/RUNPATH"

    local name actual
    for name in "${BOOTSTRAP_TOOLS[@]}"; do
        actual=$("$PATCHELF" --print-rpath "$QT_ROOT/bin/$name")
        [ "$actual" = "$QT_BIN_RPATH" ] || fail "Unexpected RPATH on $name: $actual"
    done
    export UNSAFE_RPATH_LOG
}
