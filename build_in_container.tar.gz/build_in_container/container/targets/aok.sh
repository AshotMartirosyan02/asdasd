# shellcheck shell=bash
# AOK - RHEL 8.10, x86_64, gcc-toolset-10
EGL_MODE="${EGL_MODE:-require}"
REQUIRE_AOK_REFERENCE_PLUGINS="${REQUIRE_AOK_REFERENCE_PLUGINS:-1}"
ICU_COMPONENTS=(data i18n io test tu uc)
ICU_RPATH='$ORIGIN:$ORIGIN/../lib64:$ORIGIN/../../../icv_lib/lib64:$ORIGIN/../lib:$ORIGIN/../../../icv_lib.aok/lib64'

target_preflight(){
    section "Validating RHEL 8 host"
    [ -r /etc/os-release ] || fail "/etc/os-release is missing"
    . /etc/os-release
    [ "${ID:-}" = rhel ] || fail "Expected RHEL, found ${ID:-unknown}"
    case "${VERSION_ID:-}" in 8|8.*) ;; *) fail "Expected RHEL 8, found ${VERSION_ID:-unknown}" ;; esac
    echo "Operating system: ${PRETTY_NAME:-RHEL 8}"
    local c
    for c in patch xz tar perl readelf file cmp; do require_cmd "$c"; done
}

target_prepare_env(){
    section "Configuring AOK compiler environment"
    export GCC_TOOLSET_ROOT=/opt/rh/gcc-toolset-10/root/usr
    export CC="$GCC_TOOLSET_ROOT/bin/gcc"
    export CXX="$GCC_TOOLSET_ROOT/bin/g++"
    export PATH="$TOOLS_BIN:$GCC_TOOLSET_ROOT/bin:/usr/bin:/bin:${PATH}"
    export LD_LIBRARY_PATH="$GCC_TOOLSET_ROOT/lib64${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
    [ -x "$CC" ]  || fail "Compiler missing: $CC"
    [ -x "$CXX" ] || fail "Compiler missing: $CXX"
    "$CC" --version | head -1
    case "$("$CC" -dumpmachine)" in
        x86_64-redhat-linux*) ;;
        *) fail "Unexpected GCC target: $("$CC" -dumpmachine)" ;;
    esac

    create_python_wrapper /usr/bin/python3

    section "Creating AOK zlib shim"
    mkdir -p /build/shim/zlib/include /build/shim/zlib/lib64
    export AOK_ZLIB_ROOT=/user/cal_wg_server/ic/icv_zlib/exports.v1-2-13_2025-03-24_engr-aok/mgc_home
    export ZLIB_INCLUDE_SOURCE="$AOK_ZLIB_ROOT/shared/pkgs/icv_zlib_inhouse.aok/include"
    export ZLIB_LIBRARY_SOURCE="$AOK_ZLIB_ROOT/pkgs/icv_lib.aok/lib64"
    [ -f "$ZLIB_INCLUDE_SOURCE/zlib.h" ]  || fail "AOK zlib.h is missing"
    [ -f "$ZLIB_INCLUDE_SOURCE/zconf.h" ] || fail "AOK zconf.h is missing"
    ln -sfn "$ZLIB_INCLUDE_SOURCE/zlib.h"  /build/shim/zlib/include/zlib.h
    ln -sfn "$ZLIB_INCLUDE_SOURCE/zconf.h" /build/shim/zlib/include/zconf.h

    local real_zlib
    real_zlib=$(find "$ZLIB_LIBRARY_SOURCE" -maxdepth 1 \( -type f -o -type l \) -name 'libz.so.1*' -print 2>/dev/null | sort -V | tail -1)
    [ -n "$real_zlib" ] || fail "No libz.so.1 found in $ZLIB_LIBRARY_SOURCE"
    real_zlib=$(readlink -f "$real_zlib")
    [ -f "$real_zlib" ] || fail "Resolved zlib is missing: $real_zlib"
    file "$real_zlib" | grep -q 'ELF 64-bit.*x86-64' || fail "AOK zlib is not x86-64"
    ln -sfn "$real_zlib" /build/shim/zlib/lib64/libz.so
    ln -sfn "$real_zlib" /build/shim/zlib/lib64/libz.so.1
    echo "AOK zlib shim uses: $real_zlib"

    section "Defining AOK dependencies"
    if [ -d /usr/include/libpng16 ]; then
        export libpng16IncludePath=/usr/include/libpng16
    else
        export libpng16IncludePath=/usr/include
    fi
    export sqliteConfigs="${sqliteConfigs:-}"
    export psqlConfigs="${psqlConfigs:-}"
    export doubleconversionConfigs="${doubleconversionConfigs:-}"
    export MYSQL_ROOT=/wv/calibre_3rdparty/NxDAT_OSS_imports/Oracle/mysql-commercial-8.0.32-1.1.el8.x86_64/usr
    export ICU_LIBDIR=/user/cal_wg_server/ic/icu/exports.v65_1_3-9-2023_engr-aok/mgc_home/pkgs/icv_lib.aok/lib64
    [ -f "$MYSQL_ROOT/lib64/mysql/libmysqlclient.so.21.2.32" ] || fail "AOK MySQL client is missing"
    [ -d "$ICU_LIBDIR" ] || fail "AOK ICU directory is missing"
    ok "AOK dependencies resolved"
}

target_patch_buildqt(){
    section "Patching buildQt for AOK"
    sed -i 's|export PATH=${mySqlLocation}/bin:/opt/rh/gcc-toolset-10|export PATH=${mySqlLocation}/bin:/build/tools/bin:/opt/rh/gcc-toolset-10|g' "$BUILD_SCRIPT"

    "$PYTHON_BIN" - "$BUILD_SCRIPT" <<'PY_AOK_DEPS'
from pathlib import Path
import re, sys

p = Path(sys.argv[1]); t = p.read_text()
m = t.find("qtLicenseType='-commercial'")
if m < 0:
    raise SystemExit("ERROR: qtLicenseType marker not found")
s = t.find('if [ ${VCO} = "aok" ]', m)
e = t.find('elif [ "${VCO}" = "aom" ]', s)
if s < 0 or e < 0:
    raise SystemExit("ERROR: AOK dependency block not found")
b = t[s:e]

def one(pattern, repl, msg):
    global b
    b, n = re.subn(pattern, repl, b, count=1, flags=re.M)
    if n != 1:
        raise SystemExit(msg)

one(r'^[ \t]*zlibIncludePath=.*$', '    zlibIncludePath="/build/shim/zlib/include"', "ERROR: zlibIncludePath not found")
one(r'^[ \t]*zlibLibPath=.*$',     '    zlibLibPath="/build/shim/zlib/lib64"',      "ERROR: zlibLibPath not found")
one(r'^[ \t]*freetypeConfigs=.*$', '    freetypeConfigs="FREETYPE_INCDIR=${freetypeIncludePath} FREETYPE_LIBDIR=${freetypeLibPath} FREETYPE_LIBS=-lfreetype"', "ERROR: freetypeConfigs not found")

if not re.search(r'^[ \t]*freetypeLibs=', b, re.M):
    needle = '    freetypeConfigs="FREETYPE_INCDIR=${freetypeIncludePath} FREETYPE_LIBDIR=${freetypeLibPath} FREETYPE_LIBS=-lfreetype"'
    b = b.replace(needle, needle + '\n    freetypeLibs="-lfreetype"', 1)

one(r'^[ \t]*export LDFLAGS="-L\$\{sqliteLibPath\} -Wl,-rpath,\$\{sqliteLibPath\} \$\{LDFLAGS\}"$',
    '    export LDFLAGS="-L${sqliteLibPath} -Wl,-rpath,${sqliteLibPath} ${LDFLAGS} -lrt -ldl"',
    "ERROR: SQLite LDFLAGS not found")

p.write_text(t[:s] + b + t[e:])
print("Updated AOK dependency settings")
PY_AOK_DEPS
}

target_post_install(){
    section "Bundling AOK ICU 65 runtime family"
    local c real soname base
    for c in "${ICU_COMPONENTS[@]}"; do
        real=$(find "$ICU_LIBDIR" -maxdepth 1 -type f -name "libicu${c}.so.65.*" -print 2>/dev/null | sort -V | tail -1)
        [ -n "$real" ] || fail "ICU real library missing: libicu${c}.so.65.*"
        file "$real" | grep -q 'ELF 64-bit.*x86-64' || fail "ICU library is not x86-64: $real"
        soname=$(readelf -d "$real" | awk -F'[][]' '/SONAME/{print $2;exit}')
        [ "$soname" = "libicu${c}.so.65" ] || fail "Unexpected ICU SONAME for $real: $soname"
        base=$(basename "$real")
        bundle_library "$real" "$base" "$soname" "libicu${c}.so"
    done

    section "Bundling AOK MySQL runtime"
    bundle_library "$MYSQL_ROOT/lib64/mysql/libmysqlclient.so.21.2.32" \
        libmysqlclient.so.21.2.32 libmysqlclient.so.21 libmysqlclient.so
    [ "$(readelf -d "$QT_ROOT/lib/libmysqlclient.so.21.2.32" | awk -F'[][]' '/SONAME/{print $2;exit}')" = libmysqlclient.so.21 ] ||
        fail "Unexpected MySQL SONAME"
    [ -f "$QT_ROOT/plugins/sqldrivers/libqsqlmysql.so" ] || fail "Qt MySQL plugin is missing"

    validate_bundled_families 'libicu*.so*' 'libmysqlclient.so*'
    egl_reference_plugins_check "$REQUIRE_AOK_REFERENCE_PLUGINS"
    fix_packaging_mysql_path aok '/wv/calibre_3rdparty/NxDAT_OSS_imports/Oracle/mysql-commercial-8.0.32-1.1.el8.x86_64'
}

target_patch_bundled(){
    section "RPATH: bundled AOK runtimes"
    local c f
    for c in "${ICU_COMPONENTS[@]}"; do
        f=$(readlink -f "$QT_ROOT/lib/libicu${c}.so.65")
        [ -f "$f" ] || fail "Bundled ICU real file missing: libicu${c}.so.65"
        echo "Patching bundled ICU library: $f"
        patchelf_set_rpath "$f" "$ICU_RPATH"
    done
    f=$(readlink -f "$QT_ROOT/lib/libmysqlclient.so.21")
    echo "Patching bundled MySQL library: $f"
    patchelf_set_rpath "$f" '$ORIGIN'
}

target_post_rpath(){
    section "Validating AOK runtime resolution"
    local c actual
    for c in "${ICU_COMPONENTS[@]}"; do
        actual=$("$PATCHELF" --print-rpath "$(readlink -f "$QT_ROOT/lib/libicu${c}.so.65")")
        [ "$actual" = "$ICU_RPATH" ] || fail "Unexpected ICU RPATH: $actual"
    done
    expect_bundled "$QT_ROOT/plugins/sqldrivers/libqsqlmysql.so" libmysqlclient.so.21
    for c in data i18n uc; do
        expect_bundled "$QT_ROOT/lib/libQt5Core.so.${QT_VERSION}" "libicu${c}.so.65"
    done
}

target_final_validation(){
    [ "$REQUIRE_AOK_REFERENCE_PLUGINS" = 1 ] || return 0
    local rel
    for rel in plugins/egldeviceintegrations/libqeglfs-x11-integration.so \
               plugins/xcbglintegrations/libqxcb-egl-integration.so; do
        [ -f "$QT_ROOT/$rel" ] || fail "Reference plugin disappeared: $rel"
    done
    ok "AOK reference plugins present"
}
