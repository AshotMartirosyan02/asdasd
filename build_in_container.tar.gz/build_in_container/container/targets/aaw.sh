# shellcheck shell=bash
# AAW - RHEL 9, aarch64, GCC Toolset 13
EGL_MODE="${EGL_MODE:-auto}"

target_preflight(){
    section "Validating RHEL 9 aarch64 host"
    [ "$(uname -m)" = aarch64 ] || fail "AAW requires an aarch64 container"
    if [ -r /etc/os-release ]; then
        . /etc/os-release
        echo "Operating system: ${PRETTY_NAME:-unknown}"
        case "${VERSION_ID:-}" in 9|9.*) ;; *) warn "Expected RHEL 9, found ${PRETTY_NAME:-unknown}" ;; esac
    fi
    local c
    for c in patch xz tar perl readelf file cmp; do require_cmd "$c"; done
}

target_prepare_env(){
    section "Activating GCC Toolset 13"
    [ -r /opt/rh/gcc-toolset-13/enable ] || fail "gcc-toolset-13 enable script is missing"
    # shellcheck disable=SC1091
    source /opt/rh/gcc-toolset-13/enable
    hash -r

    export GCC_ROOT=/opt/rh/gcc-toolset-13/root/usr
    export REAL_CC="$GCC_ROOT/bin/gcc"
    export REAL_CXX="$GCC_ROOT/bin/g++"
    export GCC_INTERNAL_INCLUDE="$GCC_ROOT/lib/gcc/aarch64-redhat-linux/13/include"
    [ -x "$REAL_CC" ]  || fail "Real GCC is missing: $REAL_CC"
    [ -x "$REAL_CXX" ] || fail "Real G++ is missing: $REAL_CXX"
    [ -f "$GCC_INTERNAL_INCLUDE/stddef.h" ] || fail "GCC internal stddef.h is missing"
    [ -f "$GCC_INTERNAL_INCLUDE/stdarg.h" ] || fail "GCC internal stdarg.h is missing"
    echo "GCC target:  $("$REAL_CC" -dumpmachine)"
    echo "GCC version: $("$REAL_CC" -dumpversion)"
    case "$("$REAL_CC" -dumpmachine)" in aarch64*) ;; *) fail "GCC does not target aarch64" ;; esac

    section "Creating GCC wrappers"
    cat > "$TOOLS_BIN/gcc" <<'GCC_WRAPPER'
#!/bin/sh
exec /opt/rh/gcc-toolset-13/root/usr/bin/gcc \
    -isystem /opt/rh/gcc-toolset-13/root/usr/lib/gcc/aarch64-redhat-linux/13/include \
    "$@"
GCC_WRAPPER
    cat > "$TOOLS_BIN/g++" <<'GXX_WRAPPER'
#!/bin/sh
exec /opt/rh/gcc-toolset-13/root/usr/bin/g++ \
    -isystem /opt/rh/gcc-toolset-13/root/usr/lib/gcc/aarch64-redhat-linux/13/include \
    "$@"
GXX_WRAPPER
    chmod 755 "$TOOLS_BIN/gcc" "$TOOLS_BIN/g++"

    create_python_wrapper ""
    export CC="$TOOLS_BIN/gcc"
    export CXX="$TOOLS_BIN/g++"
    hash -r
    [ "$(command -v gcc)" = "$TOOLS_BIN/gcc" ] || fail "GCC wrapper was not selected"
    [ "$(command -v g++)" = "$TOOLS_BIN/g++" ] || fail "G++ wrapper was not selected"

    section "Testing GCC wrapper"
    cat > /tmp/qt-aaw-cstddef-test.cpp <<'CPP_TEST'
#include <cstddef>
#include <iostream>
int main()
{
    std::size_t value = 0;
    std::cout << value << '\n';
    return 0;
}
CPP_TEST
    "$CXX" -std=c++17 /tmp/qt-aaw-cstddef-test.cpp -o /tmp/qt-aaw-cstddef-test
    file /tmp/qt-aaw-cstddef-test | tee "$LOG_DIR/qt-aaw-compiler-test-file.log"
    file /tmp/qt-aaw-cstddef-test | grep -q 'ARM aarch64' || fail "Compiler test binary is not ARM aarch64"
    /tmp/qt-aaw-cstddef-test
    ok "GCC wrapper resolves internal headers"

    section "Defining AAW dependencies"
    export AAW_SSL_ROOT=/wv/cal_wg_server/ic/openssl/exports.v1.1.1l_2.28_20250603_engr-aaw/mgc_home/shared/pkgs/icv_openssl_comp_inhouse.aaw
    export AAW_ICU_ROOT=/wv/cal_wg_server/ic/icu/exports.v65_1_3-9-2023_engr-aaw/mgc_home
    export AAW_FREETYPE_ROOT=/wv/cal_wg_server/ic/icv_freetype/exports.v6.19.0_2.28_20250721_engr-aaw/mgc_home
    export AAW_ZLIB_ROOT=/wv/cal_wg_server/ic/icv_zlib/exports.v1.2.13_2.28_20250605_engr-aaw/mgc_home
    export AAW_PSQL_ROOT=/wv/cal_wg_server/ic/timescale/exports.v2_17_2_2_28_6-13-2025_engr-aaw/mgc_home
    export AAW_SQLITE_ROOT=/wv/cal_wg_server/ic/sqlite_notsee/exports.v3.48.0_2.28_20250626_engr-aaw/mgc_home
    export AAW_PNG_LIB=/wv/calibre_3rdparty/python/icv_python_20250611/icv_oss_python/aaw/install/lib
    export AAW_ICU_LIB="$AAW_ICU_ROOT/pkgs/icv_lib.aaw/lib64"
    export AAW_FREETYPE_LIB="$AAW_FREETYPE_ROOT/pkgs/icv_lib.aaw/lib64"
    export AAW_ZLIB_LIB="$AAW_ZLIB_ROOT/pkgs/icv_lib.aaw/lib64"
    export AAW_PSQL_LIB="$AAW_PSQL_ROOT/pkgs/icv_timescale.aaw/lib"
    export AAW_SQLITE_LIB="$AAW_SQLITE_ROOT/pkgs/icv_lib.aaw/lib64"

    [ -f "$AAW_SSL_ROOT/include/openssl/ssl.h" ] || fail "AAW OpenSSL headers are missing"
    [ -f "$AAW_SSL_ROOT/lib/libssl.a" ]          || fail "AAW libssl.a is missing"
    [ -f "$AAW_SSL_ROOT/lib/libcrypto.a" ]       || fail "AAW libcrypto.a is missing"
    [ -f "$AAW_ICU_ROOT/shared/pkgs/icu_inhouse.aaw/include/unicode/utypes.h" ] || fail "AAW ICU headers are missing"
    [ -f "$AAW_FREETYPE_ROOT/shared/pkgs/icv_freetype_inhouse.aaw/include/freetype2/ft2build.h" ] || fail "AAW Freetype headers are missing"
    [ -f "$AAW_ZLIB_ROOT/shared/pkgs/icv_zlib_inhouse.aaw/include/zlib.h" ] || fail "AAW zlib headers are missing"
    [ -f "$AAW_PSQL_ROOT/shared/pkgs/icv_timescale_inhouse.aaw/include/libpq-fe.h" ] || fail "AAW PostgreSQL headers are missing"
    [ -f "$AAW_SQLITE_ROOT/shared/pkgs/icv_sqlite_inhouse.aaw/include/sqlite3.h" ] || fail "AAW SQLite headers are missing"
    [ -e "$AAW_PNG_LIB/libpng16.so.16" ] || fail "AAW libpng16 runtime is missing"
    ok "AAW dependencies resolved"
}

target_patch_buildqt(){
    section "Patching buildQt for AAW"
    sed -i "s|export PATH=/opt/rh/gcc-toolset-13/root/usr/bin:|export PATH=$TOOLS_BIN:/opt/rh/gcc-toolset-13/root/usr/bin:|g" "$BUILD_SCRIPT"

    "$PYTHON_BIN" - "$BUILD_SCRIPT" <<'PY_AAW_DEPS'
from pathlib import Path
import re, sys

path = Path(sys.argv[1])
text = path.read_text()
marker = "qtLicenseType='-commercial'"
marker_pos = text.find(marker)
if marker_pos == -1:
    raise SystemExit("ERROR: dependency-section marker was not found")

start = text.find('elif [ "${VCO}" = "aaw" ]', marker_pos)
end = text.find('elif [ "${VCO}" = "soa" ]', start)
if start == -1 or end == -1:
    raise SystemExit("ERROR: AAW dependency block was not found")

block = text[start:end]
block, count = re.subn(r'^[ \t]*mySql=.*$', '    mySql="-no-sql-mysql"', block,
                       count=1, flags=re.MULTILINE)
if count != 1 and 'mySql="-no-sql-mysql"' not in block:
    raise SystemExit("ERROR: AAW MySQL assignment was not found")

block = re.sub(r'^(?P<prefix>[ \t]*icuLibPath="[^"]*?)[ \t]+"$', r'\g<prefix>"',
               block, count=1, flags=re.MULTILINE)
block = re.sub(r'^(?P<prefix>[ \t]*freetypeLibPath="[^"]*?)[ \t]+"$', r'\g<prefix>"',
               block, count=1, flags=re.MULTILINE)

path.write_text(text[:start] + block + text[end:])
print("Updated AAW dependency settings")
PY_AAW_DEPS

    section "Inserting deterministic AAW compiler environment"
    "$PYTHON_BIN" - "$BUILD_SCRIPT" <<'PY_AAW_ENV'
from pathlib import Path
import re, sys

path = Path(sys.argv[1])
text = path.read_text()
block = """# AAW deterministic compiler environment.
if [ "${VCO}" = "aaw" ]; then
    . /opt/rh/gcc-toolset-13/enable
    export PATH="/build/tools/bin:${PATH}"
    export CC=/build/tools/bin/gcc
    export CXX=/build/tools/bin/g++
    hash -r
fi
"""
if block in text:
    print("AAW compiler environment block already exists")
    raise SystemExit(0)

inserted = False
for pattern in (r'^(VCO=.*)$', r'^(checkTarball=.*)$'):
    match = re.search(pattern, text, flags=re.MULTILINE)
    if match:
        pos = match.end()
        text = text[:pos] + "\n\n" + block + text[pos:]
        inserted = True
        break
if not inserted and text.startswith("#!"):
    nl = text.find("\n")
    text = text[:nl + 1] + "\n" + block + text[nl + 1:]
    inserted = True
if not inserted:
    raise SystemExit("ERROR: compiler environment insertion point not found")

path.write_text(text)
print("Inserted AAW compiler environment")
PY_AAW_ENV

    sed -i "s|/opt/rh/gcc-toolset-13/root/usr/bin/g++|$TOOLS_BIN/g++|g" "$BUILD_SCRIPT"
    sed -i "s|/opt/rh/gcc-toolset-13/root/usr/bin/gcc|$TOOLS_BIN/gcc|g" "$BUILD_SCRIPT"
}

target_post_install(){
    section "Validating AAW install specifics"
    [ ! -e "$QT_ROOT/plugins/sqldrivers/libqsqlmysql.so" ] || fail "MySQL plugin was unexpectedly built"

    section "Bundling AAW runtime libraries"
    copy_family "$AAW_ICU_LIB"      'libicudata.so*'  'ICU data'
    copy_family "$AAW_ICU_LIB"      'libicui18n.so*'  'ICU i18n'
    copy_family "$AAW_ICU_LIB"      'libicuuc.so*'    'ICU uc'
    copy_family "$AAW_FREETYPE_LIB" 'libfreetype.so*' 'Freetype'
    copy_family "$AAW_PNG_LIB"      'libpng16.so*'    'PNG'
    copy_family "$AAW_ZLIB_LIB"     'libz.so*'        'zlib'
    copy_family "$AAW_PSQL_LIB"     'libpq.so*'       'PostgreSQL client'
    copy_family "$AAW_SQLITE_LIB"   'libsqlite3.so*'  'SQLite'

    local required
    for required in \
        "$QT_ROOT/lib/libicudata.so.65" \
        "$QT_ROOT/lib/libicui18n.so.65" \
        "$QT_ROOT/lib/libicuuc.so.65" \
        "$QT_ROOT/lib/libfreetype.so.6" \
        "$QT_ROOT/lib/libpng16.so.16" \
        "$QT_ROOT/lib/libz.so.1" \
        "$QT_ROOT/lib/libpq.so.5" \
        "$QT_ROOT/lib/libsqlite3.so.0"
    do
        [ -e "$required" ] || fail "Bundled runtime entry is missing: $required"
    done

    validate_bundled_families 'libicu*.so*' 'libfreetype.so*' 'libpng16.so*' 'libz.so*' 'libpq.so*' 'libsqlite3.so*'
    aaw_fix_mkspecs
}

aaw_fix_mkspecs(){
    section "Removing -m64 from installed ARM64 mkspecs"
    local qmake_spec qmake_xspec spec spec_conf processed=""
    qmake_spec=$("$QT_ROOT/bin/qmake" -query QMAKE_SPEC)
    qmake_xspec=$("$QT_ROOT/bin/qmake" -query QMAKE_XSPEC)
    echo "QMAKE_SPEC=$qmake_spec"
    echo "QMAKE_XSPEC=$qmake_xspec"
    [ -n "$qmake_spec" ] || fail "QMAKE_SPEC is empty"
    export QMAKE_SPEC="$qmake_spec" QMAKE_XSPEC="$qmake_xspec"

    for spec in "$qmake_spec" "$qmake_xspec"; do
        [ -n "$spec" ] || continue
        case " $processed " in *" $spec "*) continue ;; esac
        processed="$processed $spec"
        spec_conf="$QT_ROOT/mkspecs/$spec/qmake.conf"
        [ -f "$spec_conf" ] || fail "qmake spec is missing: $spec_conf"
        cp -a "$spec_conf" "$BACKUP_DIR/mkspecs/${spec//\//_}.qmake.conf.original"
        "$PYTHON_BIN" - "$spec_conf" <<'PY_FIX_M64'
from pathlib import Path
import re, sys
path = Path(sys.argv[1])
text = path.read_text()
updated = re.sub(r"(?<!\S)-m64(?!\S)", "", text)
updated = "\n".join(line.rstrip() for line in updated.splitlines()) + "\n"
path.write_text(updated)
PY_FIX_M64
        if grep -n -- '-m64' "$spec_conf"; then
            fail "Installed ARM64 qmake spec still contains -m64: $spec_conf"
        fi
        ok "-m64 removed from $spec_conf"
    done
}

target_patch_bundled(){
    section "RPATH: bundled AAW runtimes"
    local f
    while IFS= read -r -d '' f; do
        file "$f" | grep -q 'ELF .*shared object' || continue
        echo "Patching bundled runtime: $f"
        patchelf_set_rpath "$f" '$ORIGIN'
    done < <(
        find "$QT_ROOT/lib" -maxdepth 1 -type f \
            \( -name 'libicu*.so*' -o -name 'libfreetype.so*' -o -name 'libpng16.so*' -o \
               -name 'libz.so*' -o -name 'libpq.so*' -o -name 'libsqlite3.so*' \) \
            ! -name '*.debug' -print0
    )
}

target_post_rpath(){
    section "Validating bundled Freetype and ICU resolution"
    local freetype_real
    freetype_real=$(readlink -f "$QT_ROOT/lib/libfreetype.so.6")
    [ -f "$freetype_real" ] || fail "Bundled Freetype real file is missing"
    expect_bundled "$freetype_real" libpng16.so.16
    expect_bundled "$freetype_real" libz.so.1
    local c
    for c in data i18n uc; do
        expect_bundled "$QT_ROOT/lib/libQt5Core.so.${QT_VERSION}" "libicu${c}.so.65"
    done
}

target_extra_smoke(){
    section "Testing installed default qmake spec (ARM64)"
    rm -rf /build/qmake-spec-test
    mkdir -p /build/qmake-spec-test
    cd /build/qmake-spec-test

    cat > main.cpp <<'CPP_SPEC_TEST'
#include <cstddef>
#include <iostream>
int main()
{
    std::size_t value = 0;
    std::cout << value << '\n';
    return 0;
}
CPP_SPEC_TEST

    cat > spec-test.pro <<'QMAKE_SPEC_PROJECT'
QT -= gui
CONFIG += console
CONFIG -= app_bundle
SOURCES += main.cpp
QMAKE_SPEC_PROJECT

    "$QT_ROOT/bin/qmake" spec-test.pro
    if grep -R -- '-m64' Makefile .qmake.stash 2>/dev/null; then
        fail "Default qmake spec still produces -m64"
    fi
    "$MAKE_TOOL" -j"$JOBS"
    file ./spec-test | grep -q 'ARM aarch64' || fail "Default-spec executable is not ARM aarch64"
    LD_LIBRARY_PATH="$QT_ROOT/lib" ./spec-test
    ok "default qmake spec works on ARM64"
}

target_final_validation(){
    [ "${EGL_MODE:-auto}" = require ] || return 0
    local rel
    for rel in plugins/egldeviceintegrations/libqeglfs-x11-integration.so \
               plugins/xcbglintegrations/libqxcb-egl-integration.so; do
        [ -f "$QT_ROOT/$rel" ] || fail "Required EGL/X11 plugin is missing: $rel"
    done
    ok "AAW EGL/X11 plugins present"
}
