EGL_MODE="${EGL_MODE:-auto}"

target_preflight(){
    section "Validating RHEL 9 aarch64 host"
    [ "$(uname -m)" = aarch64 ] || fail "AAW requires an aarch64 container"
    if [ -r /etc/os-release ]; then
        . /etc/os-release
        echo "Operating system: ${PRETTY_NAME:-unknown}"
        case "${VERSION_ID:-}" in 9|9.*) ;; *) fail "Expected RHEL 9, found ${PRETTY_NAME:-unknown}" ;; esac
    fi
    local c
    for c in patch xz tar perl readelf file cmp; do require_cmd "$c"; done
}

target_prepare_env(){
    section "Activating GCC Toolset 13"
    [ -r /opt/rh/gcc-toolset-13/enable ] || fail "gcc-toolset-13 enable script is missing"
    set +u
    source /opt/rh/gcc-toolset-13/enable
    set -u
    hash -r

    export GCC_ROOT=/opt/rh/gcc-toolset-13/root/usr
    export REAL_CC="$GCC_ROOT/bin/gcc"
    export REAL_CXX="$GCC_ROOT/bin/g++"
    export GCC_INTERNAL_INCLUDE="$GCC_ROOT/lib/gcc/aarch64-redhat-linux/13/include"
    [ -x "$REAL_CC" ]  || fail "Real GCC is missing: $REAL_CC"
    [ -x "$REAL_CXX" ] || fail "Real G++ is missing: $REAL_CXX"
    [ -f "$GCC_INTERNAL_INCLUDE/stddef.h" ] || fail "GCC internal stddef.h is missing"
    [ -f "$GCC_INTERNAL_INCLUDE/stdarg.h" ] || fail "GCC internal stdarg.h is missing"
    echo "GCC target:  $("$REAL_CC" -dumpmachine)"
    echo "GCC version: $("$REAL_CC" -dumpversion)"
    case "$("$REAL_CC" -dumpmachine)" in aarch64*) ;; *) fail "GCC does not target aarch64" ;; esac

    create_compiler_wrappers "$REAL_CC" "$REAL_CXX" "$GCC_INTERNAL_INCLUDE"

    create_python_wrapper ""
    export CC="$TOOLS_BIN/gcc"
    export CXX="$TOOLS_BIN/g++"
    hash -r
    [ "$(command -v gcc)" = "$TOOLS_BIN/gcc" ] || fail "GCC wrapper was not selected"
    [ "$(command -v g++)" = "$TOOLS_BIN/g++" ] || fail "G++ wrapper was not selected"

    aaw_test_compiler

    section "Defining AAW dependencies"
    export AAW_SSL_ROOT=/wv/cal_wg_server/ic/openssl/exports.v1.1.1l_2.28_20250603_engr-aaw/mgc_home/shared/pkgs/icv_openssl_comp_inhouse.aaw
    export AAW_ICU_ROOT=/wv/cal_wg_server/ic/icu/exports.v65_1_3-9-2023_engr-aaw/mgc_home
    export AAW_FREETYPE_ROOT=/wv/cal_wg_server/ic/icv_freetype/exports.v6.19.0_2.28_20250721_engr-aaw/mgc_home
    export AAW_ZLIB_ROOT=/wv/cal_wg_server/ic/icv_zlib/exports.v1.2.13_2.28_20250605_engr-aaw/mgc_home
    export AAW_PSQL_ROOT=/wv/cal_wg_server/ic/timescale/exports.v2_17_2_2_28_6-13-2025_engr-aaw/mgc_home
    export AAW_SQLITE_ROOT=/wv/cal_wg_server/ic/sqlite_notsee/exports.v3.48.0_2.28_20250626_engr-aaw/mgc_home
    export AAW_PNG_LIB=/wv/calibre_3rdparty/python/icv_python_20250611/icv_oss_python/aaw/install/lib
    export AAW_ICU_LIB="$AAW_ICU_ROOT/pkgs/icv_lib.aaw/lib64"
    export AAW_FREETYPE_LIB="$AAW_FREETYPE_ROOT/pkgs/icv_lib.aaw/lib64"
    export AAW_ZLIB_LIB="$AAW_ZLIB_ROOT/pkgs/icv_lib.aaw/lib64"
    export AAW_PSQL_LIB="$AAW_PSQL_ROOT/pkgs/icv_timescale.aaw/lib"
    export AAW_SQLITE_LIB="$AAW_SQLITE_ROOT/pkgs/icv_lib.aaw/lib64"

    [ -f "$AAW_SSL_ROOT/include/openssl/ssl.h" ] || fail "AAW OpenSSL headers are missing"
    [ -f "$AAW_SSL_ROOT/lib/libssl.a" ]          || fail "AAW libssl.a is missing"
    [ -f "$AAW_SSL_ROOT/lib/libcrypto.a" ]       || fail "AAW libcrypto.a is missing"
    [ -f "$AAW_ICU_ROOT/shared/pkgs/icu_inhouse.aaw/include/unicode/utypes.h" ] || fail "AAW ICU headers are missing"
    [ -f "$AAW_FREETYPE_ROOT/shared/pkgs/icv_freetype_inhouse.aaw/include/freetype2/ft2build.h" ] || fail "AAW Freetype headers are missing"
    [ -f "$AAW_ZLIB_ROOT/shared/pkgs/icv_zlib_inhouse.aaw/include/zlib.h" ] || fail "AAW zlib headers are missing"
    [ -f "$AAW_PSQL_ROOT/shared/pkgs/icv_timescale_inhouse.aaw/include/libpq-fe.h" ] || fail "AAW PostgreSQL headers are missing"
    [ -f "$AAW_SQLITE_ROOT/shared/pkgs/icv_sqlite_inhouse.aaw/include/sqlite3.h" ] || fail "AAW SQLite headers are missing"
    [ -e "$AAW_PNG_LIB/libpng16.so.16" ] || fail "AAW libpng16 runtime is missing"
    ok "AAW dependencies resolved"
}

aaw_test_compiler(){
    section "Testing GCC wrapper"
    local probe_dir
    probe_dir=$(mktemp -d "${TOOLS_BIN%/bin}/aaw-cstddef.XXXXXX") || fail "Cannot create compiler probe workspace"
    echo "Compiler probe: $probe_dir"
    cat > "$probe_dir/main.cpp" <<'CPP_TEST'
#include <cstddef>
#include <iostream>
int main()
{
    std::size_t value = 0;
    std::cout << value << '\n';
    return 0;
}
CPP_TEST
    "$CXX" -std=c++17 "$probe_dir/main.cpp" -o "$probe_dir/probe"
    file "$probe_dir/probe" | tee "$LOG_DIR/qt-aaw-compiler-test-file.log"
    file "$probe_dir/probe" | grep -q 'ARM aarch64' || fail "Compiler test binary is not ARM aarch64"
    "$probe_dir/probe"
    rm -rf -- "$probe_dir"
    ok "GCC wrapper resolves internal headers"
}

target_post_install(){
    section "Validating AAW install specifics"
    [ ! -e "$QT_ROOT/plugins/sqldrivers/libqsqlmysql.so" ] || fail "MySQL plugin was unexpectedly built"

    section "Bundling AAW runtime libraries"
    copy_family "$AAW_ICU_LIB"      'libicudata.so*'  'ICU data'
    copy_family "$AAW_ICU_LIB"      'libicui18n.so*'  'ICU i18n'
    copy_family "$AAW_ICU_LIB"      'libicuuc.so*'    'ICU uc'
    copy_family "$AAW_FREETYPE_LIB" 'libfreetype.so*' 'Freetype'
    copy_family "$AAW_PNG_LIB"      'libpng16.so*'    'PNG'
    copy_family "$AAW_ZLIB_LIB"     'libz.so*'        'zlib'
    copy_family "$AAW_PSQL_LIB"     'libpq.so*'       'PostgreSQL client'
    copy_family "$AAW_SQLITE_LIB"   'libsqlite3.so*'  'SQLite'

    local required
    for required in \
        "$QT_ROOT/lib/libicudata.so.65" \
        "$QT_ROOT/lib/libicui18n.so.65" \
        "$QT_ROOT/lib/libicuuc.so.65" \
        "$QT_ROOT/lib/libfreetype.so.6" \
        "$QT_ROOT/lib/libpng16.so.16" \
        "$QT_ROOT/lib/libz.so.1" \
        "$QT_ROOT/lib/libpq.so.5" \
        "$QT_ROOT/lib/libsqlite3.so.0"
    do
        [ -e "$required" ] || fail "Bundled runtime entry is missing: $required"
    done

    validate_bundled_families 'libicu*.so*' 'libfreetype.so*' 'libpng16.so*' 'libz.so*' 'libpq.so*' 'libsqlite3.so*'
    aaw_fix_mkspecs
}

aaw_fix_mkspecs(){
    section "Removing -m64 from installed ARM64 mkspecs"
    local qmake_spec qmake_xspec spec spec_conf processed=""
    qmake_spec=$("$QT_ROOT/bin/qmake" -query QMAKE_SPEC)
    qmake_xspec=$("$QT_ROOT/bin/qmake" -query QMAKE_XSPEC)
    echo "QMAKE_SPEC=$qmake_spec"
    echo "QMAKE_XSPEC=$qmake_xspec"
    [ -n "$qmake_spec" ] || fail "QMAKE_SPEC is empty"
    export QMAKE_SPEC="$qmake_spec" QMAKE_XSPEC="$qmake_xspec"

    for spec in "$qmake_spec" "$qmake_xspec"; do
        [ -n "$spec" ] || continue
        case " $processed " in *" $spec "*) continue ;; esac
        processed="$processed $spec"
        spec_conf="$QT_ROOT/mkspecs/$spec/qmake.conf"
        [ -f "$spec_conf" ] || fail "qmake spec is missing: $spec_conf"
        if [ ! -e "$BACKUP_DIR/mkspecs/${spec//\//_}.qmake.conf.original" ]; then
            cp -a "$spec_conf" "$BACKUP_DIR/mkspecs/${spec//\//_}.qmake.conf.original"
        fi
        "$PYTHON_BIN" - "$spec_conf" <<'PY_FIX_M64'
from pathlib import Path
import re, sys
path = Path(sys.argv[1])
text = path.read_text()
updated = re.sub(r"(?<!\S)-m64(?!\S)", "", text)
updated = "\n".join(line.rstrip() for line in updated.splitlines()) + "\n"
path.write_text(updated)
PY_FIX_M64
        if grep -n -- '-m64' "$spec_conf"; then
            fail "Installed ARM64 qmake spec still contains -m64: $spec_conf"
        fi
        ok "-m64 removed from $spec_conf"
    done
}

target_patch_bundled(){
    section "RPATH: bundled AAW runtimes"
    local f
    while IFS= read -r -d '' f; do
        file "$f" | grep -q 'ELF .*shared object' || continue
        echo "Patching bundled runtime: $f"
        patchelf_set_rpath "$f" '$ORIGIN'
    done < <(
        find "$QT_ROOT/lib" -maxdepth 1 -type f \
            \( -name 'libicu*.so*' -o -name 'libfreetype.so*' -o -name 'libpng16.so*' -o \
               -name 'libz.so*' -o -name 'libpq.so*' -o -name 'libsqlite3.so*' \) \
            ! -name '*.debug' -print0
    )
}

target_post_rpath(){
    section "Validating bundled Freetype and ICU resolution"
    local freetype_real
    freetype_real=$(readlink -f "$QT_ROOT/lib/libfreetype.so.6")
    [ -f "$freetype_real" ] || fail "Bundled Freetype real file is missing"
    expect_bundled "$freetype_real" libpng16.so.16
    expect_bundled "$freetype_real" libz.so.1
    local c
    for c in data i18n uc; do
        expect_bundled "$QT_ROOT/lib/libQt5Core.so.${QT_VERSION}" "libicu${c}.so.65"
    done
}

target_extra_smoke(){
    section "Testing installed default qmake spec (ARM64)"
    rm -rf /build/qmake-spec-test
    mkdir -p /build/qmake-spec-test
    cd /build/qmake-spec-test

    cat > main.cpp <<'CPP_SPEC_TEST'
#include <cstddef>
#include <iostream>
int main()
{
    std::size_t value = 0;
    std::cout << value << '\n';
    return 0;
}
CPP_SPEC_TEST

    cat > spec-test.pro <<'QMAKE_SPEC_PROJECT'
QT -= gui
CONFIG += console
CONFIG -= app_bundle
SOURCES += main.cpp
QMAKE_SPEC_PROJECT

    "$QT_ROOT/bin/qmake" spec-test.pro
    if grep -R -- '-m64' Makefile .qmake.stash 2>/dev/null; then
        fail "Default qmake spec still produces -m64"
    fi
    "$MAKE_TOOL" -j"$JOBS"
    file ./spec-test | grep -q 'ARM aarch64' || fail "Default-spec executable is not ARM aarch64"
    LD_LIBRARY_PATH="$QT_ROOT/lib" ./spec-test
    ok "default qmake spec works on ARM64"
}

target_final_validation(){
    [ "${EGL_MODE:-auto}" = require ] || return 0
    local rel
    for rel in plugins/egldeviceintegrations/libqeglfs-x11-integration.so \
               plugins/xcbglintegrations/libqxcb-egl-integration.so; do
        [ -f "$QT_ROOT/$rel" ] || fail "Required EGL/X11 plugin is missing: $rel"
    done
    ok "AAW EGL/X11 plugins present"
}
