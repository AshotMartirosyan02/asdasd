EGL_MODE="${EGL_MODE:-off}"

target_preflight(){
    section "Validating SLE 15 host"
    if [ -r /etc/os-release ]; then
        . /etc/os-release
        echo "Operating system: ${PRETTY_NAME:-unknown}"
        case "${ID:-}" in
            sles|sle*|opensuse*) ;;
            *) fail "Expected SLE 15, found ${ID:-unknown}" ;;
        esac
    fi
    local c
    for c in patch xz tar perl readelf file cmp; do require_cmd "$c"; done
}

target_prepare_env(){
    section "Configuring SOA compiler environment"
    export CC=/usr/bin/gcc-10
    export CXX=/usr/bin/g++-10
    [ -x "$CC" ]  || fail "Compiler was not found: $CC"
    [ -x "$CXX" ] || fail "Compiler was not found: $CXX"
    "$CC" --version | head -1

    create_compiler_wrappers "$CC" "$CXX"
    create_python_wrapper /usr/bin/python3
    export PATH="$TOOLS_BIN:/usr/bin:/bin:${PATH}"

    section "Defining SOA dependency environment"
    export freetypeIncludePath=/usr/include/freetype2
    export freetypeLibPath=/usr/lib64
    export freetypeConfigs="FREETYPE_INCDIR=${freetypeIncludePath} FREETYPE_LIBDIR=${freetypeLibPath} FREETYPE_LIBS=-lfreetype"
    export freetypeLibs="-lfreetype"
    if [ -d /usr/include/libpng16 ]; then
        export libpng16IncludePath=/usr/include/libpng16
    else
        export libpng16IncludePath=/usr/include
    fi
    export icu="-icu"
    export zlib="-system-zlib"
    export sqliteConfigs=""
    export psqlConfigs=""
    export doubleconversionConfigs=""
    export SSL_ROOT=/wv/cal_wg_server/ic/openssl/exports.v0-0_6-29-2020_engr-soa/mgc_home/shared/pkgs/icv_openssl_comp_inhouse.soa
    export MYSQL_ROOT=/wv/calibre_3rdparty/NxDAT_OSS_imports/Oracle/mysql-commercial-8.0.32-1.1.sl15.x86_64/usr

    [ -f "$SSL_ROOT/include/openssl/ssl.h" ] || fail "SOA OpenSSL headers are missing"
    [ -f "$SSL_ROOT/lib/libssl.a" ]          || fail "SOA libssl.a is missing"
    [ -f "$SSL_ROOT/lib/libcrypto.a" ]       || fail "SOA libcrypto.a is missing"
    [ -f "$MYSQL_ROOT/lib64/mysql/libmysqlclient.so.21.2.32" ] || fail "SOA MySQL client library is missing"
    ok "SOA dependencies resolved"
}

target_post_install(){
    section "Bundling SOA MySQL runtime"
    bundle_library "$MYSQL_ROOT/lib64/mysql/libmysqlclient.so.21.2.32" \
        libmysqlclient.so.21.2.32 libmysqlclient.so.21 libmysqlclient.so

    local soname missing
    soname=$(readelf -d "$QT_ROOT/lib/libmysqlclient.so.21.2.32" | awk -F'[][]' '/SONAME/{print $2;exit}')
    echo "MySQL SONAME: $soname"
    [ "$soname" = "libmysqlclient.so.21" ] || fail "Unexpected MySQL SONAME: $soname"

    missing=$(LD_LIBRARY_PATH="$QT_ROOT/lib" ldd "$QT_ROOT/lib/libmysqlclient.so.21" 2>/dev/null | grep 'not found' || true)
    [ -z "$missing" ] || { echo "$missing"; fail "libmysqlclient has missing dependencies"; }
    [ -f "$QT_ROOT/plugins/sqldrivers/libqsqlmysql.so" ] || fail "Qt MySQL plugin is missing"

    validate_bundled_families 'libmysqlclient.so*'
    fix_packaging_mysql_path soa '/wv/calibre_3rdparty/NxDAT_OSS_imports/Oracle/mysql-commercial-8.0.32-1.1.sl15.x86_64'
}

target_patch_bundled(){
    section "RPATH: bundled SOA runtimes"
    local f
    f=$(readlink -f "$QT_ROOT/lib/libmysqlclient.so.21")
    echo "Patching bundled MySQL library: $f"
    patchelf_set_rpath "$f" '$ORIGIN'
}

target_post_rpath(){
    section "Validating SOA MySQL plugin resolution"
    local missing
    missing=$(LD_LIBRARY_PATH="$QT_ROOT/lib" ldd "$QT_ROOT/plugins/sqldrivers/libqsqlmysql.so" 2>/dev/null | grep 'not found' || true)
    [ -z "$missing" ] || { echo "$missing"; fail "Qt MySQL plugin has missing dependencies"; }
    expect_bundled "$QT_ROOT/plugins/sqldrivers/libqsqlmysql.so" libmysqlclient.so.21
}
