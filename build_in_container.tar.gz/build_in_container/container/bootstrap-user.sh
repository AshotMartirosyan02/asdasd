#!/usr/bin/bash
# =============================================================================
# Runs as ROOT inside the container, before the real build.
#
#   * makes sure $BUILD_USER (default cdtop) exists
#   * picks the primary group so that new files match the deployment area
#   * gives that user a usable HOME and ownership of /build
#   * PROVES, by an actual write probe, that the user can create files in
#     $INSTALL_ROOT - this, not uid equality, is the real acceptance criterion
#     (the /wv/iit/qt/<vco> directories are group-writable and are typically
#      owned by a different uid than cdtop)
#
# Diagnostics go to stderr; stdout carries only the machine-readable lines
# consumed by the host driver: BUILD_UID= / BUILD_GID= / BUILD_HOME=
# =============================================================================
set -Eeuo pipefail

BUILD_USER="${BUILD_USER:-cdtop}"
VCO="${VCO:-}"
IIT_QT_ROOT="${IIT_QT_ROOT:-/wv/iit/qt}"
INSTALL_ROOT="${INSTALL_ROOT:-$IIT_QT_ROOT/$VCO}"
STRICT_UID="${STRICT_UID:-0}"

log(){  echo "bootstrap: $*" >&2; }
fail(){ echo "ERROR: bootstrap: $*" >&2; exit 1; }

as_user(){
    if command -v runuser >/dev/null 2>&1; then
        runuser -u "$BUILD_USER" -- "$@"
    else
        local cmd
        printf -v cmd '%q ' "$@"
        su -s /bin/bash -c "$cmd" "$BUILD_USER"
    fi
}

[ "$(id -u)" = 0 ] || fail "bootstrap-user.sh must run as root"
[ -n "$BUILD_USER" ] || fail "BUILD_USER is empty"

# --- 1. the deployment area ---------------------------------------------------
ref="$INSTALL_ROOT"
while [ ! -e "$ref" ] && [ "$ref" != / ]; do ref=$(dirname "$ref"); done
[ -e "$ref" ] || fail "no existing directory found for $INSTALL_ROOT"

ref_uid=$(stat -c '%u' "$ref")
ref_gid=$(stat -c '%g' "$ref")
ref_mode=$(stat -c '%A' "$ref")
log "deployment area $ref: owner uid=$ref_uid gid=$ref_gid mode=$ref_mode"

# --- 2. make sure the build user exists ---------------------------------------
if id -u "$BUILD_USER" >/dev/null 2>&1; then
    uid=$(id -u "$BUILD_USER")
    log "user $BUILD_USER exists (uid=$uid, primary gid=$(id -g "$BUILD_USER"))"
else
    log "creating $BUILD_USER with uid=$ref_uid gid=$ref_gid"
    if ! getent group "$ref_gid" >/dev/null 2>&1; then
        groupadd -g "$ref_gid" "$BUILD_USER" || fail "groupadd failed"
    fi
    grp=$(getent group "$ref_gid" | cut -d: -f1)
    useradd -u "$ref_uid" -g "$grp" -M -d "/home/$BUILD_USER" -s /bin/bash "$BUILD_USER" ||
        fail "useradd failed for $BUILD_USER"
    uid=$ref_uid
fi

# A different uid is normal here: the shares are group-writable, so ownership
# equality is NOT required. Only complain loudly, and only fail when asked to.
if [ "$uid" != "$ref_uid" ]; then
    log "note: $BUILD_USER uid=$uid differs from the directory owner uid=$ref_uid"
    log "      this is fine as long as the write probe below succeeds"
    if [ "$STRICT_UID" = 1 ]; then
        fail "STRICT_UID=1 and uid mismatch ($uid != $ref_uid)"
    fi
fi

# --- 3. primary group: prefer the group of the deployment area ---------------
user_gid=$(id -g "$BUILD_USER")
gid="$user_gid"
if [ "$ref_gid" != "$user_gid" ]; then
    if id -G "$BUILD_USER" | tr ' ' '\n' | grep -qx "$ref_gid"; then
        gid="$ref_gid"
        log "using gid=$ref_gid as primary group (matches $ref, $BUILD_USER is a member)"
    else
        log "note: $BUILD_USER is not a member of gid=$ref_gid; new files will use gid=$user_gid"
    fi
fi

# --- 4. HOME (qmake and buildQt look for ~/.qt-license) ----------------------
home=$(getent passwd "$BUILD_USER" | cut -d: -f6)
[ -n "$home" ] || home="/home/$BUILD_USER"
mkdir -p "$home"
chown "$uid:$user_gid" "$home"
log "home directory: $home"

# --- 5. /build must belong to the build user ---------------------------------
mkdir -p /build
current=$(stat -c '%u' /build)
if [ "$current" != "$uid" ]; then
    log "chowning /build to $uid:$user_gid (metadata only, may take a moment)"
    chown -R "$uid:$user_gid" /build
fi

# --- 6. authoritative write probe --------------------------------------------
if [ ! -d "$INSTALL_ROOT" ]; then
    as_user mkdir -p "$INSTALL_ROOT" ||
        fail "$BUILD_USER cannot create $INSTALL_ROOT (create it once with the right owner/group, or check root_squash)"
fi
probe="$INSTALL_ROOT/.write-probe-$$"
as_user touch "$probe" ||
    fail "$BUILD_USER cannot write into $INSTALL_ROOT - check the group permissions of that directory"
probe_uid=$(stat -c '%u' "$probe")
probe_gid=$(stat -c '%g' "$probe")
as_user rm -f "$probe"
log "write probe OK: new files become uid=$probe_uid gid=$probe_gid in $INSTALL_ROOT"
[ "$probe_uid" = "$uid" ] ||
    fail "probe file got uid=$probe_uid instead of $uid - broken id mapping on the share"

echo "BUILD_UID=$uid"
echo "BUILD_GID=$gid"
echo "BUILD_HOME=$home"
