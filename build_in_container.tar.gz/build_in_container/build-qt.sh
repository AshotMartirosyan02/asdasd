#!/usr/bin/env bash
# =============================================================================
# Qt 5.15.19 - single entry point for AOK / SOA / AAW container builds.
#
#   ./build-qt.sh -aok
#   ./build-qt.sh -aok -soa
#   ./build-qt.sh -aok -soa -aaw
#
# The script detects the host architecture, dispatches non-matching targets over
# SSH (x86_64 -> eiger, aarch64 -> cal-arm-19), makes sure the docker image
# exists (building it from oss-containers when needed), recreates the build
# container from scratch and installs Qt directly into /wv/iit/qt/<vco>.
# =============================================================================
set -Eeuo pipefail

SCRIPT_PATH=$(readlink -f "${BASH_SOURCE[0]}")
BIC_DIR=$(cd "$(dirname "$SCRIPT_PATH")" && pwd -P)
QT_DIR=$(cd "$BIC_DIR/.." && pwd -P)
export BIC_DIR QT_DIR

# shellcheck disable=SC1091
. "$BIC_DIR/host/lib-log.sh"
# shellcheck disable=SC1091
. "$BIC_DIR/config/common.conf"
# shellcheck disable=SC1091
. "$BIC_DIR/host/lib-args.sh"
# shellcheck disable=SC1091
. "$BIC_DIR/host/lib-remote.sh"
# shellcheck disable=SC1091
. "$BIC_DIR/host/lib-docker.sh"

parse_args "$@"

[ -f "$QT_DIR/bin/buildQt-${QT_VERSION}" ] ||
    fail "build_in_container must live inside the qt repository. Not found: $QT_DIR/bin/buildQt-${QT_VERSION}"
[ -f "$QT_DIR/bin/qt-license" ] ||
    fail "Qt license not found: $QT_DIR/bin/qt-license"

mkdir -p "$BIC_DIR/logs"
RUN_STAMP=$(date +%Y%m%d-%H%M%S)
MAIN_LOG="$BIC_DIR/logs/driver-$RUN_STAMP.log"
exec > >(tee -a "$MAIN_LOG") 2>&1

HOST_ARCH=$(uname -m)

section "Qt $QT_VERSION build driver"
info "Host:          $(hostname -s) ($HOST_ARCH)"
info "Qt repository: $QT_DIR"
info "Targets:       ${TARGETS[*]}"
info "Install root:  ${INSTALL_ROOT_OVERRIDE:-$IIT_QT_ROOT/<vco>}"
info "Force replace: $FORCE_REPLACE"
info "Driver log:    $MAIN_LOG"
[ "$DRY_RUN" = 1 ] && warn "DRY RUN - nothing will be executed"

LOCAL_TARGETS=()
REMOTE_X86=""
REMOTE_ARM=""

for t in "${TARGETS[@]}"; do
    a=$(target_arch "$t")
    if [ "$a" = "$HOST_ARCH" ]; then
        LOCAL_TARGETS+=("$t")
    elif [ "$LOCAL_ONLY" = 1 ]; then
        fail "Target $t needs $a but --local-only was given on a $HOST_ARCH host"
    else
        case "$a" in
            x86_64)  REMOTE_X86="$REMOTE_X86 $t" ;;
            aarch64) REMOTE_ARM="$REMOTE_ARM $t" ;;
        esac
    fi
done

declare -A RESULT
EXIT_CODE=0

for t in ${LOCAL_TARGETS[@]+"${LOCAL_TARGETS[@]}"}; do
    if build_target_local "$t"; then
        RESULT[$t]="PASS  (local $(hostname -s))"
    else
        RESULT[$t]="FAIL  (local $(hostname -s))"
        EXIT_CODE=1
    fi
done

if [ -n "$REMOTE_X86" ]; then
    if dispatch_remote x86_64 $REMOTE_X86; then
        for t in $REMOTE_X86; do RESULT[$t]="PASS  (remote $HOST_X86_64)"; done
    else
        for t in $REMOTE_X86; do RESULT[$t]="FAIL  (remote $HOST_X86_64)"; done
        EXIT_CODE=1
    fi
fi

if [ -n "$REMOTE_ARM" ]; then
    if dispatch_remote aarch64 $REMOTE_ARM; then
        for t in $REMOTE_ARM; do RESULT[$t]="PASS  (remote $HOST_AARCH64)"; done
    else
        for t in $REMOTE_ARM; do RESULT[$t]="FAIL  (remote $HOST_AARCH64)"; done
        EXIT_CODE=1
    fi
fi

section "Summary"
for t in "${TARGETS[@]}"; do
    printf '  %-5s %-28s -> %s\n' "$t" "${RESULT[$t]:-SKIPPED}" \
        "${INSTALL_ROOT_OVERRIDE:-$IIT_QT_ROOT/$t}/qt-$QT_VERSION"
done
echo
info "Driver log: $MAIN_LOG"

if [ "$EXIT_CODE" -eq 0 ]; then
    ok "All requested Qt $QT_VERSION builds completed"
else
    err "At least one target failed"
fi
exit "$EXIT_CODE"
