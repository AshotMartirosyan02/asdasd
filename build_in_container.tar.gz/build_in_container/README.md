# build_in_container — Qt 5.15.19 multi-platform build system

One entry point drives the whole thing:

```
./build-qt.sh -aok            # single target
./build-qt.sh -aok -soa       # two targets
./build-qt.sh -aok -soa -aaw  # everything, remote hosts included
```

This directory lives **inside the qt repository** (`<qt>/build_in_container`), so the
qt repo is never cloned by the tooling. Only `oss-containers` is cloned, and only
when a docker image has to be built.

## What the driver does per target

1. Resolves the required architecture (`aok`,`soa` -> x86_64, `aaw` -> aarch64).
   If it does not match the current host, the run is dispatched over SSH to
   `eiger` (x86_64) or `cal-arm-19` (aarch64).
2. Checks whether the docker image exists.
   * missing -> clone/refresh `oss-containers`, run `setup.sh` (AOK/SOA), `docker build`
   * present -> reused (`--rebuild-image` forces a rebuild)
3. Removes any existing container with the same name and starts a fresh one.
4. Runs `container/run-build.sh <vco>` inside the container.
5. Installs **directly into `/wv/iit/qt/<vco>/qt-5.15.19`** (bind mounted), so the
   resulting tree is byte-for-byte comparable with the older `qt-5.15.x` installs:
   the prefix baked into `qmake`, `qt.conf`, mkspecs and pkg-config is the real
   deployment path, not `/build/install`.

## Layout

```
build_in_container/
├── build-qt.sh                  MAIN entry point (the only file you run)
├── config/
│   ├── common.conf              versions, hosts, repo URLs, /wv/iit/qt root
│   ├── aok.conf soa.conf aaw.conf
├── host/
│   ├── lib-log.sh               logging helpers
│   ├── lib-args.sh              CLI parsing / usage
│   ├── lib-remote.sh            arch detection + SSH dispatch + rsync
│   └── lib-docker.sh            image build, container lifecycle, docker exec
├── container/
│   ├── run-build.sh             in-container orchestrator (arg: aok|soa|aaw)
│   ├── lib/common.sh            workspace, buildQt staging, phases
│   ├── lib/egl-x11.sh           GLVND-safe egl-x11 configure-test patch
│   ├── lib/rpath.sh             selective RPATH processing (qmake stays pristine)
│   ├── lib/verify.sh            audits, smoke tests, parity vs. previous installs
│   └── targets/{aok,soa,aaw}.sh platform specifics
└── logs/                        driver + per-target logs (gitignored)
```

## Important options

| Option | Meaning |
|---|---|
| `--force` | replace an existing `qt-5.15.19` (renamed to `qt-5.15.19-prev-<ts>`, never deleted) |
| `--install-root DIR` | build somewhere else (staging); hardcoded paths are retargeted |
| `--rebuild-image` | rebuild the docker image even if it exists |
| `--cache` | allow docker build cache (default is `--no-cache`) |
| `--stop-after` | remove the container when the build ends (default: keep it for inspection) |
| `--owner uid:gid` | `chown -R` the installed tree afterwards |
| `--local-only` | never SSH (used automatically for the remote leg) |
| `--dry-run` | print what would happen |

## Safety rules baked in

* `fixRpath=0` in `buildQt-5.15.19`; RPATH is applied selectively afterwards.
  `qmake` and `*.debug` are **never** patched (SHA-256 compared before/after).
* The extracted source tree is auto-detected, never hardcoded.
* prepare -> patch -> configure -> build phases are separated so the EGL/X11 fix
  survives.
* Every bundled runtime family is validated (arch, SONAME, no dangling symlinks,
  nothing resolving outside the Qt tree).
* Unsafe RPATH audit (`/wv`, `/user`, `/build`, `/home`, `/tmp`) + recursive
  missing-dependency audit + mandatory QtCore smoke test.
* An existing installation is never overwritten silently.


## Who writes into /wv/iit/qt

The build never runs as root. `build-qt.sh` performs two `docker exec` calls:

1. `container/bootstrap-user.sh` **as root** - makes sure `cdtop` exists, gives
   it a HOME and ownership of `/build`, and runs a real write probe in
   `/wv/iit/qt/<vco>`.
2. `container/run-build.sh` **as `cdtop`** (`docker exec -u cdtop`, by name so
   the supplementary groups survive), so every artefact in
   `/wv/iit/qt/<vco>/qt-5.15.19` belongs to `cdtop`.

`cdtop` normally has a *different* uid than the owner of `/wv/iit/qt/<vco>`;
those directories are group-writable, so ownership equality is not required and
is only reported. Set `STRICT_UID=1` if you do want it enforced.

Guards:

* `assert_build_identity` refuses to continue if the build ends up as root.
* `assert_install_ownership` does a real write probe before configure.
* `verify_install_ownership` fails the build if any installed file has a
  foreign uid.
* `~/.qt-license` follows `$HOME`, it is no longer hardcoded to `/root`.

Override with `--build-user NAME`, or `--as-root` (only sensible together with
`--install-root /build/install`).
