# Qt 5.15.19 container build

Գլխավոր սկրիպտը՝ `build-qt.sh`։ Պանակը տեղադրիր գործող Qt repository-ի մեջ՝ `<qt>/build_in_container`։

## Գործարկում

```bash
cd /wv/ashmarmo_nobackup/fix_container/final/qt/build_in_container
./build-qt.sh -aok -soa -aaw
```

Առանձին կամ համակցված տարբերակները՝

```bash
./build-qt.sh -aok
./build-qt.sh -soa
./build-qt.sh -aaw
./build-qt.sh -soa -aaw
./build-qt.sh -aok -aaw
```

Ընտրված target-ները կատարվում են հերթով՝ տրված հերթականությամբ։ Կրկնված target-ը կատարվում է մեկ անգամ։ Մեկի սխալը չի դադարեցնում մյուսները. վերջում ցուցադրվում է յուրաքանչյուրի արդյունքը։ Ընդհանուր exit code-ը `0` է միայն բոլոր ընտրված target-ների հաջողության դեպքում։

| Target | Container | Ճարտարապետություն | SSH host, եթե տեղականը չի համապատասխանում | Install tree |
|---|---|---|---|---|
| aok | RHEL 8, GCC 10 | x86_64 | eiger | /wv/iit/qt/aok/qt-5.15.19 |
| soa | SLE 15, GCC 10 | x86_64 | eiger | /wv/iit/qt/soa/qt-5.15.19 |
| aaw | RHEL 9, GCC 13 | aarch64 | cal-arm-19 | /wv/iit/qt/aaw/qt-5.15.19 |

## Քո ընթացիկ build-ների ավարտը

Ուղարկած log-երում AOK/SOA-ն արդեն ավարտել են compile/install-ը։ Դրանց bundling/RPATH/validation փուլերը կրկնելու և AAW-ն ամբողջությամբ կառուցելու համար՝

```bash
./build-qt.sh --post-only -aok -soa
./build-qt.sh -aaw
```

`--post-only`-ն պահպանում է գործող container-ը և `/build` workspace-ը։ Այն պահանջում է արդեն տեղադրված `qmake`։ Container-ի բացակայության դեպքում ստեղծվում է նորը, և անհրաժեշտ փոքր մուտքային ֆայլերը պատճենվում են repository-ից։ AAW-ի ապրիլյան հին install-ը ընթացիկ build-ի արդյունքը չէ. դրա համար օգտագործիր սովորական `-aaw`։

## Լրիվ build-ի ընթացքը

1. Օգտագործում է առկա `aok:qt51519-ready`, `soa:qt51519-ready`, `aaw:qt51519-ready` image-ները։ Բացակայող image-ը կառուցում է համապատասխան `oss-containers` պանակից։
2. Նախկին նույնանուն container-ից պահպանում է `/build/logs` և `/build/backups` տվյալները, ապա ստեղծում նոր container։
3. Root bootstrap-ը ստուգում է `cdtop`-ին, նրա HOME-ը, `/build`-ը և install root-ում գրելու իրական հնարավորությունը։ Build-ը կատարվում է `cdtop`-ով։
4. Repository-ից աշխատանքային պատճեն է ստեղծում `/build/qt`-ում, այնտեղ հարմարեցնում vendor script-ը, ստուգում archive-ները, configure և compile է անում Qt-ն ու style plugin-ները։
5. Միայն compile-ից և Cleanlooks-ի ստուգումից հետո առկա install tree-ը տեղափոխում է `qt-5.15.19-prev-<timestamp>` անունով։ Այնուհետև տեղադրում է նոր Qt-ն իրական deployment prefix-ով։ Նախորդ tree-ը չի ջնջվում։
6. Bundle է անում runtime-ները, ուղղում RPATH-ները և կատարում վերջնական ստուգումները։

Սովորական գործարկումն ամբողջական նոր build է։ `--force` պետք չէ. հին կանչերի համատեղելիության համար այն ընդունվում է։ Install-ի կամ հետագա ստուգման ձախողման դեպքում նախորդ tree-ը մնում է backup անունով, container-ը՝ inspection-ի համար։

## Անհրաժեշտ մուտքերը

Qt repository-ում պետք է մնան իրական ֆայլերը՝

- `bin/buildQt-5.15.19`, `bin/qt-license`, AOK/SOA-ի համար՝ `bin/makeQt5Pkg.pl`։
- `patches/5.15.19-patch` և առկա մյուս vendor patch-երը։
- `md5sums.txt`, ներառյալ `qtstyleplugins-master.zip`-ի ճիշտ checksum-ը։

Default tarball directory-ն `/wv/calibre_3rdparty/tarballs/Qt` է։ Այնտեղ անհրաժեշտ են `qt-everywhere-src-5.15.19.tar.xz` և `qtstyleplugins-master.zip`։ Մուտքային vendor script-երը չեն փոխվում repository-ում. ուղղվում են միայն staged պատճենները։ Ուղղված `makeQt5Pkg.pl`-ը նաև պահվում է target-ի container log-երի մեջ։ Այս driver-ը package tarball չի ստեղծում։

Host-ում անհրաժեշտ են Bash, Docker-ի հասանելիություն և `flock`։ Հեռավոր target-ների համար անհրաժեշտ են SSH հասանելիություն և `rsync` երկու host-ում։ Image կառուցելու դեպքում պետք է `git` և ներքին `oss-containers` repository-ի հասանելիություն։ `cdtop`-ը պետք է արդեն գոյություն ունենա image-ում՝ ընկերության ճիշտ UID/GID-ով։

Ներքին `/wv`, `/user`, `/home/cqi` dependency export-երը պետք է հասանելի լինեն համապատասխան host-ում։ Driver-ը mount է անում առկա export-երը, repository-ն՝ read-only, `/wv/iit`-ը՝ writable։ Host-ի `/tmp`-ը նոր container-ներին չի mount անում։ AAW compiler probe-ը ստեղծում է եզակի պանակ `/build/tools`-ում, ուստի հին root-owned `/tmp/qt-aaw-cstddef-test*` ֆայլերը չեն խանգարում։

Remote գործարկումը նույն absolute Qt repository path-ն է օգտագործում։ `bin/`, `patches/`, `build_in_container/`, checksum-ը և առկա `qt.conf`-ը sync են արվում. Git metadata-ն չի sync արվում։ Այլ remote path-ի համար սահմանվում է `REMOTE_QT_DIR`։

## Ընտրանքներ

| Ընտրանք | Նշանակություն |
|---|---|
| `--jobs 16` | Qt/style compile-ի իրական զուգահեռությունը. default՝ container-ի CPU count |
| `--post-only` | Կրկնել արդեն տեղադրված tree-ի post-processing-ը |
| `--rebuild-image` | Վերակառուցել image-ը. չի համակցվում `--post-only`-ի հետ |
| `--cache` | Image build-ի ժամանակ թույլատրել cache-ը. default՝ no-cache |
| `--stop-after` | Հաջող ավարտից հետո հեռացնել container-ը |
| `--no-sync` | Օգտագործել արդեն առկա remote repository ֆայլերը |
| `--no-remote` | Թույլատրել միայն տեղական ճարտարապետության target-ները |
| `--dry-run` | Ցուցադրել պլանը՝ առանց Docker/SSH գործողությունների |
| `--install-root DIR` | Մեկ target-ի այլ install root. այն պետք է արդեն writable լինի build user-ի համար |
| `--build-user NAME` | Այլ գոյություն ունեցող, ոչ root container account |

Host-երը, image-ները և mount-երը սահմանված են `config/`-ում։ `IIT_QT_ROOT`-ով կարելի է փոխել բոլոր target-ների ընդհանուր install base-ը։ `QT_TARBALL`-ով կարելի է նշել այլ tarball path՝ նույն պանակում պահելով style archive-ը։ Պանակների անուններում whitespace և quotes չեն աջակցվում vendor script-ի սահմանափակումների պատճառով։ `PATCHELF_OVERRIDE`-ը սահմանելու դեպքում ընտրվում է հենց այդ executable-ը։

## Ստուգումներ և log-եր

RPATH-ը փոխվում է ժամանակավոր պատճենի վրա. միայն հաջող `patchelf`, RPATH readback և ELF header ստուգումից հետո է պատճենը փոխարինում ֆայլին։ `qmake`-ը RPATH չի ստանում. դրա checksum-ը և pristine backup-ը ստուգվում են։

Պարտադիր են ճիշտ architecture/prefix-ը, Cleanlooks-ը, bundled runtime-ների SONAME-ներն ու տեղական symlink-երը, dependency audit-ը, install ownership-ը և իրական compile/run QtCore smoke test-ը։ AAW-ն նաև ստուգում է default qmake spec-ով C++ ծրագրի build/run-ը՝ առանց `-m64`-ի։ AOK-ում պարտադիր են EGL/X11 reference plugin-ները։

Vendor-ի optional GTK style-ի build error-ը կարող է մնալ log-ում։ Cleanlooks-ի բացակայությունը կամ Qt-ի build/install սխալը ավարտում է target-ը սխալով։ Offscreen `qtdiag`-ը optional է։ Dependency audit-ը և smoke test-երը օգտագործում են `LD_LIBRARY_PATH=$QT_ROOT/lib`։

Log-երը՝ `logs/driver-*.log` և `logs/<target>-<timestamp>/`։ Հեռավոր target-ի մանրամասն log-երը պահվում են հեռավոր host-ի նույն պանակում, իսկ stdout/stderr-ը նաև ընդհանուր driver log-ում։ Օրինակ inspection՝

```bash
docker exec -it qtbuild-aok bash
ssh -t cal-arm-19 'docker exec -it qtbuild-aaw bash'
```

Այս տարբերակի shell/Python syntax-ը, target-ների համակցությունները, remote routing-ը, staged vendor configure/install կանչերը և failure/retry վարքը ստուգվել են տեղական fixture-ներով։ Իրական Qt compilation-ը և NFS/CDTOP permissions-ը պետք է անցնեն քո host-երի վրա. այդ ներքին միջավայրերը այստեղ հասանելի չեն։
