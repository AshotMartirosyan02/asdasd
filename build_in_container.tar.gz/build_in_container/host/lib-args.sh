# shellcheck shell=bash
# CLI parsing for build-qt.sh

usage(){
    cat <<'USAGE'
Usage: ./build-qt.sh [options] <targets>

Targets (one or more, any order):
  -aok | --aok | aok     RHEL 8.10  x86_64   (build host: eiger)
  -soa | --soa | soa     SLE 15.4   x86_64   (build host: eiger)
  -aaw | --aaw | aaw     RHEL 9     aarch64  (build host: cal-arm-19)
  -all | --all           all three

Options:
  --install-root DIR   Override install root (default: /wv/iit/qt/<vco>)
  --force              Replace an existing qt-<version> tree
                       (renamed to qt-<version>-prev-<timestamp>, never deleted)
  --rebuild-image      Rebuild the docker image even if it already exists
  --cache              Allow docker build cache (default: --no-cache)
  --stop-after         Remove the build container when finished
  --jobs N             Parallel build jobs (default: nproc inside the container)
  --owner uid:gid      chown -R the installed tree after a successful build
  --no-remote          Do not SSH; fail if a target needs another host
  --no-sync            Do not rsync build_in_container to the remote host
  --local-only         Internal: never dispatch over SSH (set automatically)
  --dry-run            Show what would be done
  -h | --help          This help

Examples:
  ./build-qt.sh -aok
  ./build-qt.sh -aok -soa --force
  ./build-qt.sh -all --force --rebuild-image
USAGE
}

parse_args(){
    TARGETS=()
    DRY_RUN=0
    LOCAL_ONLY=0
    ALLOW_REMOTE=1
    SYNC_REMOTE=1
    REBUILD_IMAGE=0
    DOCKER_NO_CACHE=1
    STOP_AFTER=0
    FORCE_REPLACE=0
    JOBS=""
    INSTALL_OWNER=""
    INSTALL_ROOT_OVERRIDE=""

    while [ $# -gt 0 ]; do
        case "$1" in
            -aok|--aok|aok) TARGETS+=(aok) ;;
            -soa|--soa|soa) TARGETS+=(soa) ;;
            -aaw|--aaw|aaw) TARGETS+=(aaw) ;;
            -all|--all|all) TARGETS+=(aok soa aaw) ;;
            --install-root) INSTALL_ROOT_OVERRIDE="${2:?--install-root needs a value}"; shift ;;
            --force) FORCE_REPLACE=1 ;;
            --rebuild-image) REBUILD_IMAGE=1 ;;
            --cache) DOCKER_NO_CACHE=0 ;;
            --no-cache) DOCKER_NO_CACHE=1 ;;
            --stop-after) STOP_AFTER=1 ;;
            --jobs) JOBS="${2:?--jobs needs a value}"; shift ;;
            --owner) INSTALL_OWNER="${2:?--owner needs a value}"; shift ;;
            --no-remote) ALLOW_REMOTE=0 ;;
            --no-sync) SYNC_REMOTE=0 ;;
            --local-only) LOCAL_ONLY=1; ALLOW_REMOTE=0 ;;
            --dry-run) DRY_RUN=1 ;;
            -h|--help) usage; exit 0 ;;
            *) usage; fail "Unknown argument: $1" ;;
        esac
        shift
    done

    [ "${#TARGETS[@]}" -gt 0 ] || { usage; fail "No target given (-aok / -soa / -aaw)"; }

    # de-duplicate, keep order
    local seen="" t uniq=()
    for t in "${TARGETS[@]}"; do
        case " $seen " in *" $t "*) continue ;; esac
        seen="$seen $t"
        uniq+=("$t")
    done
    TARGETS=("${uniq[@]}")
}
