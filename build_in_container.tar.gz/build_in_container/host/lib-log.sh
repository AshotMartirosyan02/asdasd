# shellcheck shell=bash
# Logging helpers for the host-side driver.

_ts(){ date '+%Y-%m-%d %H:%M:%S'; }

section(){
    echo
    echo "============================================================"
    echo "$*"
    echo "============================================================"
}

info(){ printf '%s INFO  %s\n' "$(_ts)" "$*"; }
warn(){ printf '%s WARN  %s\n' "$(_ts)" "$*"; }
err(){  printf '%s ERROR %s\n' "$(_ts)" "$*" >&2; }
ok(){   printf '%s OK    %s\n' "$(_ts)" "$*"; }

fail(){ err "$*"; exit 1; }

# run <cmd...> - echo and execute, honouring DRY_RUN
run(){
    info "+ $*"
    [ "${DRY_RUN:-0}" = 1 ] && return 0
    "$@"
}
