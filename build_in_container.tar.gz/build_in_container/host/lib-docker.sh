# shellcheck shell=bash
# Docker image / container handling and in-container dispatch.

load_target_config(){
    VCO=$1
    TARGET_EXTRA_MOUNTS=()
    TARGET_EXTRA_DOCKER_ARGS=()
    TARGET_ENV=()
    [ -f "$BIC_DIR/config/$VCO.conf" ] || fail "Missing config: $BIC_DIR/config/$VCO.conf"
    # shellcheck disable=SC1090
    . "$BIC_DIR/config/$VCO.conf"
    INSTALL_ROOT="${INSTALL_ROOT_OVERRIDE:-$IIT_QT_ROOT/$VCO}"
    QT_ROOT="$INSTALL_ROOT/qt-$QT_VERSION"
}

ensure_docker(){
    command -v docker >/dev/null 2>&1 || fail "docker is not installed on $(hostname -s)"
    docker info >/dev/null 2>&1 || fail "docker daemon is not reachable (permissions? service?)"
}

image_exists(){ docker image inspect "$1" >/dev/null 2>&1; }
container_exists(){ [ -n "$(docker ps -aq --filter "name=^${1}$")" ]; }
container_running(){ [ -n "$(docker ps -q --filter "name=^${1}$")" ]; }

ensure_oss_containers(){
    if [ ! -d "$OSS_CONTAINERS_DIR/.git" ]; then
        info "Cloning oss-containers into $OSS_CONTAINERS_DIR"
        run mkdir -p "$(dirname "$OSS_CONTAINERS_DIR")"
        run git clone "$OSS_CONTAINERS_URL" "$OSS_CONTAINERS_DIR"
    else
        info "Reusing oss-containers at $OSS_CONTAINERS_DIR"
    fi
    [ "${DRY_RUN:-0}" = 1 ] && return 0
    [ -d "$OSS_CONTAINERS_DIR/$TARGET_CONTAINER_DIR" ] ||
        fail "$OSS_CONTAINERS_DIR/$TARGET_CONTAINER_DIR does not exist"
}

build_image(){
    section "[$VCO] Building docker image $TARGET_IMAGE_TAG"
    ensure_oss_containers

    local ctx="$OSS_CONTAINERS_DIR/$TARGET_CONTAINER_DIR"
    local log="$BIC_DIR/logs/${VCO}-image-$RUN_STAMP.log"
    local args=(build)

    [ "$DOCKER_NO_CACHE" = 1 ] && args+=(--no-cache)
    args+=(--pull=false -t "$TARGET_IMAGE_TAG")
    [ -n "$TARGET_DOCKERFILE" ] && args+=(-f "$TARGET_DOCKERFILE")
    args+=(.)

    if [ "$TARGET_RUN_SETUP" = 1 ] && [ -f "$ctx/setup.sh" ]; then
        info "Running $ctx/setup.sh"
        [ "${DRY_RUN:-0}" = 1 ] || ( cd "$ctx" && chmod +x ./setup.sh && ./setup.sh )
    fi

    info "+ (cd $ctx && DOCKER_BUILDKIT=0 docker ${args[*]})"
    [ "${DRY_RUN:-0}" = 1 ] && return 0

    local rc
    ( cd "$ctx" && DOCKER_BUILDKIT=0 docker "${args[@]}" ) 2>&1 | tee "$log"
    rc=${PIPESTATUS[0]}
    [ "$rc" -eq 0 ] || fail "[$VCO] docker image build failed (rc=$rc), log: $log"
    ok "[$VCO] image built: $TARGET_IMAGE_TAG (log: $log)"
}

ensure_image(){
    if image_exists "$TARGET_IMAGE_TAG" && [ "$REBUILD_IMAGE" = 0 ]; then
        ok "[$VCO] image already present: $TARGET_IMAGE_TAG"
    else
        [ "$REBUILD_IMAGE" = 1 ] && info "[$VCO] --rebuild-image requested"
        build_image
    fi
}

mount_args(){
    local m
    local mounts=("${COMMON_MOUNTS[@]}")
    mounts+=(${TARGET_EXTRA_MOUNTS[@]+"${TARGET_EXTRA_MOUNTS[@]}"})
    for m in "${mounts[@]}"; do
        if [ ! -e "$m" ]; then
            warn "[$VCO] skipping missing bind mount: $m"
            continue
        fi
        printf '%s\n%s\n' "--mount" "src=$m,target=$m,type=bind"
    done
    printf '%s\n%s\n' "--mount" "src=$QT_DIR,target=$QT_DIR,type=bind"
}

port_in_use(){
    command -v ss >/dev/null 2>&1 || return 1
    ss -ltn 2>/dev/null | grep -qE "[:.]${1}[[:space:]]"
}

recreate_container(){
    section "[$VCO] Recreating container $TARGET_CONTAINER_NAME"

    if container_exists "$TARGET_CONTAINER_NAME"; then
        if container_running "$TARGET_CONTAINER_NAME"; then
            info "[$VCO] stopping running container"
        else
            info "[$VCO] removing stale container"
        fi
        run docker rm -f "$TARGET_CONTAINER_NAME"
    fi

    if port_in_use "$TARGET_SSH_PORT"; then
        fail "[$VCO] host port $TARGET_SSH_PORT is already in use (set ${VCO^^}_SSH_PORT to another value)"
    fi

    local margs=()
    mapfile -t margs < <(mount_args)

    local args=(run --rm -d --name "$TARGET_CONTAINER_NAME" -p "${TARGET_SSH_PORT}:22")
    args+=(${TARGET_EXTRA_DOCKER_ARGS[@]+"${TARGET_EXTRA_DOCKER_ARGS[@]}"})
    args+=("${margs[@]}")
    args+=(--workdir "$QT_DIR" "$TARGET_IMAGE_TAG")

    info "+ docker ${args[*]}"
    [ "${DRY_RUN:-0}" = 1 ] && return 0

    docker "${args[@]}" >/dev/null || fail "[$VCO] docker run failed"
    docker exec "$TARGET_CONTAINER_NAME" true || fail "[$VCO] container is not responding"
    ok "[$VCO] container running: $TARGET_CONTAINER_NAME (ssh port $TARGET_SSH_PORT)"
}

# Make sure the unprivileged build user exists inside the container, owns
# /build and can really write into the deployment area. Runs as root, once per
# container, and reports the uid/gid the real build has to use.
prepare_container_user(){
    BUILD_UID=0
    BUILD_GID=0
    BUILD_HOME=/root

    if [ "${BUILD_USER:-root}" = root ]; then
        warn "[$VCO] running the build as root - only safe with --install-root outside /wv"
        return 0
    fi

    section "[$VCO] Preparing build user $BUILD_USER"
    [ "${DRY_RUN:-0}" = 1 ] && { BUILD_UID=0; BUILD_GID=0; return 0; }

    local out
    out=$(docker exec -u root \
        -e "BUILD_USER=$BUILD_USER" \
        -e "VCO=$VCO" \
        -e "IIT_QT_ROOT=$IIT_QT_ROOT" \
        -e "INSTALL_ROOT=$INSTALL_ROOT" \
        -e "ALLOW_UID_MISMATCH=${ALLOW_UID_MISMATCH:-0}" \
        "$TARGET_CONTAINER_NAME" \
        /usr/bin/bash "$QT_DIR/build_in_container/container/bootstrap-user.sh") ||
        fail "[$VCO] could not prepare build user $BUILD_USER inside the container"

    BUILD_UID=$(printf '%s\n' "$out" | awk -F= '/^BUILD_UID=/{print $2}')
    BUILD_GID=$(printf '%s\n' "$out" | awk -F= '/^BUILD_GID=/{print $2}')
    BUILD_HOME=$(printf '%s\n' "$out" | awk -F= '/^BUILD_HOME=/{print $2}')
    [ -n "$BUILD_UID" ] && [ -n "$BUILD_GID" ] && [ -n "$BUILD_HOME" ] ||
        fail "[$VCO] bootstrap-user.sh did not report uid/gid/home"

    ok "[$VCO] build user $BUILD_USER -> uid=$BUILD_UID gid=$BUILD_GID home=$BUILD_HOME"
    info "[$VCO] the container is entered by user name so supplementary groups are kept"
}

exec_container_build(){
    section "[$VCO] Running the in-container build"

    local log="$BIC_DIR/logs/${VCO}-build-$RUN_STAMP.log"
    local eargs=()
    local e

    if [ "${BUILD_USER:-root}" != root ]; then
        # By NAME on purpose: docker/runc then also grants the supplementary
        # groups from /etc/group, which is how cdtop gets write access to the
        # group-writable /wv/iit/qt/<vco> directories. A numeric uid:gid would
        # drop those groups and the build would fail on the share.
        eargs+=(-u "$BUILD_USER")
    fi
    eargs+=(-e "HOME=$BUILD_HOME")
    eargs+=(-e "USER=$BUILD_USER")
    eargs+=(-e "BUILD_USER=$BUILD_USER")
    eargs+=(-e "VCO=$VCO")
    eargs+=(-e "QT_VERSION=$QT_VERSION")
    eargs+=(-e "QT_TARBALL=$QT_TARBALL")
    eargs+=(-e "QT_REPO_DIR=$QT_DIR")
    eargs+=(-e "INSTALL_ROOT=$INSTALL_ROOT")
    eargs+=(-e "IIT_QT_ROOT=$IIT_QT_ROOT")
    eargs+=(-e "FORCE_REPLACE=$FORCE_REPLACE")
    eargs+=(-e "POST_ONLY=$POST_ONLY")
    eargs+=(-e "ADOPT_PREV=$ADOPT_PREV")
    [ -n "$JOBS" ]          && eargs+=(-e "JOBS=$JOBS")
    [ -n "$INSTALL_OWNER" ] && eargs+=(-e "INSTALL_OWNER=$INSTALL_OWNER")
    for e in ${TARGET_ENV[@]+"${TARGET_ENV[@]}"}; do eargs+=(-e "$e"); done

    info "+ docker exec (as ${BUILD_USER:-root}) $TARGET_CONTAINER_NAME run-build.sh $VCO"
    info "  log: $log"
    [ "${DRY_RUN:-0}" = 1 ] && return 0

    local rc
    docker exec "${eargs[@]}" "$TARGET_CONTAINER_NAME" \
        /usr/bin/bash "$QT_DIR/build_in_container/container/run-build.sh" "$VCO" 2>&1 | tee "$log"
    rc=${PIPESTATUS[0]}

    if [ "$rc" -ne 0 ]; then
        err "[$VCO] in-container build failed (rc=$rc)"
        err "[$VCO] container kept alive for inspection: docker exec -it $TARGET_CONTAINER_NAME bash"
        return "$rc"
    fi
    ok "[$VCO] build finished, log: $log"
    return 0
}

build_target_local(){
    local vco=$1 rc=0
    load_target_config "$vco"

    section "[$vco] Local build on $(hostname -s) ($(uname -m))"
    info "[$vco] image:        $TARGET_IMAGE_TAG"
    info "[$vco] container:    $TARGET_CONTAINER_NAME"
    info "[$vco] build user:   ${BUILD_USER:-root}"
    info "[$vco] install root: $INSTALL_ROOT"
    info "[$vco] final tree:   $QT_ROOT"

    if [ "$POST_ONLY" = 1 ] && [ ! -d "$QT_ROOT" ]; then
        warn "[$vco] --post-only requested but $QT_ROOT does not exist"
        if [ -d "$INSTALL_ROOT" ]; then
            info "[$vco] present in $INSTALL_ROOT:"
            ls -1d "$INSTALL_ROOT"/qt-* 2>/dev/null | sed 's|^|            |' || true
        fi
    fi

    ensure_docker
    ensure_image
    recreate_container
    prepare_container_user
    exec_container_build || rc=$?

    if [ "$rc" -eq 0 ] && [ "$STOP_AFTER" = 1 ]; then
        info "[$vco] removing container (--stop-after)"
        run docker rm -f "$TARGET_CONTAINER_NAME" >/dev/null 2>&1 || true
    fi
    return $rc
}
