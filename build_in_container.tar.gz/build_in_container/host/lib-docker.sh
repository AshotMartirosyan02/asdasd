load_target_config(){
    VCO=$1
    source "$BIC_DIR/config/$VCO.conf"
    [[ "$TARGET_CONTAINER_NAME" =~ ^[a-zA-Z0-9][a-zA-Z0-9_.-]*$ ]] || fail "Invalid container name"
    INSTALL_ROOT="${INSTALL_ROOT_OVERRIDE:-$IIT_QT_ROOT/$VCO}"
    INSTALL_ROOT=${INSTALL_ROOT%/}
    QT_ROOT="$INSTALL_ROOT/qt-$QT_VERSION"
}
container_exists(){ docker container inspect "$1" >/dev/null 2>&1; }
container_running(){ [ "$(docker inspect --format '{{.State.Running}}' "$1")" = true ]; }
ensure_image(){
    if [ "$REBUILD_IMAGE" = 1 ] || ! docker image inspect "$TARGET_IMAGE_TAG" >/dev/null 2>&1; then
        if [ ! -d "$OSS_CONTAINERS_DIR/$TARGET_CONTAINER_DIR" ]; then
            [ ! -e "$OSS_CONTAINERS_DIR" ] || fail "Container source is incomplete: $OSS_CONTAINERS_DIR"
            git clone "$OSS_CONTAINERS_URL" "$OSS_CONTAINERS_DIR"
        fi
        local context="$OSS_CONTAINERS_DIR/$TARGET_CONTAINER_DIR"
        [ -d "$context" ] || fail "Missing image context: $context"
        local args=(build --pull=false -t "$TARGET_IMAGE_TAG")
        [ "$DOCKER_NO_CACHE" = 0 ] || args+=(--no-cache)
        [ -z "$TARGET_DOCKERFILE" ] || args+=(-f "$TARGET_DOCKERFILE")
        if [ "$TARGET_RUN_SETUP" = 1 ] && [ -f "$context/setup.sh" ]; then
            (cd "$context" && bash ./setup.sh)
        fi
        (cd "$context" && DOCKER_BUILDKIT=0 docker "${args[@]}" .) 2>&1 | tee "$TARGET_LOG_DIR/image.log"
    fi
    local architecture expected
    architecture=$(docker image inspect --format '{{.Architecture}}' "$TARGET_IMAGE_TAG")
    case "$TARGET_ARCH" in x86_64) expected=amd64 ;; aarch64) expected=arm64 ;; esac
    [ "$architecture" = "$expected" ] || fail "$TARGET_IMAGE_TAG is $architecture, expected $expected"
}
collect_container_evidence(){
    local dest=$1 part
    [ -n "${TARGET_CONTAINER_NAME:-}" ] && container_exists "$TARGET_CONTAINER_NAME" || return 0
    mkdir -p "$dest"
    for part in logs backups; do
        docker cp "$TARGET_CONTAINER_NAME:/build/$part" "$dest/" >/dev/null 2>&1 || true
    done
}
prepare_build_container(){
    if [ "$POST_ONLY" = 1 ] && container_exists "$TARGET_CONTAINER_NAME"; then
        container_running "$TARGET_CONTAINER_NAME" || docker start "$TARGET_CONTAINER_NAME" >/dev/null
        local existing_arch existing_image
        existing_image=$(docker inspect --format '{{.Config.Image}}' "$TARGET_CONTAINER_NAME")
        [ "$existing_image" = "$TARGET_IMAGE_TAG" ] || fail "Existing container uses $existing_image, expected $TARGET_IMAGE_TAG"
        existing_arch=$(docker exec "$TARGET_CONTAINER_NAME" uname -m)
        [ "$existing_arch" = "$TARGET_ARCH" ] || fail "Existing container architecture is $existing_arch"
        docker exec "$TARGET_CONTAINER_NAME" test -r "$QT_DIR/bin/buildQt-$QT_VERSION" ||
            fail "Existing container does not have the requested Qt repository mounted"
        docker exec "$TARGET_CONTAINER_NAME" test -x "$QT_ROOT/bin/qmake" ||
            fail "No installed qmake for post-only: $QT_ROOT"
        info "[$VCO] reusing $TARGET_CONTAINER_NAME"
        return 0
    fi
    if container_exists "$TARGET_CONTAINER_NAME"; then
        collect_container_evidence "$TARGET_LOG_DIR/previous-container"
        docker rm -f "$TARGET_CONTAINER_NAME" >/dev/null
    fi
    local args=(run -d --name "$TARGET_CONTAINER_NAME" --init
        --entrypoint /usr/bin/bash --workdir "$QT_DIR")
    local m
    for m in "${COMMON_MOUNTS[@]}"; do
        [ -d "$m" ] || continue
        if [ "$m" = /wv/iit ]; then
            args+=(--mount "type=bind,src=$m,dst=$m")
        else
            args+=(--mount "type=bind,src=$m,dst=$m,readonly")
        fi
    done
    case "$INSTALL_ROOT/" in
        /wv/iit/*) [ -d /wv/iit ] || fail "/wv/iit is not mounted on this host" ;;
        *)
            [ -d "$INSTALL_ROOT" ] || fail "Create the custom install root with build-user permissions first: $INSTALL_ROOT"
            args+=(--mount "type=bind,src=$INSTALL_ROOT,dst=$INSTALL_ROOT") ;;
    esac
    args+=(--mount "type=bind,src=$QT_DIR,dst=$QT_DIR,readonly")
    docker "${args[@]}" "$TARGET_IMAGE_TAG" -c 'exec sleep infinity' >/dev/null
    docker exec "$TARGET_CONTAINER_NAME" true
}
prepare_container_user(){
    local output
    output=$(docker exec -u root \
        -e "BUILD_USER=$BUILD_USER" -e "VCO=$VCO" \
        -e "INSTALL_ROOT=$INSTALL_ROOT" -e "IIT_QT_ROOT=$IIT_QT_ROOT" \
        -e "STRICT_UID=${STRICT_UID:-0}" "$TARGET_CONTAINER_NAME" \
        /usr/bin/bash "$QT_DIR/build_in_container/container/bootstrap-user.sh")
    BUILD_HOME=$(awk -F= '/^BUILD_HOME=/{print $2}' <<< "$output")
    [ -n "$BUILD_HOME" ] || fail "Container bootstrap did not report HOME"
}
exec_container_build(){
    local args=(exec -u "$BUILD_USER"
        -e "HOME=$BUILD_HOME" -e "USER=$BUILD_USER" -e "BUILD_USER=$BUILD_USER"
        -e "VCO=$VCO" -e "QT_VERSION=$QT_VERSION" -e "QT_TARBALL=$QT_TARBALL"
        -e "QT_REPO_DIR=$QT_DIR" -e "IIT_QT_ROOT=$IIT_QT_ROOT" -e "INSTALL_ROOT=$INSTALL_ROOT"
        -e "POST_ONLY=$POST_ONLY" -e "RUN_STAMP=$RUN_STAMP")
    [ -z "$JOBS" ] || args+=(-e "JOBS=$JOBS")
    [ -z "${PATCHELF_OVERRIDE:-}" ] || args+=(-e "PATCHELF_OVERRIDE=$PATCHELF_OVERRIDE")
    local item
    for item in "${TARGET_ENV[@]}"; do args+=(-e "$item"); done
    docker "${args[@]}" "$TARGET_CONTAINER_NAME" \
        /usr/bin/bash "$QT_DIR/build_in_container/container/run-build.sh" "$VCO"
}
target_exit(){
    local rc=$?
    trap - EXIT
    set +e
    collect_container_evidence "$TARGET_LOG_DIR/container"
    if [ "$rc" -ne 0 ]; then
        err "[$VCO] failed (rc=$rc); log: $TARGET_LOG_DIR/build.log"
        err "Inspect: docker exec -it $TARGET_CONTAINER_NAME bash"
    elif [ "$STOP_AFTER" = 1 ]; then
        docker rm -f "$TARGET_CONTAINER_NAME" >/dev/null || true
    fi
    exit "$rc"
}
build_target_local(){
    load_target_config "$1"
    if [ "$DRY_RUN" = 1 ]; then
        info "[$VCO] image=$TARGET_IMAGE_TAG; container=$TARGET_CONTAINER_NAME; user=$BUILD_USER"
        info "[$VCO] destination=$QT_ROOT; post-only=$POST_ONLY; jobs=${JOBS:-automatic}"
        return 0
    fi
    local cmd
    for cmd in docker flock tee; do command -v "$cmd" >/dev/null || fail "Missing host command: $cmd"; done
    docker info >/dev/null
    local lock_dir="${XDG_CACHE_HOME:-$HOME/.cache}/qt-container-build/locks"
    mkdir -p "$lock_dir"
    exec 9>"$lock_dir/$TARGET_CONTAINER_NAME.lock"
    flock -n 9 || fail "Another build is using $TARGET_CONTAINER_NAME"
    TARGET_LOG_DIR="$BIC_DIR/logs/$VCO-$RUN_STAMP"
    mkdir -p "$TARGET_LOG_DIR"
    if [ "$POST_ONLY" = 1 ]; then
        [ -x "$QT_ROOT/bin/qmake" ] || fail "--post-only requires an existing installed qmake: $QT_ROOT"
    fi
    ensure_image
    prepare_build_container
    trap target_exit EXIT
    prepare_container_user
    exec_container_build 2>&1 | tee "$TARGET_LOG_DIR/build.log"
    ok "[$VCO] completed: $QT_ROOT"
}
