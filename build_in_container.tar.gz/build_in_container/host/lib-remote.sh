target_arch(){
    case "$1" in aok|soa) echo x86_64 ;; aaw) echo aarch64 ;; *) fail "Unknown target: $1" ;; esac
}
host_for_arch(){
    case "$1" in x86_64) echo "$HOST_X86_64" ;; aarch64) echo "$HOST_AARCH64" ;; esac
}
ssh_run(){
    local host=$1 command; shift
    printf -v command '%q ' "$@"
    ssh $SSH_OPTS "$host" "$command"
}
dispatch_remote(){
    local arch=$1 target=$2 host rqt command rsync_shell rel name
    host=$(host_for_arch "$arch")
    rqt=${REMOTE_QT_DIR:-$QT_DIR}
    case "$rqt" in /*) ;; *) fail "REMOTE_QT_DIR must be absolute" ;; esac
    info "[$target] remote host: $host; repository: $rqt"
    if [ "$DRY_RUN" = 1 ]; then
        info "[$target] would sync bin/, patches/, build_in_container/ and run the target on $host"
        return 0
    fi
    command -v ssh >/dev/null || fail "ssh is required"
    ssh_run "$host" true || fail "Cannot SSH to $host"
    if [ "$SYNC_REMOTE" = 1 ]; then
        command -v rsync >/dev/null || fail "rsync is required for remote builds"
        ssh_run "$host" mkdir -p "$rqt/bin" "$rqt/patches" "$rqt/build_in_container"
        rsync_shell="ssh $SSH_OPTS"
        for rel in bin patches build_in_container; do
            [ -d "$QT_DIR/$rel" ] || fail "Missing source directory: $QT_DIR/$rel"
            rsync -a --checksum --delete --exclude 'logs/' -e "$rsync_shell" \
                "$QT_DIR/$rel/" "$host:$rqt/$rel/"
        done
        for rel in md5sums.txt qt.conf; do
            [ -f "$QT_DIR/$rel" ] || continue
            rsync -a --checksum -e "$rsync_shell" "$QT_DIR/$rel" "$host:$rqt/$rel"
        done
    fi
    ssh_run "$host" test -r "$rqt/bin/buildQt-$QT_VERSION" || fail "Remote Qt build script is missing"
    local env_args=(env "QT_VERSION=$QT_VERSION" "QT_TARBALL=$QT_TARBALL"
        "IIT_QT_ROOT=$IIT_QT_ROOT" "BUILD_USER=$BUILD_USER"
        "OSS_CONTAINERS_URL=$OSS_CONTAINERS_URL"
        "OSS_CONTAINERS_DIR=${REMOTE_OSS_CONTAINERS_DIR:-$(dirname "$rqt")/oss-containers}")
    for name in AOK_IMAGE_TAG SOA_IMAGE_TAG AAW_IMAGE_TAG AOK_CONTAINER_NAME SOA_CONTAINER_NAME \
        AAW_CONTAINER_NAME AOK_EGL_MODE SOA_EGL_MODE AAW_EGL_X11_MODE \
        REQUIRE_AOK_REFERENCE_PLUGINS PATCHELF_OVERRIDE STRICT_UID; do
        [ -z "${!name:-}" ] || env_args+=("$name=${!name}")
    done
    info "[$target] starting remote build"
    ssh_run "$host" "${env_args[@]}" bash "$rqt/build_in_container/build-qt.sh" \
        --_run-one --local-only "$target" "${FORWARD_ARGS[@]}"
}
