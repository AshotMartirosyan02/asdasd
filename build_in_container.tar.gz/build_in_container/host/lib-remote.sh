# shellcheck shell=bash
# Architecture detection and SSH dispatching.

target_arch(){
    case "$1" in
        aok|soa) printf 'x86_64\n' ;;
        aaw)     printf 'aarch64\n' ;;
        *)       fail "Unknown target: $1" ;;
    esac
}

host_for_arch(){
    case "$1" in
        x86_64)  printf '%s\n' "$HOST_X86_64" ;;
        aarch64) printf '%s\n' "$HOST_AARCH64" ;;
        *)       fail "Unsupported architecture: $1" ;;
    esac
}

ssh_run(){
    local host=$1; shift
    # shellcheck disable=SC2086
    ssh $SSH_OPTS "$host" "$@"
}

# Resolve the qt repository path on a remote host.
remote_qt_dir(){
    local host=$1
    if [ -n "${REMOTE_QT_DIR:-}" ]; then
        printf '%s\n' "$REMOTE_QT_DIR"
        return 0
    fi
    if ssh_run "$host" "test -f '$QT_DIR/bin/buildQt-${QT_VERSION}'" >/dev/null 2>&1; then
        printf '%s\n' "$QT_DIR"
        return 0
    fi
    # shellcheck disable=SC2016
    ssh_run "$host" "eval echo $REMOTE_WORK_ROOT/qt"
}

ensure_remote_workspace(){
    local host=$1 rqt=$2
    if ! ssh_run "$host" "test -f '$rqt/bin/buildQt-${QT_VERSION}'" >/dev/null 2>&1; then
        warn "No qt repository on $host at $rqt - cloning $QT_REPO_URL"
        run ssh_run "$host" "mkdir -p '$(dirname "$rqt")' && cd '$(dirname "$rqt")' && git clone '$QT_REPO_URL' '$(basename "$rqt")'"
        [ "${DRY_RUN:-0}" = 1 ] || ssh_run "$host" "test -f '$rqt/bin/buildQt-${QT_VERSION}'" ||
            fail "qt repository still missing on $host:$rqt"
    fi
    if [ "$SYNC_REMOTE" = 1 ]; then
        info "Syncing build_in_container -> $host:$rqt/build_in_container"
        # shellcheck disable=SC2086
        run rsync -az --delete --exclude 'logs/' -e "ssh $SSH_OPTS" \
            "$BIC_DIR/" "$host:$rqt/build_in_container/"
    fi
}

remote_flags(){
    local flags="--local-only"
    [ "$FORCE_REPLACE" = 1 ]   && flags="$flags --force"
    [ "$POST_ONLY" = 1 ]       && flags="$flags --post-only"
    [ "$ADOPT_PREV" = 1 ]      && flags="$flags --adopt-prev"
    [ "$REBUILD_IMAGE" = 1 ]   && flags="$flags --rebuild-image"
    [ "$DOCKER_NO_CACHE" = 0 ] && flags="$flags --cache"
    [ "$STOP_AFTER" = 1 ]      && flags="$flags --stop-after"
    [ "$DRY_RUN" = 1 ]         && flags="$flags --dry-run"
    [ -n "$JOBS" ]             && flags="$flags --jobs $JOBS"
    [ -n "$INSTALL_OWNER" ]    && flags="$flags --owner $INSTALL_OWNER"
    [ -n "$INSTALL_ROOT_OVERRIDE" ] && flags="$flags --install-root $INSTALL_ROOT_OVERRIDE"
    [ -n "${BUILD_USER:-}" ]   && flags="$flags --build-user $BUILD_USER"
    printf '%s\n' "$flags"
}

# dispatch_remote <arch> <target...>
dispatch_remote(){
    local arch=$1; shift
    local targets="$*"
    local host rqt flags cmd rc=0

    host=$(host_for_arch "$arch")
    section "Dispatching [$targets] to $host ($arch)"

    [ "$ALLOW_REMOTE" = 1 ] ||
        fail "Targets [$targets] require $arch ($host) but remote execution is disabled"

    ssh_run "$host" true >/dev/null 2>&1 || fail "Cannot SSH to $host"

    rqt=$(remote_qt_dir "$host")
    info "Remote qt repository: $host:$rqt"
    ensure_remote_workspace "$host" "$rqt"

    flags=$(remote_flags)
    local args=""
    local t
    for t in $targets; do args="$args -$t"; done
    cmd="cd '$rqt/build_in_container' && ./build-qt.sh $flags$args"

    info "+ ssh $host bash -lc \"$cmd\""
    [ "${DRY_RUN:-0}" = 1 ] && return 0

    # shellcheck disable=SC2086
    ssh $SSH_OPTS -tt "$host" "bash -lc \"$cmd\"" || rc=$?
    return $rc
}
